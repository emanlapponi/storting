#' Polity IV Coups -  The Polity IV Project Coups d'Etat, Marshall and Marshall (2013). 
#' 
#' @description This dataset compiles basic descriptive information on all coups d’état occurring in countries 
#' reaching a population greater than 500,000 during the period 1946-2012. 
#'For full documentation, see \url{http://www.systemicpeace.org/inscr/CSPCoupsCodebook2012.pdf}. 
#'The dataset is a copy of CSPCoupsList2012.xls downloaded from The Systemic Peace website.
#' @format An unbalanced dataframe with  824 rows and 9 variables. 
#' Each row indicates a coup d’état in a country with population greater than 500000
#' in the period 1946 - 2012.
#' \describe{
#' \item{country}{Country name}
#' \item{scode}{Standard INSCR three-letter country abbreviation.}
#' \item{mth}{Month of coup d’état event.}
#' \item{day}{Beginning day of coup d’état event.}
#' \item{year}{Year of coup d’état event.}
#' \item{success}{Coded result of coup d’état event: 1) successful coup; 2) attempted (failed) 
#' coup; 3) plotted coup; and 4) alleged coup plot.}
#' \item{leader}{Brief description/identification of coup leader(s); in successful cases where coup 
#' leader is not clearly identified, the new executive leader is reported as the coup leader}
#' \item{deaths}{Number of persons killed during the coup and/or as a direct result of the coup
#' event(executions of ousted leaders or coup plotters are included as reported). 
#' In cases where reports do not provide specific information on, or estimates of, 
#' the number killed as a direct result of coups, attempted coups, or the 
#' discovery of coup plots, a code of “999” is entered.}
#' \item{arc}{Adverse Regime Change: A one (1) on this indicator identifies successful 
#' coups that resulted in what the Political Instability Task Force (PITF) has 
#' designated as an “adverse regime change,” which is defined by a decrease in 
#' the regime’s Polity IV POLITY score by six points or more or a near total 
#' collapse of central authority (POLITY code -77, interregnum). }
#'  } 
#' @name PolityIVcoups
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Marshall and Marshall (2013). “Coups d'Etat, 1946-2012”. 
#' @source Marshall and Marshall (2013) at Center for Systemic Peace online: \url{http://www.systemicpeace.org/inscr/inscr.htm}.
#' @seealso PolityIV ACImepv
#' @keywords dataset regime
#' @examples
#' #This example shows the share of coups each year
#' #that results in an adverse regime change
#' data(PolityIVcoups)
#' 
#' PolityIVcoups <- PolityIVcoups[1:820,]
#' PolityIVcoups$arc[is.na(PolityIVcoups$arc)] <- 0
#' 
#' Length <- aggregate(PolityIVcoups$arc,by=list(PolityIVcoups$year),length)
#' sum <- aggregate(PolityIVcoups$arc,by=list(PolityIVcoups$year),sum)
#' breakdown <- merge(Length,sum,by="Group.1")
#' breakdown$share <- breakdown$x.y/breakdown$x.x
#' plot(breakdown$Group.1,breakdown$share,type="l",ylim=c(0,1),lwd=2,
#'      main="Share of coups resulting in an adverse regime change",
#'      ylab="Share",xlab="Year")
#' 
NULL 