#' Chapel Hill expert survey 1999
#' 
#' @description This is the 1999 edition of the Chapel Hill expert opinion survey of party positions.
#' @format A cross-sectional dataframe with 1233 rows and 19 variables.
#' It includes 129 parties from 15 countries.
#' For full documentation, see \url{http://www.unc.edu/~hooghe/data_pp.php}
#' \describe{
#' 
#' \item{expert}{expert id}
#' \item{country}{country id}
#' \item{partyname}{name of party}
#' \item{party.}{party id}
#' \item{position}{Party position to european integration, categorized from 1 - 7. The higher value the more in favor of integration. Original name: Q1}
#' \item{salience2}{The relative importance of the european integration issue for this party this year. Categorized from 1 - 5 and 5 is most salient, 1 the least. Original name: Q2}
#' \item{dissent2}{The degree of party dissent on the issue of european integration. This is categorized from 1 - 5 where 5 is most dissent, 1 the least. Original name: Q3}
#' \item{q4}{Empty column. Not in codebook.}
#' \item{future_ei}{Party stance on the future of integration. Categorized from 1 - 5: 5 indicates it should be pushed further, 1 indicates it has gone to far. Original name: Q5}
#' \item{ep}{Position of the party leadership on strengthening the European Parliament. Higher value indicate pro-strengthening. NB: Missing values indicate parties that have not taken a stance. Original name: Q6a}
#' \item{eu_tax}{Position of party leadership on tax harmonization in the EU. Higher value indicate more in favor of tax harmonization. NB: Missing values indicate parties that have not taken a stance. Original name: Q6b}
#' \item{eu_employ}{Position of party leadership on common employment policy in EU. Higher value indicate more in favor of employment policy NB: Missing values indicate parties that have not taken a stance. Original name: Q6c}
#' \item{eu_cohesion}{Position of party leadership on EU cohesion policy. Higher value indicate more in favor of cohesion policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q6d}
#' \item{eu_envir}{Position of party leadership on common EU environmental policy. Higher value indicate more in favor of common EU environmental policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q6e}
#' \item{eu_asylum}{Position of party leadership on common policy on political asylum. Higher value indicate more in favor of common policy on political asylum. NB: Missing values indicate parties that have not taken a stance. Original name: Q6f}
#' \item{eu_foreignpol}{Position of party leadership on common foreign and security policy. Higher value indicate more in favor of common foreign and security policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q6g}
#' \item{leftright}{Position of party in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q8a}
#' \item{econlr}{Position of party on economic issues in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q8b}
#' \item{galtan}{Position of party on democratic freedom and rights in the broad ideological spectrum. Democratic freedom and rights is understood as the role of government in life choices. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q8c}
#' 
#'  }
#' @name ChapelHill1999
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Marco Steenbergen and Gary Marks (2007). "Evaluating Expert Surveys," European Journal of Political Research, 46(3): 347–366.
#' @source \url{http://www.unc.edu/~hooghe/data_pp.php} 
#' @seealso ChapelHill2010 ChapelHill2006 ChapelHill2002 
#' @keywords dataset party position
#' @examples
#' data(ChapelHill1999)
#' 
#' # This scatterplot illustrates some obvious correlation between
#' 
#' #party position on different dimensions.
#' library(car)
#' scatterplotMatrix(~leftright+position+eu_tax+eu_employ+
#'                     eu_cohesion+eu_envir+eu_asylum, data=ChapelHill1999,
#'                   main="Scatterplot")
#' 
#' #This example shows how to evaluate if there is any significant
#' #variation in the coding between experts
#' data(ChapelHill1999)
#' library(lme4)
#' ChapelHill1999$country <- as.factor(as.character(ChapelHill1999$country))
#' ChapelHill1999$party. <- as.factor(as.character(ChapelHill1999$party.))
#' ChapelHill1999$expert <- as.factor(as.character(ChapelHill1999$expert))
#' 
#' 
#' PartySD <- aggregate(ChapelHill1999$position,by=list(ChapelHill1999$party.), FUN=sd)
#' SDData <- merge(ChapelHill1999,PartySD, by.x="party.",by.y="Group.1",all=TRUE)
#' 
#' #The coding of parties are more unstable if there is dissent on the party-sta
#' ExpertJudgements <- lmer(x ~ dissent2 + salience2 + (1|country) + (1|expert),data=SDData)
#' 
#' #The coding of a party is less secure the more dissent there is within the party.
#' #The more important the issue is for the party, the more precise coding of position
#' #There is no significant variance in party-standard deviation between experts nor country
#' summary(ExpertJudgements)
NULL