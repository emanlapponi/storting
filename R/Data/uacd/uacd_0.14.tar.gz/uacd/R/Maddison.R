#' Maddison - Angus Maddisons Statistics on Population, GDP and GDP per capita 1 - 2008 AD
#' 
#' @description These are historical data on statistics on Population, GDP and GDP per capita 1 - 2008 AD from Angus Maddison
#' @format This is a balanced data frame with 35476 observations and 5 variables.
#' It includes 181 areas (countries and regions) over the period 1 A.D. - 2030.
#' Each area is noted for 196 years, but with several missing country-years.
#' 
#' \describe{
#' \item{Country}{Country}
#' \item{Year}{Year}
#' \item{GDPpc}{GDP per capita in constant 1990 Geary-Khamis dollars}
#' \item{GDP}{GDP in constant 1990 Geary-Khamis dollars}
#' \item{Population}{Population in thousand measured mid-year}
#' }
#' 
#' @name Maddison
#' @author Bjørn Høyland, Haakon Gjerløw og Aleksander Eilertsen
#' @details Notice that population measures are predicted from 2009 - 2030.
#' @keywords dataset economy
#' @source Homepage: \url{http://www.ggdc.net/maddison/oriindex.htm}
#' @seealso MaddisonNew
#' @references Angus Maddison (2010). "Statistics on Population, GDP and GDP per capita 1 - 2008 AD". University of Gronigen.
#' @examples
#' library(ggplot2)
#' data(Maddison)
#' 
#' Modern <- Maddison[which(Maddison$Year>=1950 & Maddison$Country!="World Total"
#'                          & Maddison$Country!="Asia" & Maddison$Country!="16 E. Asia"
#'                          & Maddison$Country!="12 W. Europe" & Maddison$Country!="14 small WEC"
#'                          & Maddison$Country!="15 L. America" & Maddison$Country!="15 W. Asia"
#'                          & Maddison$Country!="21 Caribbean" & Maddison$Country!="24 Sm. E. Asia"
#'                          & Maddison$Country!="3 Small Afr." & Maddison$Country!="30 E. Asia"
#'                          & Maddison$Country!="7 E. Europe" & Maddison$Country!="8 L. America"
#'                          & Maddison$Country!="30 W. Europe" & Maddison$Country!="Total Africa"
#'                          & Maddison$Country!="L. America" & Maddison$Country!="W. Offshoots"),]
#' 
#' ggplot(Modern, aes(Year, Population, group = Country)) +
#'   geom_rect(aes(xmax=2030,xmin=2009,ymax=max(Modern$Population),ymin=0),
#'             alpha=0.01,fill="grey20",inherit.aes=FALSE) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Population in thousands") +
#'   geom_text(aes(x=2020,y=max(Modern$Population)+50000,label="Predicted area")) +
#'   geom_text(aes(x=2002,y=1400000,size=8,label="China")) +
#'   geom_text(aes(x=2002,y=1150000,size=8,label="India")) +
#'   theme(legend.position="none")
#' 
#' 
#' #Several authors claim that PR systems serve the majority better than other
#' #democracies partly because the have larger electoral districts,
#' #making politicians answer to larger segments of society.
#' #If this is true, then we should observe that larger district magnitude is
#' #positive for GDP per capita growth, under the assumption that GDP per capita
#' #growth is a good valued by the majority.
#' 
#' data(desaw)
#' data(Maddison)
#' 
#' Maddison <- Maddison[which(Maddison$Year >= 1945 & Maddison$Year <= 2008),]
#' desaw <- desaw[which(desaw$year >= 1945 & desaw$year <= 2008),]
#' 
#' library(car)
#' Maddison$Country <- recode(Maddison$Country, "'Centr. Afr. Rep.'='Central African Republic';
#'                            'Comoro Islands'='Comoros';
#'                            'Czech Rep.'='Czech Republic';
#'                            'Dominican Rep.'='Dominican Republic';
#'                            'Burma'='Myanmar';
#'                            'UK'='United Kingdom';
#'                            'USA'='United States of America';
#'                            'N. Zealand'='New Zealand';
#'                            'S. Korea'='South Korea';
#'                            'T. & Tobago'='Trinidad and Tobago'")
#' 
#' 
#' #remove rows for presidential elections, to avoid duplicate rows.
#' desaw <- desaw[which(desaw$presidential!=1),]
#' desaw$election_year <- 1 #can be used as a elecetion year dummy later
#' desaw <- merge(desaw,Maddison,by.x=c("country","year"),by.y=c("Country","Year"),all=TRUE)
#' 
#' #Identify rows which have information from a preceding election
#' require(data.table)
#' library(zoo)
#' desaw <- data.table(desaw)
#' setkey(desaw,country, year)
#' desaw[,ccode:=na.locf(ccode,na.rm=FALSE),by=country]
#' 
#' #Any rows still NA on ccode are rows without any information from an election.
#' #Remove these to speed up the following functions.
#' desaw <- desaw[which(is.na(desaw$ccode)==FALSE),]
#' 
#' #Fill in missing entries with information from previous
#' #election for the variables used in the analysis
#' desaw[,':='(tier1_avemag=na.locf(tier1_avemag,na.rm=FALSE),
#'             region3=na.locf(region3,na.rm=FALSE),
#'             regime=na.locf(regime,na.rm=FALSE)),
#'       by=country]
#' desaw$election_year[which(is.na(desaw$election_year)==TRUE)] <- 0
#' 
#' #Create lag and difference -variables
#' desaw[,':='(GDPpc_lag=c(NA,GDPpc[-length(GDPpc)]),
#'             population_lag=c(NA,Population[-length(Population)]),
#'             election_lag=c(NA,election_year[-length(election_year)])),
#'       by=country]
#' 
#' desaw$growth <- desaw$GDPpc - desaw$GDPpc_lag
#' 
#' desaw$tier1_avemag[which(desaw$tier1_avemag==-99)] <- NA
#' 
#' 
#' #Control for an outlier
#' desaw$outlier <- ifelse(desaw$tier1_avemag==max(na.omit(desaw$tier1_avemag)),1,0)
#' 
#' #OLS: Large districts are good for economic growth.
#' #There are indications that the year after an election is bad
#' summary(lm(growth ~ log(population_lag) + log(GDPpc_lag)
#'            + log(tier1_avemag) + factor(election_year) + factor(outlier)
#'            + factor(election_lag) + factor(region3),
#'            data=desaw))
NULL