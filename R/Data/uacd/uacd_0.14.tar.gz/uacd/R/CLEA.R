#' CLEA - Constituency-Level Elections Archive
#' 
#' @description A repository of detailed election results at the constituency level for lower house legislative elections from around the world.
#' @format Unit of analysis is party/candidate at constituency-level for 86 countries between 1788 - 2013. There are 687960 rows and 59 columns.
#' For full documentation, see \url{http://www.unc.edu/~hooghe/data_pp.php}
#' \describe{
#' 
#' \item{release}{Dataset release
#' 
#' 1. 2008 August 15
#' 
#' 2. 2010 February 3
#' 
#' 3. 2010 December 15
#' 
#' 4. 2011 September 14
#' 
#' 5. 2012 December 17
#' 
#' 6. 2013 December 4
#' 
#' }
#' \item{rg}{region}
#' \item{ctr_n}{Country name}
#' \item{ctr}{\href{UN country code}{http://unstats.un.org/unsd/methods/m49/m49.htm}}
#' \item{yr}{Election year}
#' \item{mn}{Election month}
#' \item{sub}{Sub-national geographical unit}
#' \item{cst_n}{Constituency name}
#' \item{cst}{Constituency code
#' 
#' All constituencies in a country are sorted alphabetically, according to their names,
#' and then assigned a constituency code.
#' This code assignment is repeated in each election in the country.
#' Thus, \emph{the same code may or may not belong to the same constituency across elections},
#' depending upon whether redistricting occurs between elections.
#' In the event of special districts for minority populations
#' (e.g., the Maori districts in New Zealand prior to the electoral reform in 1996)
#' or semi-autonomous regions (e.g., Greenland for Danish parliamentary elections)
#' these districts receive the first numeric code following the last alphabetically
#' sorted geographical distric.
#' 
#' In a case where a country uses a multi-tier or mixed electoral system,
#' the CLEA dataset uses the following coding scheme: 
#' 
#' \strong{001-900} Lower-tier electoral districts (in multi-tier PR) or electoral districts where a majoritarian
#' formula is used (in a mixed electoral system)
#' 
#' \strong{901-999} Upper-tier electoral districts (in multi-tier PR) or electoral districts where
#' PR is used (in a mixed electoral system). If a country uses a single-tier system,
#' only constituency codes for lower-tier electoral districts are used.
#' 
#' }
#' \item{mag}{Number of seats allocated in a given constituency.}
#' \item{pty_n}{Party name
#' 
#' In several countries, special kinds of party groupings are used in reported election results.
#' For instance, categories such as "miscellaneous right-wing" and "regionalists and separatists"
#' are used in France. For those special categories,
#' their names are used for this variable and unique numeric codes are assigned to each such category.
#' 
#' Independent candidates are handled in two different ways when election results are reported. 
#' or much of the data we have collected,
#' all independent candidates are grouped under a single category.
#' In such cases, "Independents" is used. However, when each and every individual independent candidate
#' is identified and his/her votes received are reported separately in the election returns,
#' "Independent" is used instead. Different numeric codes are assigned with these different methods.
#' 
#' In a few countries, there are independent candidates who are affiliated with a party,
#' but cannot officially stand under its label.
#' As a result, they may be labeled in a manner that reflects both their independent status and their
#' party affiliation (e.g., "Independent Labour" or "Independent Greens").
#' }
#' \item{pty}{Party code.
#' 
#' \strong{0001-3999} Political parties
#' 
#' \strong{3996} None of these candidates (in some countries, voters have the option to express disapproval for all the candidates on the ballot)
#' 
#' \strong{3997} Elected (for several early elections in Iceland and Sweden, the results for political parties are not available)
#' 
#' \strong{3998} No against for uncontested (in Denmark)
#' 
#' \strong{3999} Unknown
#' 
#' \strong{4000} “Others” (i.e., more than two small parties are grouped)
#' 
#' \strong{4001-} Special kinds of ‘others’
#' 
#' \strong{4998} Write-in
#' 
#' 
#' \strong{4999} Blank/Scattering
#' 
#' \strong{5001-5999} Electoral coalitions or alliances between political parties
#' 
#' \strong{6000} "Independents" (i.e., more than two independent candidates are grouped)
#' 
#' \strong{6001-} Independent 1, Independent 2, and so on (i.e., a single unaffiliated candidate), including special kinds of ‘independents’.
#' 
#' 
#' Each party and electoral alliance is assigned a unique numeric code that remains consistent
#' across elections. If a party changes its name,
#' merges with other parties or splits into separate parties,
#' a new numeric code is given to the party that emerges as a result of such changes.
#' 
#' 
#' Party codes for ‘other’ and ‘independent’ are assigned to parties or unaffiliated candidates
#' in each election. This code assignment is repeated in each election in the country.
#' Thus, the same code does not belong to the same minor party or independent candidate across elections.
#' 
#' 
#' Note: In India, there were more than 4,000 independent candidates in several general elections.
#' In such cases, many independent candidates are assigned a five-digit party code.
#' 
#' }
#' \item{can}{Candidate name
#' 
#' Note: For Japan, Taiwan, and Thailand, a numeric code is given instead of the actual candidate name. Full lists of candidate names in original language from these countries are available upon request.
#' }
#' \item{pev1}{Number of eligeble voters (first round)}
#' \item{vot1}{The total number of votes cast for all candidates in a given constituency (first round)}
#' \item{vv1}{The total number of valid votes in a constituency. (first round)
#' 
#' 
#' When voters have multiple votes, the total number of valid votes in a constituency may be larger than the total votes cast or even the number of eligible voters.
#' 
#' 
#' NOTE: In some cases, this variable was calculated from the manually added sum of party votes (PV1) or candidate votes (CV1), if the original sources we collected do not contain information on valid votes but it is confirmed that no party or candidate is missing.
#' }
#' \item{ivv1}{The total number of invalid and spoilt votes in a given constituency. (first round)}
#' \item{to1}{Turnout. The fraction of eligible voters who vote in a given constituency (first round)
#' 
#' NOTE: This is not a turnout rate reported in an official election report. It is our own calculation from dividing VOT1 by PEV1. In some instances, TO1 is greater than 1 when the official results report more votes cast (VOT1) than eligible votes (PEV1).
#' }
#' \item{cv1}{Candidate votes (first round). Total number of votes received by the candidate in a given constituency.
#' This variable was used only if multiple candidates from the same party run for election
#' (for instance, in Japan under the single non-transferable vote electoral system).
#' Otherwise, this variable was set to Missing Data. If there is a runoff election,
#' it indicates the total number of votes received by the candidate in the first-round election.}
#' \item{cvs1}{Candidate vote share (first round).
#' The fraction of total votes received by the candidate in a given constituency.
#' This variable was used only if multiple candidates from the same party run for election
#' (for instance, in Japan under the single non-transferable vote electoral system).
#' Otherwise, this variable was set to Missing Data. If there is a runoff election,
#' it indicates the vote share of the candidates in the first-round election.
#' 
#' NOTE: In some instances, CVS1 is greater than or equal to 1, depending on the officially reported candidate vote totals (CV1).
#' }
#' \item{pv1}{Party votes (first round) Total number of votes received by the party in a given constituency.
#' NOTE: If there are more than two candidates running for election from the same party in a given
#' constituency, the sum of the votes received by all candidates from the same parties is used.
#' Thus, party votes for the same party are repeated as many times in the column of Party Votes as
#' there are candidates from that party.
#' }
#' \item{pvs1}{Party vote share. The fraction of the total votes (VOT1) received by a particular party (first round)
#' In some cases, this variable was calculated by dividing PV1 by VV1 (or if VV1 is not available,
#' the sum of party votes), if the original data sources we collected do not report the party vote share
#' (also see VV1) or if the original data sources have obvious errors in their calculation of the party
#' vote share.
#' 
#' NOTE: Like with PV1, when there are more than two candidates from the same party in a given constituency,
#'  the party vote share of the same party is repeated as many times in the column of Party Vote Share
#'  as there are candidates from that party. Consequently, in some instances PVS1 is greater
#'  than or equal to 1.
#' } 
#' 
#' \item{pev1}{Number of eligeble voters (second round)}
#' \item{vot1}{The total number of votes cast for all candidates in a given constituency (second round)}
#' \item{vv1}{The total number of valid votes in a constituency. (second round)
#' 
#' 
#' When voters have multiple votes, the total number of valid votes in a constituency may be larger than the total votes cast or even the number of eligible voters.
#' 
#' 
#' NOTE: In some cases, this variable was calculated from the manually added sum of party votes (PV1) or candidate votes (CV1), if the original sources we collected do not contain information on valid votes but it is confirmed that no party or candidate is missing.
#' }
#' \item{ivv1}{The total number of invalid and spoilt votes in a given constituency. (second round)}
#' \item{to1}{Turnout. The fraction of eligible voters who vote in a given constituency (second round)
#' 
#' NOTE: This is not a turnout rate reported in an official election report. It is our own calculation from dividing VOT1 by PEV1. In some instances, TO1 is greater than 1 when the official results report more votes cast (VOT1) than eligible votes (PEV1).
#' }
#' \item{cv1}{Candidate votes (second round). Total number of votes received by the candidate in a given constituency.
#' This variable was used only if multiple candidates from the same party run for election
#' (for instance, in Japan under the single non-transferable vote electoral system).
#' Otherwise, this variable was set to Missing Data.}
#' \item{cvs1}{Candidate vote share (second round).
#' The fraction of total votes received by the candidate in a given constituency.
#' This variable was used only if multiple candidates from the same party run for election
#' (for instance, in Japan under the single non-transferable vote electoral system).
#' Otherwise, this variable was set to Missing Data.
#' 
#' NOTE: In some instances, CVS1 is greater than or equal to 1, depending on the officially reported candidate vote totals (CV1).
#' }
#' \item{pv1}{Party votes (second round) Total number of votes received by the party in a given constituency.
#' NOTE: If there are more than two candidates running for election from the same party in a given
#' constituency, the sum of the votes received by all candidates from the same parties is used.
#' Thus, party votes for the same party are repeated as many times in the column of Party Votes as
#' there are candidates from that party.
#' }
#' \item{pvs1}{Party vote share. The fraction of the total votes (VOT1) received by a particular party (second round)
#' In some cases, this variable was calculated by dividing PV1 by VV1 (or if VV1 is not available,
#' the sum of party votes), if the original data sources we collected do not report the party vote share
#' (also see VV1) or if the original data sources have obvious errors in their calculation of the party
#' vote share.
#' 
#' NOTE: Like with PV1, when there are more than two candidates from the same party in a given constituency,
#'  the party vote share of the same party is repeated as many times in the column of Party Vote Share
#'  as there are candidates from that party. Consequently, in some instances PVS1 is greater
#'  than or equal to 1.
#' }
#' \item{seat}{Either the number of seats won by a party (under PR), or whether a party won or not (under SMP or MMP).}
#' \item{elec}{The number of electors chosen in the indirect election. Currently, this applies only to Norway (1822-1903) and Sweden (1866-1908).}
#' \item{ev}{The number of votes for the elected candidates cast by electors in the indirect election. Currently, this applies only to Norway (1822-1903) and Sweden (1866-1908).}
#' \item{vote2}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote3}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote4}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote5}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote6}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote7}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote8}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote9}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote10}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote11}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote12}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote13}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote14}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote15}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote16}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote17}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote18}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#' \item{vote19}{Preferencial vote counts. In Australia and Ireland votes are counted by order of preference. The candidate ranked first is coded PV1 (i.e., party votes first round). If no candidate receives an absolute majority, the candidate with the fewest first-preference votes is eliminated. This counting procedure continues until a candidate receives an absolute majority. Except for Australia and Ireland, this variable is coded missing (-990).}
#'
#'}
#'@details 
#'For all variables, values -992 and -994 have the following interpretations:
#' 
#'
#'\strong{-992} Uncontested Election (i.e., a single candidate contested the election)
#'
#'\strong{-994} Suspended Election
#' @name CLEA
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references  
#' APA (6th edition) 
#' Kollman, K., Hicken, A., Caramani, D., & Backer, D. (2013). Constituency-level elections archive [data file and codebook]. Ann Arbor, MI: Center for Political Studies, University of Michigan [producer and distributor].
#' 
#' 
#' MLA (7th edition) 
#' Kollman, Ken, Allen Hicken, Daniele Caramani, and David Backer. Constituency-Level Elections Archive. Ann Arbor, MI: Center for Political Studies, University of Michigan [producer and distributor], 2013. Web. 4 Dec 2013.
#' 
#' 
#' Chicago (16th edition) 
#' Kollman, Ken, Allen Hicken, Daniele Caramani, and David Backer. 2013. Constituency-Level Elections Archive. Produced and distributed by Ann Arbor, MI: Center for Political Studies, University of Michigan.
#' @source \url{http://www.electiondataarchive.org/index.html}
#' @keywords dataset election party
#' @examples
#' library(uacd)
#' data(CLEA)
NULL