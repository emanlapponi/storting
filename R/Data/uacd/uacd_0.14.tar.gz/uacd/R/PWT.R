#' PWT - Penn World Tables
#' 
#' @description This is PWT 7.1, released on Nov 30, 2012
#' @format A balanced data frame with 11590 rows and 36 columns.
#' It includes 90 countries between 1950 - 2010.
#' 
#' \describe{
#' \item{isocode}{Country name abbreviation, iso format}
#' \item{year}{Year}
#' \item{population}{Population (in thousands)}
#' \item{exchange_us}{Exchange Rate to US$}
#' \item{currency}{National Currency (Local Currency Unit)}
#' \item{ppp_us}{Purchasing Power Parity over GDP (in national currency units per US$)}
#' \item{ppp_gk_current}{Total PPP Converted GDP, G-K method, at current prices (in milions I$)}
#' \item{ppppc_gk_current}{PPP Converted GDP Per Capita, G-K method, at current prices (in I$)}
#' \item{ppppc_average_current}{PPP Converted GDP Per Capita,  average GEKS-CPDW, at current prices (in I$)}
#' \item{ppppc_domestic_absorption_current}{PPP Converted Domestic Absorption Per Capita, average GEKS-CPDW, at current prices (in I$)}
#' \item{ppppc_consumption_current}{Consumption Share of PPP Converted GDP Per Capita at current prices [cgdp], (percent)}
#' \item{gov_ppppc_consumption_current}{Government Consumption Share of PPP Converted GDP Per Capita at current prices [cgdp], (percent)}
#' \item{ppppc_investment_current}{Investment Share of PPP Converted GDP Per Capita at current prices [cgdp], (percent)}
#' \item{gdp_price_level_gk}{Price Level of GDP, G-K method (US = 100)}
#' \item{gdp_price_level_average}{Price Level of GDP, average of GEKS-CPDW (US = 100)}
#' \item{consumption_price_level}{Price Level of Consumption. PPP over consumption / XRAT}
#' \item{gov_consumption_price_level}{Price Level of Government Consumption. PPP over government consumption / XRAT}
#' \item{investment_price_level}{Price Level of Investment. PPP over investment / XRAT}
#' \item{openness_current}{Openness at Current Prices (percent)}
#' \item{gnp_gdp_ratio}{Ratio of GNP to GDP (percent)}
#' \item{relative_ppppc_gk_current}{PPP Converted GDP Per Capita Relative to the United States, G-K method, at current prices, [cgdp](US = 100)}
#' \item{relative_ppppc_average_current}{PPP Converted GDP Per Capita Relative to the United States, average GEKS-CPDW, at current prices, [cgdp2](US = 100)}
#' \item{ppppc_cgi_derived_constant}{PPP Converted GDP Per Capita (Laspeyres), derived from growth rates of c, g, i, at 2005 constant prices}
#' \item{ppppc_domestic_derived_constant}{PPP Converted GDP Per Capita (Laspeyres), derived from growth rates of domestic absorption, at 2005 constant prices}
#' \item{ppppc_constant}{PPP Converted GDP Per Capita (Chain Series), at 2005 constant prices}
#' \item{ppppc_consumption_constant}{Consumption Share of PPP Converted GDP Per Capita at 2005 constant prices [rgdpl]}
#' \item{gov_ppppc_consumption_constant}{Government Consumption Share of PPP Converted GDP Per Capita at 2005 constant prices [rgdpl]}
#' \item{ppppc_investment_constant}{Investment Share of PPP Converted GDP Per Capita at 2005 constant prices [rgdpl]}
#' \item{openness__constant}{Openness at 2005 constant prices (percent)}
#' \item{ppp_adult_constant}{PPP Converted GDP Chain per equivalent adult at 2005 constant prices}
#' \item{ppp_chain_worker_constant}{PPP Converted GDP Chain per worker at 2005 constant prices}
#' \item{ppp_laspeyres_worker_constant}{PPP Converted GDP Laspeyres per worker at 2005 constant prices}
#' \item{ppp_engaged_constant}{PPP Converted GDP Laspeyres person engaged at 2005 constant prices}
#' \item{ppp_employment_constant}{PPP Converted GDP Laspeyres per person counted in total employment at 2005 constant prices}
#' \item{ppp_workhour_constant}{PPP Converted GDP Laspeyres per hour worked by employees at 2005 constant prices}
#' \item{ppp_gdi_constant}{PPP Converted Gross Domestic Income 
#' (RGDPL adjusted for Terms of Trade changes) at 2005 constant prices}
#' 
#' }
#' @name PWT
#' @author Bjørn Høyland, Haakon Gjerløw and Aleksander Eilertsen
#' @keywords dataset economy
#' @source Homepage: \url{https://pwt.sas.upenn.edu/php_site/pwt_index.php}
#' @references Alan Heston, Robert Summers and Bettina Aten, Penn World Table Version 7.1, Center for International Comparisons of Production, Income and Prices at the University of Pennsylvania, Nov 2012.
#' @examples
#' data(PWT)
#' library(ggplot2)
#' # A simple plot of trends in the data
#' ggplot(PWT, aes(year, gov_ppppc_consumption_constant, group = isocode)) +
#' geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Yearly government consumption of PPP converted GDP per capita")
#' 
NULL