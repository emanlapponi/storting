#' Archigos - A Data Base on Leaders 1875 - 2004
#' 
#' @description This dataset contains contains information on the date and manner of entry and 
#' exit of over 3,000 leaders 1872 - 2004 as well as their gender, birth- and death-date, 
#' previous times in office and their post-exit fate. It covers 187 countries. 
#' The leader-spell is the unit of observation. For full documentation see the orginal 
#' \href{http://www.rochester.edu/college/faculty/hgoemans/Archigos.2.9-August.pdf}{codebook}.
#' @format A dataframe with 3042 rows and 21 variables. There is one row per leader.
#' It covers leaders in power in 187 countries during the period 1872 - 2004.
#' \describe{
#' 
#' \item{obsid}{Observation ID. }
#' \item{leadid}{Leader ID. }
#' \item{ccode}{COW numeric country code. }
#' \item{idacr}{COW alpha country code. }
#' \item{leader}{Leader name. }
#' \item{startdate}{Start of tenure spell in d/m/Y format}
#' \item{enddate}{End of tenure spell in d/m/Y format}
#' \item{bornin}{Leader birth date. }
#' \item{died}{Leader death date. }
#' \item{eindate}{Start of tenure spell in Y-m-d format}
#' \item{eoutdate}{End of tenure spell in Y-m-d format}
#' \item{entry}{Identifies how the leader came to power. {\strong{0)}} Through regular means
#' {\strong{1)}} Through irregular means {\strong{2)}} Directly imposed by another state.}
#' \item{exit}{Identifies how the leader lost power. {\strong{1)}} Through regular means
#' {\strong{2)}} Leader died of natural cause while in power {\strong{2.1)}} Leader retired due to ill health.
#' {\strong{2.2)}} Leader lost office as a result of suicide.
#' {\strong{3)}} Leader lost power through irregular means
#' {\strong{4)}} Leader deposed by another state
#' {\strong{-888)}} Leader still in power }
#' \item{exitcode}{Identifies in more detail how the leader lost power.
#' {\strong{0)}} Through regular means
#' {\strong{1)}} Leader lost power as a result of domestic popular protest with foreign support
#' {\strong{2)}} Leader lost power as a result of domestic popular protest without foreign support
#' {\strong{3)}} Leader removed by domestic rebel forces with foreign support
#' {\strong{4)}} Leader removed by domestic rebel forces without foreign support
#' {\strong{5)}} Leader removed by domestic military actors with foreign support
#' {\strong{6)}} Leader removed by domestic military actors without foreign support
#' {\strong{7)}} Leader removed by other domestic government actors with foreign support
#' {\strong{8)}} Leader removed by other domestic government actors without foreign support
#' {\strong{9)}} Leader removed through the threat or use of foreign force
#' {\strong{11)}} Leader removed through assassination by unsupported individual
#' {\strong{16)}} Leader removed in a power struggle within military, short of coup, i.e. without changing institutional features such as a military council or junta
#' {\strong{111)}} Leader removed in an irregular manner through other means or processes
#' }
#' \item{prevtimesinoffice}{This variable counts the leader's previous times in office. }
#' \item{posttenurefate}{Post tenure fate.
#' {\strong{-999)}} Missing because lost once in 2004, before 31 December. No year has passed.
#' {\strong{-888)}} Missing because the leader is still in power
#' {\strong{-777)}} Missing because the leader died a natural death, up to six months after losing once.
#' {\strong{-666)}} Missing because no information could be found.
#' {\strong{0)}} OK
#' {\strong{1)}} Exile
#' {\strong{2)}} Imprisonment (including house arrest)
#' {\strong{3)}} Death }
#' \item{gender}{Gender. {\strong{0)}} Male
#' {\strong{1)}} Female }
#' \item{borndate}{Exact date of birth.}
#' \item{yrborn}{Year of birth.}
#' \item{deathdate}{Exact date of death. }
#' \item{yrdied}{Year of death.}
#' 
#' }
#' @name Archigos
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen 
#' @references Goemans, Gleditsch, Chiozza (2009). 
#' "Introducing Archigos: A Data Set of Political Leaders," Journal of Peace Research, 46(2), (March) 2009: 269-183.
#' @keywords dataset leaders cabinet
#' @source Project homepage: \url{http://www.rochester.edu/college/faculty/hgoemans/data.htm}.
#' @seealso ArchigosTimeVarying ArchigosElectionDates
#' @examples 
#' #This example shows some simple descriptive statistics of state leaders
#' data(Archigos)
#' 
#' Archigos$exit[which(Archigos$exit==-666)] <- NA
#' Archigos$entry[which(Archigos$entry==-666)] <- NA
#' 
#' Archigos$startyear <- as.numeric(
#' as.character(sapply(strsplit(Archigos$startdate, "/"),"[[",3)))
#' Archigos$age <- Archigos$startyear - Archigos$yrborn
#' 
#What matters for leader age?
#' library(MASS)
#' summary(glm.nb(age ~ gender + factor(entry) + poly(startyear,3), data = Archigos))
#' 
#' #This shows how leader age has increased
#' library(ggplot2)
#' ggplot(Archigos, aes(y=age,x=startyear)) +
#'   geom_point() + stat_smooth(method=loess,lwd=1)
#' 
#' #Plot the age density for male and females and do a t-test to check
#' #for ny significant differences
#' Maledensity <- density(na.omit(Archigos$age[Archigos$gender=="M"]))
#' Femaledensity <- density(na.omit(Archigos$age[Archigos$gender=="F"]))
#' plot(Maledensity,main="Age density",
#'      ylim=c(min(Femaledensity$y),max(Femaledensity$y)))
#' lines(Femaledensity,lty="dashed",col="blue")
#' abline(v=mean(Maledensity$x))
#' abline(v=mean(Femaledensity$x),lty="dashed",col="blue")
#' legend("topleft",lty=c("solid","dashed"),col=c("black","blue"),
#'        legend=c("Male","Female"),bty="n",cex=0.8)
#' text(66,0.045,"Means",cex=0.8)
#' 
#' #There is no significant age difference between male and female leaders
#' with(Archigos, t.test(age[gender=="M"],age[gender=="F"]))
#' 
NULL