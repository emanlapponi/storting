#' ACI MEPV  - Armed Conflict and Intervention Datasets: Major Episodes of Political Violence, 1946-2012 from Marshall (2013).
#' 
#' @description This dataset contains information on Major Episodes of Political Violence, 1946-2012, 
#' from the Center for Systemic Peace. This is the Annual Set version and lists annual, cross-national, 
#' time-series data on interstate, societal, and communal warfare magnitude scores for all countries.
#' For full documentation, see the orginal \href{http://www.systemicpeace.org/inscr/MEPVcodebook2012.pdf}{codebook}.
#' The dataset is a copy of MEPV2012.sav downloaded from The Center for Systemic Peace \href{http://www.systemicpeace.org/inscr/inscr.htm}{website}.
#' @format A dataframe with 9057 rows and 20 variables.
#' It includes 167 countries and the longes time series goes from 1946 - 2012.
#' The mean number of countries per year is 135. The mean number of years per country is 66.
#' \describe{
#' \item{scode}{INSCR standard alpha-character country code.}
#' \item{ccode}{INSCR standard numeric country code. }
#' \item{country}{INSCR standard country name. }
#' \item{year}{Year. }
#' \item{ind}{Independent State indicator: 0) non-independent state; 1) independent state.}
#' \item{intind}{Magnitude score of episode of warfare episode occurring in a non-independent state and/or associated with an 
#' attempt to gain independence for the state (i.e., war of independence). Scale: 1 (lowest) to 10 (highest) for each MEPV; 
#' Magnitude scores for multiple MEPV are summed; 0 denotes no episodes.}
#' \item{intviol}{Magnitude score of episode(s) of international violence involving that state in that year. 
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{intwar}{Magnitude score of episode(s) of international warfare involving that state in that year. 
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{civviol}{Magnitude score of episode(s) of civil violence involving that state in that year. 
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{civwar}{Magnitude score of episode(s) of civil warfare involving that state in that year. 
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{ethviol}{Magnitude score of episode(s) of ethnic violence involving that state in that year. 
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{ethwar}{Magnitude score of episode(s) of ethnic warfare involving that state in that year.
#' Scale: 1 (lowest) to 10 (highest) for each MEPV; Magnitude scores for multiple MEPV are summed; 0 denotes no episodes. }
#' \item{inttot}{Total summed magnitudes of all interstate MEPV. INTTOT = INTVIOL + INTWAR. }
#' \item{civtot}{Total summed magnitudes of all societal MEPV. CIVTOT = CIVVIOL + CIVWAR + ETHVIOL + ETHWAR.}
#' \item{actotal}{Total summed magnitudes of all (societal and interstate) MEPV. ACTOTAL = INTTOT + CIVTOT. }
#' \item{nborder}{Number of neighboring states sharing a border with the identified state. }
#' \item{region}{Code designation for affective geopolitical region. The variables also includes codes for states 
#' straddling two or more regions. These are designated by a two-digit combination of the single-digit region codes in which
#' they are included; for states straddling three regions (SUD and ZAI) a unique 
#' two-digit region code has been assigned. 0) European (East/West); 1) West Africa; 
#' 2) North Africa; 3) East Africa; 4) South Africa; 5) Middle East; 6) South-central Asia; 7) East Asia; 
#' 8) South America; 9) Central America.}
#' \item{nregion}{Number of states in the designated geopolitical region. }
#' \item{afrreg}{Dummy variable for African countries}
#' \item{regcon}{Region dummy. 0) European (East/West); 1) West Africa; 
#' 2) North Africa; 3) East Africa; 4) South Africa; 5) Middle East; 6) South-central Asia; 7) East Asia; 
#' 8) South America; 9) Central America. }
#' }
#' @name ACImepv
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references  Marshall (2013). "Major Episodes of Political Violence, 1946-2012".  
#' @source Marshall (2013) at Center for Systemic Peace online: \url{http://www.systemicpeace.org/inscr/inscr.htm}.
#' @seealso PolityIV PolityIVcoups 
#' @keywords dataset violence conflict
#' @examples
#' # This example shows how to use ACImepv together with other datasets, 
#' # by merging ACImepv with the DD and PWT datasets. It shows how the sum 
#' # of societal episodes of political violence differs for 
#' # different types of democratic regimes, controlling for 
#' # population and level of economic development.
#' 
#' #Loading packages and datasets 
#' library(MASS);library(car); library(lmtest); library(sandwich)
#' data(DD); data(ACImepv); data(PWT)
#' 
#' #Merging datasets, subsetting democratic countries and recoding variables 
#' data <- merge(ACImepv, DD, by.x=c("ccode", "year"), by.y=c("cowcode", "year")) 
#' data <- merge(data, PWT, by.x=c("scode", "year"), by.y=c("isocode", "year"), all.x=TRUE)
#' democracies <- subset(data, democracy==1) 
#' democracies$StartYear <- democracies$year - min(democracies$year) 
#' democracies$regime <- recode(democracies$regime, "0='Parl'; 1='Mixed'; 2='Pres'")
#' democracies$regime <- as.factor(democracies$regime)
#' 
#' #Running count model (negative binomial)
#' negbinModel <- glm.nb(civtot ~ as.factor(regime) + StartYear + 
#' log(population) + log(ppp_us), data=democracies)
#' #Adding heteroskedasticity and autocorrelation consistent standard errors
#' coeftest(negbinModel, vcov=vcovHAC(negbinModel, type="HAC")) 
#'
#' #Plotting the effect 
#' termplot(negbinModel, se=TRUE, term=1,, col.se="blue",col.term=2, 
#'    lwd.term=2, lty.se=2, xlab="Regime type", 
#'    ylab="Partial change in societal MEPV", 
#'    main="Effect of regime type on societal MEPV", 
#'    data=democracies)
NULL 