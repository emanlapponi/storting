#' Polity IV -  The Polity IV Project Annual Time-Series, Marshall, Gurr and Jaggers (2013).
#' 
#' @description This dataset contains political regime characteristics and transitions 
#'from The Polity IV Project Annual Time-Series covering 192 countries for the time period 1800 - 2012.
#'For full documentation, see \url{http://www.systemicpeace.org/inscr/p4manualv2012.pdf}. 
#'The dataset is a copy of p4v2012.sav downloaded from The Center for Systemic Peace website.
#' @format An unbalanced dataframe with 16560 rows and 36 variables.
#' It includes 192 countries between 1800 - 2012.
#' Mean number of years per country is 86, standard deviation is 64 and median is 54.
#' \describe{
#' 
#' \item{cyear}{Country Year. A unique identifier for each country year, consisting of the country code (ccode)
#' followed by the year.} 
#' \item{ccode}{Numeric Country Code. Derived from the Correlates of War's listing of members of the interstate system.}
#' \item{scode}{Alpha Country Code. Derived from the Correlates of War's listing of members of the interstate system.}
#' \item{country}{Country name.}
#' \item{year}{Year Coded. Polity codes are assigned according to the regime in place on December 31 of the year coded.}
#' \item{flag}{Indicates the general confidence in the component variable scores from the coders' perspective. A "0" 
#' code indicates reasonable confidence. A "1" code indicates that codings covering a period of up to five years since a recent 
#' polity change are considered tentative. A "2" code indicates that information is limited and that there are reservations 
#' regarding the code assigned.}
#' \item{fragment}{Polity Fragmentation. Measures the existence of a separate polity, or polities,
#' comprising substantial territory and population within the recognized borders of the state and over 
#' which the coded polity exercises no effective authority. The variable ranges from 0 (no fragmentation) 
#' to 3 (serious fragmentation).}
#' \item{democ}{Institutionalized Democracy. An additive eleven-point scale (0-10) that measures a country´s 
#' degree of democracy. }
#' \item{autoc}{Institutionalized Autocracy. An additive eleven-point scale (0-10) that measures a country´s degree of 
#' autocracy.}
#' \item{polity}{Combined Polity Score. A combination of DEMOC and AUTOC ranging from -10 (most autocratic) to +10
#' (most democratic). } 
#' \item{polity2}{Revised Combined Polity Score. A modified version of the POLITY variable in order 
#' to facilitate the use of the Polity scale regime measure in time-series analyses.}
#' \item{durable}{Regime Durability. The number of years since the most recent regime change 
#' (defined by a threepoint change in the POLITY score over a period of three years or less) or the end of 
#' transition period defined by the lack of stable political institutions (denoted by a standardized authority score).}
#' \item{xrreg}{Regulation of Chief Executive Recruitment. Divided into three categories: 1) Unregulated; 2)
#' Designational/Transitional; and 3) Regulated. }
#' \item{xrcomp}{Competitiveness of Executive Recruitment. Divided into three categories: 1) Selection; 2)
#' Dual/Transitional; and 3 Election. }
#' \item{xropen}{Openness of Executive Recruitment. Divided into four categories: 1) Closed; 
#' 2) Dual Executive–Designation; 3) Dual Executive–Election; and 4) Open. }
#' \item{xconst}{Executive Constraints (Decision Rules). Divided into seven categories: 1) Unlimited Authority;
#'  2) Intermediate Category; 3) Slight to Moderate Limitation; 4) Intermediate Category;
#' 5) Substantial Limitations; 6) Intermediate Category; and 7) Executive Parity or Subordination. }
#' \item{parreg}{Regulation of Participation. Divided into five categories: 1) Unregulated; 2) Multiple Identity;
#' 3) Sectarian; 4) Restricted; and 5) Regulated. }
#' \item{parcomp}{Executive Recruitment. Divided into five categories: 0) Not Applicable; 1) Repressed;
#' 2) Suppressed; 3) Factional; 4) Transitional; and 5 Competitive. }
#' \item{exrec}{A concept variable which combines information presented in three component variables: 
#' \code{xrreg}, \code{xrcomp}, and \code{xropen}}
#' \item{exconst}{Executive Constraints.  A concept variable which is identical to \code{xconst} }
#' \item{polcomp}{Political Competition. A concept variable  which combines information presented in 
#' two componentvariables: \code{parreg} and \code{parcomp}}
#' \item{prior}{Prior Polity Code.  Regime \code{polity} code immediately prior to the regime \code{edate} denoting a regime
#' change in the target \code{year} or the beginning year in a multi-year regime change.}
#' \item{emonth}{Polity End Month. Two-digit number denoting the ending month of the previous polity. }
#' \item{eday}{Polity End Day. Two-digit number denoting the ending day of the previous polity}
#' \item{eyear}{Polity End Year.  Four-digit number denoting the ending year of the previous polity}
#' \item{interim}{Interim Polity Code. Divided into four categories: 1) regimes changes within a single year; 2) a “transition”
#' period of three years or less while a new Polity is being established; 3) an “interruption” period of any 
#' length while a Polity remains under foreign authority; and 4) an “interregnal” 
#' period with a collapse of central authority.}
#' \item{eprec}{End Date Precision. 1) Exact Date; 2) Assigned Date; 3) Approximate Date;
#' 4) Missing Date; 9) Unkown. }
#' \item{bmonth}{Polity Begin Month. Two-digitnumber denoting the beginning month of the next, or “post” polity. }
#' \item{bday}{Polity Begin Day. Two-digit number denoting the beginning dayof the next, or “post” polity. }
#' \item{byear}{Polity Begin Year. : Four-digit number denoting the beginning year of the next, or “post” polity. }
#' \item{bprec}{Begin Date Precision. 1) Exact Date; 2) Assigned Date; 3) Approximate Date;
#' 4) Missing Date; 9) Unkown.}
#' \item{post}{Post Polity Code. Regime \code{polity} code immediately after the regime \code{bdate} denoting a regime
#' change in the target \code{year}.}
#' \item{change}{Total change in \code{polity} value. Net difference between \code{prior}
#' (the last recorded \code{polity} value)
#' and \code{post} (new) polity values across a continuous polity change. }
#' \item{d4}{Regime Transition Completed. A flag variable that designates (by code “1") the year
#' of a regime change or the final year of a multi-year regime transition. }
#' \item{sf}{State Failure. A flag variable that designates (by code “1") every year during which 
#' a Polity is considered to be in a condition of “complete collapse of central authority” or “state failure”. }
#' \item{regtrans}{Regime Transition. Measures if - and to what degree - a country has undergone a democratic or 
#' autocratic regime transition.}
#' 
#'  } 
#' @name PolityIV
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Marshall, Gurr and Jaggers (2013). “Political Regime Characteristics and Transitions, 1800-2012”. 
#' @source Marshall, Gurr and Jaggers at Center for Systemic Peace online: 
#' \url{http://www.systemicpeace.org/inscr/inscr.htm}.
#' @seealso PolityIVcoups ACImepv DD 
#' @keywords dataset regime 
#' @examples
#' 
#' #This example shows how to merge PolityIV with ParlGov.
#' #Since most countries in ParlGov are quite democratic,
#' #there is very little variaton on the variables in PolityIV after the merge.
#' 
#' data(PolityIV)
#' data(ParlGov)
#' library(countrycode)
#' ParlGov <- ParlGov[which(ParlGov$DecemberandCensored> 0 & ParlGov$NewCab==1),]
#' ParlGov$ccode <- countrycode(ParlGov$country_name_short,"iso3c","cown",warn=TRUE)
#' PolityDem <- merge(ParlGov,PolityIV, by=c("ccode","year"),all.x=TRUE)
#' 
#' summary(PolityDem$polity2)
NULL 