#' GabelHuber  -  Party left-right positions from Gabel and Huber (2000). 
#' 
#' @description This dataset contains data on party left-right positions from manifestos from Gabel and Huber (2000).
#' For full documentation, see \url{http://www.columbia.edu/~jdh39/Site/Data.html}. 
#' 
#' @format A dataframe with 1332 rows and 26 variables.
#' It includes 30 parties from 17 countries over the period 1945 - 1992.
#' 
#' \describe{
#' 
#' \item{country}{A numeric index to identify the country (not all countries are included in data set). }
#' \item{lh_c}{pro decentralization of decisions vs. anti}
#' \item{lh_e}{environment over growth vs. growth over environment.}
#' \item{lh_f}{pro friendly relations USSR vs. anti.}
#' \item{lh_p}{pro public ownership vs. anti.}
#' \item{lh_r}{anticlerical vs. proclerical}
#' \item{lh_s}{pro permissive social policy vs. anti.}
#' \item{lh_t}{increase services vs. cut taxes}
#' \item{lh_u}{pro urban interests vs. anti.}
#' \item{c_m}{Castles and Mair party locations. }
#' \item{h_i}{Huber and Inglehart party locations.}
#' \item{vote}{Unkown }
#' \item{seat}{Seat share.}
#' \item{party}{Party }
#' \item{date}{Date. year-month election. }
#' \item{year}{Election year. }
#' \item{wvs}{Mean left-right position of party supporters using most proximate WVS.}
#' \item{eurob}{Mean left-right position of party supporters using most proximate Eurobarometer.}
#' \item{h_g_11}{11 point left-right party position estimated using Huber/Gabel vanilla method on MRG data.}
#' \item{h_g_10}{10 point left-right party position estimated using Huber/Gabel vanilla method on MRG data.}
#' \item{lb_11}{11 point left-right party position estimated using Laver-Budge method on MRG data.}
#' \item{lb_10}{10 point left-right party position estimated using Laver-Budge method on MRG data.}
#' \item{lg_11}{10 point left-right party position estimated using Laver-Garry method on MRG data.}
#' \item{lg_10}{11 point left-right party position estimated using Laver-Garry method on MRG data.}
#' \item{ptyOld}{Party.}
#' \item{_merge}{Unkown. Not in codebook}
#' }
#' 
#' @name GabelHuber
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Gabel and Huber 2000.
#' @seealso BaldwinHuber HuberInglehart CastlesMair
#' @keywords dataset party position 
#' @examples
#' data(GabelHuber)
#' library(corrgram)
#' 
#' #Investigate correlation between different left-right positions.
#' corrgram(GabelHuber[,c("h_i","c_m","h_g_11","h_g_10","lb_11","lb_10",
#'                        "lg_11","lg_10")],
#'          upper.panel=panel.conf,lower.panel=panel.pie)
#' 
NULL 