#' StromMuller - The Comparative Parliamentary Data Archive
#' 
#' @description This is the The Comparative Parliamentary Data Archive dataset.
#' @format A dataframe with 424 rows and 197 variables.
#' Each row is a unique government. It covers 17 countries between 1945 - 2000.
#' \describe{
#' 
#' \item{Country}{Country code. Original: v001x: 01 Austria, 02 Belgium, 03 Denmark, 04 Finland, 05 France, 06 Germany, 07 Greece, 08 Iceland, 09 Ireland, 10 Italy, 11 Luxembourg, 12 the Netherlands, 13 Norway, 14 Portugal, 15 Spain, 16 Sweden, 17 United Kingdom}
#' \item{Cabinet_code}{Country code followed by cabinet number code. Original: v002x}
#' \item{Cabinet}{Cabinet name. Original: v003x}
#' \item{Date_in}{Inauguration date. Original: v004x}
#' \item{Date_out}{Date cabinet left office. Original: v005x}
#' \item{Start_Decade}{20th century decade cabinet started. Original: v030y}
#' \item{End_Decade}{20th century decade cabinet ended. Original: v030y2}
#' \item{Post_Election_Cabinet}{Post election cabinet, 1=Yes 0=No. Original: v040y}
#' \item{Max_Possible_Cab_Duration}{Max possible cabinet duration in days. Original: v041y}
#' \item{Absolute_No._Parl_Parties}{Absolute number of parties in parliament. Original: v042y}
#' \item{Effective_No._Parl_Parties}{Effective number of parties in parliament. Original: v043y}
#' \item{Bargaining_Power_Fragmentation}{Parliament bargaining power fragmentation index. Original: v044y}
#' \item{Cabinet_Bargaining_Power_Frag}{Cabinet bargaining power fragmentation index. Original: v044y2}
#' \item{Largest_Party_Seat_Share}{Larges party seat share. Original: v045y}
#' \item{Bargaining_Power_of_Largest_Party}{Larges party's bargaining power in Banzhaf index. Original:v046y}
#' \item{Minority_Situation_in_Parliament}{Minority situation in parliament, 1=Yes 0=No. Original: v0047y}
#' \item{Non_partisan_cabinet}{Non partisan cabinet, 1=Yes 0=No. Original: v048y}
#' \item{Coalition_Cabinet}{Coalition cabinet, 1=Yes 0=No. Original: v049y}
#' \item{Cabinet_Seat_Share}{Cabinet seat share in percentage-points. Original: v050y}
#' \item{Number_of_Cabinet_Parties}{Number of parties in cabinet. Original: v051y}
#' \item{Change_in_Cabinet_Parties}{Change in cabinet parties. 1 = Increase, 0 =No change, -1 = Decrease. Original: v051y2}
#' \item{Max_Bargaining_Power_Pty_in_Cab}{Max bargaining power pty in cabinet, 1=Yes 0=No. Original: v052y}
#' \item{Single_Party_Majority_Cabinet}{Single party majority cabinet, 1=Yes 0=No. Original: v053y}
#' \item{Single_Party_Minority_Cabinet}{Single party minority cabinet, 1=Yes 0=No. Original: v054y}
#' \item{Minority_Coalition}{Minority coalition cabinet, 1=Yes 0=No. Original: v055y}
#' \item{Majority_Cabinet}{Majority coalition cabinet, 1=Yes 0=No. Original: v056y}
#' \item{Minimal_Winning_Coalition}{A minimal winning coalition, 1=Yes 0=No. Original: v057y}
#' \item{Surplus_Majority_Cabinet}{A surplus majority cabinet, 1=Yes 0=No. Original: v058y}
#' \item{Government_Type}{Government type. 1 = Minority, 2 = Minimal winning coalition, 3 = Surplus. Original: v058y2}
#' \item{Number_of_Ministries}{Number of ministries. Original: v059y}
#' \item{Change_in_Number_of_Ministries}{Change in number of ministries, Original: v059y2. 1 = Increase, 0 = No change, -1 = Decrease.}
#' \item{Number_of_Cabinet_Members}{Number of people that are members of cabinet. Original: v060y}
#' \item{Change_in_Number_of_Ministers}{Change in number  of peoples that are members of cabinet. 1 = Increase, 0 = No change, -1 Decrease. Original: v060y2}
#' \item{Disproportionality_Index}{Disproportionality index. Original: v061y}
#' \item{Weighted_Disproportionality_Index}{Disproportionality index, weighted. Original: v062y}
#' \item{Watchdog_junior_ministers}{Watchdog junior ministries, 1=Yes 0=No. Original: v063y}
#' \item{Extremist_Party_Seat_Share}{Extremist party seat share in percentage. Original: 080y}
#' \item{Parliamentary_Preference_Range}{Parliamentary preference range in points. Original: v081y}
#' \item{Polarization_(BP_Weighted)}{BP weighted polarization manifesto points.
#' Polarization is based on the following equation:
#' 
#' \deqn{\sqrt{\sum_{i=1}^{n} b_i (x_i - \bar{x}_i)^2}}{%
#' \sum_{i=1}^{n} b_i (x_i - \bar{x}_i)^2}
#' 
#' b is for bargaining power of party i, x is the left-right position of party i,
#' and x bar is the weighted average of left-right positions of all parties. Original: v082y}
#' \item{Effective_N_of_Issue_Dimens}{Effective number of issue dimensions. Original: v083y}
#' \item{No_Core_Party}{1=No dominant dimension 0=Dominant dimension. Original: v084y}
#' \item{Median_Party_Bargaining_Power}{Bargaining power of median party in Banzhaf index. Original: v085y}
#' \item{Largest_Party_Distance_to_Median}{Largest party distance to median in manifesto points. Original: v086y}
#' \item{Cabinet_Preference_Range}{Cabinet preference range in manifesto points. Original: v088y}
#' \item{Median_Party_(1st_Dim)_in_Cab}{Is 1st dimension's median party in cabinet, 1=Yes 0=No. Original: v089y}
#' \item{Median Party_(2nd_Dim)_in_Cab}{Is 2nd dimension's median party in cabinet, 1=Yes 0=No. Note: Experts coded Denmark, France, Greece as having 1 dim., for these countries, this variable is coded with the 2nd dim equaling the 1st dim. Original: v090y}
#' \item{Connected_Cab}{A connected cabinet, 1=Yes 0=No. Original: v091y}
#' \item{Minimal_Winning_Connected_Cab}{A minimal winning connected cabinet, 1=Yes 0=No. Original: v091y2}
#' \item{Conservative_Cab}{Cabinet majority from conservative bloc, 1=Yes 0=No. Original: v092y}
#' \item{Socialist_Cab}{Cabinet majority from socialist bloc, 1=Yes 0=No. Original: v093y}
#' \item{List_PR}{Is the electoral system "List PR", 1=Yes 0=No. Original: v120y }
#' \item{Lower_Chamber_Only_Decides_Leg}{Lower chamber only decides legislature, 1=Yes 0=No. Original: v121y}
#' \item{Supermajority_for_Const_Amend}{Supermajority needed for constitutional amendments, 1=Yes 0=No. Original: v122y}
#' \item{Strong_Second_Chamber}{Strong second chamber, 1=Yes 0=No. Original: v123y}
#' \item{Weak_Second_Chamber}{Weak second chamber, 1=Yes 0=No. Original: v124y}
#' \item{Bicameralism}{Bicameralism, 1=Yes 0=No. Original: v124y2}
#' \item{Opposition_Influence}{Opposition influence. Coded as in Laver-Hunt, except Iceland. Original: v125y}
#' \item{Positive_Parliamentarism}{Positive parliamentarism, 1=Yes 0=No. Original: v126y}
#' \item{Ex_Ante_Gvt_Program_Screen}{Ex ante government program screen, 1=Yes 0=No. Original: v127y}
#' \item{Abs_Majority_No_confidence}{Absolute majority vote of no confidence, 1=Yes 0=No. Original: v128y}
#' \item{Constructive_No_Confidence}{Constructive vote of no confidence, 1=Yes 0=No. Original: v129y}
#' \item{Cabinet_Rule_Unanimity}{Cabinet rule: Unanimity, 1=Yes 0=No. Original: v130y}
#' \item{Cabinet_Rule_PM_Consensus}{Cabinet rule: PM consensus, 1=Yes 0=No. Original: v131y}
#' \item{Cabinet_Co_decides_Leg}{Cabinet co-decides legislature, 1=Yes 0=No. Original: v132y}
#' \item{PM_Cabinet_Powers}{PM cabinet powers, 1 point each of 7 PM cabinet powers. Original: v133y}
#' \item{PM_Dissolution_Powers}{PM dissolution power, 1=Yes 0=No. Original: v134y}
#' \item{PM_Cab_Appt_Power}{PM cabinet appointment power, 1=Yes 0=No. Original: v135y}
#' \item{HoS_Discretionary_Cab_Appt_Role}{HoS discretionary cabinet appointment role, 1=Yes 0=No. Original: v136y}
#' \item{Semi_Presidentialism}{Semi-presidentialism, 1=Yes 0=No. Original: v137y}
#' \item{Junior_Minister_Institution}{Junior minister institution, 1=Yes 0=No. Original: v138y}
#' \item{Size_of_Lower_Chamber}{Number of seats in lower chamber. Original: v139y}
#' \item{Continuation_Rule}{Continuation rule, 1=Yes 0=No. Original: v140y}
#' \item{Prior_Cab_Reg._El._Termination}{Prior cabinet: Regular election termination, 1=Yes 0=No. Original: v160y}
#' \item{Prior_Cab_Technical_Termination}{Prior cabinet: Technical termination, 1=Yes 0=No. Original: v160y1}
#' \item{Prior_Cab_Other_Tech_Termination}{Prior cabinet: Other technical termination, 1=Yes 0=No. Original: v161y}
#' \item{Prior_Cab_Other_Constitutional_Term}{Prior cabinet: Other constitutional termination, 1=Yes 0=No. Original: v161y1}
#' \item{Prior_Cab_Death_of_PM_Term}{Prior cabinet: Death of PM termination, 1=yes 0=No. Original: v161y2}
#' \item{Prior_Cab_Intraparty_Conflict_Term}{Prior cabinet: Intraparty conflict termination, 1=Yes 0=No. Original: v162y}
#' \item{Prior_Cab_Early_Election_Term}{Prior cabinet: Early election termination, 1=Yes 0=No. Original: v163y}
#' \item{Prior_Cab_Conflict_Termination}{Prior cabinet: conflict termination, 1=Yes 0=No. Original: v164y}
#' \item{Prior_Cab_Behavioral_Termination}{Prior cabinet: Behavioral termination, 1=Yes 0=No. Original: v165y}
#' \item{Same_PM_and_Cabinet}{Same PM & cabinet, 1=Yes 0=No. Original: v166y}
#' \item{Same_parties_in_cabinet}{Same parties in cabinet, 1=Yes 0=No. Original: v166y2}
#' \item{Same_PM}{Same PM, 1=Yes 0=No. Original: v166y3}
#' \item{Cabinet_bargaining_duration}{Cabinet bargaining duration in days. Original: v167y}
#' \item{Cabinet_bargaining_duration_add1}{Cabinet bargaining duration in days + 1 (for duration analysis). Original: v167y2}
#' \item{inconclusive_bargaining_round}{Inconclusive bargaining round, 1=Yes 0=No. Original: v168y}
#' \item{N_of_inconclusive_bargaining_rnds}{Number of inconclusive bargaining rounds. Original: v168y2}
#' \item{Coalition_Agreement_Dummy}{Coalition agreement, 1=Yes 0=No. Original: v169y}
#' \item{Coalition_Agreement_Category}{Coalition agreement. 0 = No  1 = Pre, 2 = Post, 3 = IE, 4 = Pre & Post. Original: 169y2}
#' \item{Size_of_agreement_(approx._words)}{Size of agreement in approximate number of words. Original: v169y9}
#' \item{General_procedural_rules_(in_percent)}{General procedural rulas in percentage. Original: v169y10}
#' \item{Policy_specific_procedural_rule_(in_percent)}{Policy specific procedural rules in percent. Original: v169y11}
#' \item{Distribution_of_offices_(in_percent)}{Distribution of offices in percentage. Original: v169y12}
#' \item{Distribution_of_competences_(in_percent)}{Distribution of competences. Original v169y13}
#' \item{Policies_(in_percent)}{Policies in percentage. Original: v169y14}
#' \item{Comprehensive_Policy_Agreement}{Comprehensive policy agreement, 1=Yes 0=No. Original: v170y}
#' \item{Policy_Agreement_Short}{Policy agreement. 0 = No, 1 = Basic, 2 = Comprehensive. Original: v170y2}
#' \item{Policy_Agreement_Long}{Policy agreement. 0 = No, 1 = Few issues, 2 = Many issues, 3 = Comprehensive. Original: v170y3}
#' \item{Coalition_Discipline_in_Legislation}{Coalition discipline in legislation. 1 = Yes always, 2 = Yes, except explicitly exempted, 3 = No, except explicit policies, 4 = No. Original: v171y}
#' \item{Unkown1}{Variable not in codebook. Original: v171y1}
#' \item{Unkown2}{Variable not in codebook. Original: v171y2}
#' \item{Unkown3}{Variable not in codebook. Original: v171y3}
#' \item{Coalition_Discipline_in_Legislation_Alternative}{Coalition discipline in legislation. 1 = Yes always, 2 = Yes, except explicitly exempted, 3 = No. Original: v171y4}
#' \item{Coalition_Discipline_in_Other_Parliamentary_Behavior}{Coalition discipline in other parliamentary behavior. 1 =Yes always, 2 = Yes, except explicitly exempted, 3 = No, except explicit policies, 4 = No. Original: v171yt}
#' \item{Comprehensive_Policy_Agreement_(alt)}{Alternative comprehensive policy agreement, 1=Yes 0=No. Original: v172y}
#' \item{Coalition_Agreement_(alt)}{Alternative coalition agreement, 1=Yes 0=No. Original: v173y}
#' \item{Coalition_Discipline_in_Legislation_(alt)}{Alternative coalition discipline in legislation, Original: v174y. 1 = Yes always, 2 = Yes, except explicitly exempted, 3 = No, except explicit policies, 4 =No}
#' \item{Coalition_Discipline_in_Legislation_Dummy}{Coalition discipline in legislation dummy, 1=Yes 0=No. Original: v174y1}
#' \item{Most_common_CRA}{Most common conflict resolution arena,. 0 = Internal, 1 = Mixed, 2 = External. Original: v176y2}
#' \item{Most_Common_CRA_qualitative}{Qualtitative information on most common conflict resolution arena. IC = Inner cabinet, CaC = Cabinet comm, CoC = Coal comm, Parl = Parl leaders, Pca = Combination of cabinet members & parliamentarians, PS = Party summit, O = Other. Original: v176yt}
#' \item{Serious_CRA}{Serious conflict resolution arena. 0 = Internal, 1 = Mixed, 2 = External. Original: v178y2}
#' \item{Serious_CRA_qualitative}{Qualtitative information on serious conflict resolution arena. IC = Inner cabinet, CaC = Cabinet comm, CoC = Coal comm, Parl = Parl leaders, Pca = Combination of cabinet members & parliamentarians, PS = Party summit, O = Other. Original: v178yt}
#' \item{Relative_Cab_Duration_percent}{Relative cabinet duration in percent. Origianl: v179y}
#' \item{Absolute_Cab_Duration}{Absolute cabinet duration in days. Original: v179y2}
#' \item{Early_Election_(No_Conflict)}{Early election but no conflict, 1=Yes 0=No. Original: v180y}
#' \item{Terminal_event_lag_security}{Lagged terminal event: Security, 1=Yes 0=No. Original: v200y}
#' \item{Terminal_event_lag_Economic}{Lagged terminal event: Economic, 1=Yes 0=No. Original: v201y}
#' \item{Terminal_event_lag_Personal}{Lagged terminal event: Personal, 1=Yes 0=No. Original: v202y}
#' \item{Terminal_event_lag_(Any)}{Lagged terminal event: Any, 1=Yes 0=No. Original: v203y}
#' \item{Critical_Event_Lag}{Lagged critical event, 1=Yes 0=No. Original: v203y2}
#' \item{Electoral_Volatility}{Electoral volatility. Original: v204y}
#' \item{Cabinet_Electoral_Volatility}{Cabinet electoral volatility. Original: v204y2}
#' \item{Inflation_(Cab_Beginning)}{Inflation at cabinet start. Original: v205y}
#' \item{Unemployment_(Cab_Beginning)}{Unemployment at cabinet start. Original: v206y}
#' \item{Growth_(Beginning)}{Growth at cabinet start. Original: v207y}
#' \item{Unemployment_(End)}{Unemployment at cabinet end. Original: v208y}
#' \item{Inflation_(End)}{Inflation at cabinet end. Original: v209y}
#' \item{Growth_(End)}{Growth at cabinet end. Original: v210y}
#' \item{Terminal_events_Opinion_Shock}{Terminal event: Opinnion shock, 1=Yes 0=No. Original: v213y}
#' \item{Terminal_events_security}{Terminal event: Security, 1=Yes 0=No. Original: v214y}
#' \item{Terminal_events_Economic}{Terminal event: Economic, 1=Yes 0=No. Original: v215y}
#' \item{Terminal_events_Personal}{Terminal event: Personal, 1=Yes 0=No. Original: v216y}
#' \item{Critical_Event}{Critical event, 1=Yes 0=No. Original: v216y2}
#' \item{Terminal_Event_Any}{Terminal event: Any, 1=Yes 0=No. Original: v216y3}
#' \item{Government_Termination_Cause}{Governement termination cause, Original: v217y. 0 = Technical Termination, 1 = Conflict Termination, 2 = Voluntary early election}
#' \item{Government_Termination_Regular_Election}{Government termination: regular election, 1=Yes 0=No. Original: v217y2}
#' \item{Government_Termination_Other_Technical}{Government termination: Other technical, 1=Yes 0=No. Original: v217y3}
#' \item{Government_Termination_Early_Election}{Government termination: Early election, 1=Yes 0=No. Original: v217y4}
#' \item{Government_Termination_Voluntary_Early_Election}{Government termination: Voluntary early election, 1=Yes 0=No. Original: v217y5}
#' \item{Government_Termination_Voluntary_Early_Election_lag}{Government termination: Voluntary early election lagged, 1=Yes 0=No. Original: v217y5l}
#' \item{Government_Termination_Discretionar_No_Election}{Government termination: Discretionary no election, 1=Yes 0=No. Original: v217y6}
#' \item{Government_Termination_Technical}{Government termination: Technical, 1=Yes 0=No. Original: v217y7}
#' \item{Government_Termination_Cabinet_defeat_in_parliament}{Government termination: Cabinet defeat in parliament, 1=Yes 0=No. Original: v217y23}
#' \item{Government_Termination_Inter_party_policy}{Government termination: Inter-party policy, 1=Yes 0=No. Original: v217y24}
#' \item{Government_Termination_Inter_party_personal}{Government termination: Inter-party personal, 1=Yes 0=No. Original: v217y25}
#' \item{Government_Termination_Intraparty_Conflict}{Government termination: Intraparty conflict, 1=Yes 0=No. Original: v217y27}
#' \item{Government_Termination_Other_Constitutional_Reason}{Government termination: Other constitutional reason, 1=Yes 0=No. Original: v217y31}
#' \item{Government_Termination_Death_of_PM}{Government termination: Death of PM, 1=Yes 0=No. Original: v217y32}
#' \item{Cabinet_Termination_Voluntary_Enlargment}{Cabinet termination: Voluntary enlargement, 1=Yes 0=No. Original: v218y}
#' \item{Cabinet_Termination_Voluntary_Enlargment_lag}{Cabinet termination: Voluntary enlargement lagged, 1=Yes 0=No. Original: v218yl}
#' \item{Cabinet_El_Performance}{Cabinet termination: electoral performance in percent. Original: v219y}
#' \item{Cabinet_El_Performance_controlling_for_seat}{Cabinet termination: electoral performance in percent controlled for seat share. Original: v219y2}
#' \item{Previous_Cab_All_Parties_Lost_Votes}{Previous cabinet: all parties lost votes, 1=Yes 0=No. Original: v219y3}
#' \item{Previous_Cab_Mixed_Electoral_Fortunes}{Previous cabinet: mixed electoral fortunes, 1=Yes 0=No. Original: v219y4}
#' \item{Previous_Cab_All_Parties_Gained_Votes}{Previous cabinet: all parties gained votes, 1=Yes 0=No. Original: v219y5}
#' \item{Finance_Ministers_Party_Electoral_Performace}{Finance minister's party electoral performance in percent. Original: v220y}
#' \item{Prime_Ministers_Party_Electoral_Performace}{Prime minister's party electoral performance in percent. Original: v221y}
#' \item{Country_Name}{A variable with country names instead of id-codes. This is created by the UACD-team.}
#' 
#'  }
#' @name StromMuller
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Strøm, Kaare; Müller, Wolfgang C. and Bergman, Torbjörn, eds. (2008). Cabinets and Coalition Bargaining: the Democratic Life Cycle in Western Europe. Oxford: Oxford University Press.
#' @source Project homepage: \url{www.pol.umu.se/ccpd}
#' @details The variables have been given more intuitive names. These names approximate variable names in the column "Names" in the original codebook.
#' Spaces are written as a underscore: _. Some of the names were identical, therefore some changes had to be made. The original variable name of all the variables are noted behind "Original" in the list above.
#' There are also three variables in the dataset not mentioned in the codebook. Their original names were v171y1, v171y2 and v171y3. Here they are named Unknown1-3.
#' 
#' Coding decisions for identifying cabinets similar to cabinets in ParlGov:
#' To merge StromMuller with ParlGov, differences in coding of the cabinets had to be identified.
#' These are differences found between the cabinets in StromMuller and ParlGov:
#' 
#' Austria: SM Gorbach II is ParlGov Gorbach III. 
#' SM Klaus II is ParlvGov Klaus III. 
#' ParlGov Klaus II is not in SM. 
#' Eyskens-cabinets written diferently.
#' 
#' Belgium: Martens is similar until number VII. But SM doesn't have ParlGov Martens VII. ParlGov Martens VIII is SM Martens VII, and therefore ParlGov Martens IX is SM Martens VIII
#' 
#' Denmark: Hansen I cabinet is written without "I" in SM.
#' All Rasmussen cabinets are named "Rasmussen N" in ParlGov.
#' Schluter-cabinets are written Schlüter in SM.
#' 
#' Finland: Aho I and II named a and b in SM.
#' "Fieandt" named "Von Fieandt" in SM.
#' Holkeri I and II named a and b in SM.
#' Karjalinen I - III named I, Iia and Iib in SM.
#' Lipponen I named "Lipponen" in SM.
#' There are two Sukseleinen Ic in SM, and they represent Sukseleinen I and II in ParlGov.
#' Sukselainen Ib and IV in SM have different dates then Sukselainen III in ParlGov.
#' Torngren is Törngren in SM.
#' 
#' France: Only fifth republic in SM.
#' SM Barre II is ParlGov Barre III. ParlGov Barre II is not in SM. 
#' SM Juppé is Juppe I in ParlGov, Juppe II is not in SM.
#' ParlGov Mauroy II is not in SM. SM Mauroy II is ParlGov Mauroy III.
#' Messmer III is not in SM.
#' Pompidou V is not in SM.
#' 
#' Germany: ParlGov doesn't have Adenauer VIII og IX, SM do.
#' ParlGov doesn't have Erhard III.
#' ParlGov Kohl IV is SM Kohl V. ParlGov doesn't have SM Kohl IV. ParlGov Kohl V is therefore SM Kohl VI.
#' SM Schmidt IV is not in ParlGov.
#' 
#' Greece: Papandreou A III in ParlGov is not the same as Papandreou III in SM. Papandreou A IV is Papandreou III.
#' SM Karamnlis is ParlGov Karamanlis Kon II. ParlGov Karamanlis Kon I is not in SM.
#' ParlGov Zolotas II is not in SM.
#' 
#' Iceland:SM Oddsson III is not in ParlGov
#' 
#' Ireland: Ahern II and III not in SM.
#' SM Costello II is ParlGov Costello (Unusual coding in ParlGov-data).
#' Parlgov Valera VII - IX is SM Valera VI - VII.
#' 
#' Italy: Amato II is not in SM.
#' Andreotti: Similar until IV. Parlgov IV is not in SM. ParlGov V is SM IV.
#' Berlusconi in SM is Berlusconi I in ParlGov. SM doesn't have the rest of the Berlusconi governments.
#' Craxi II not in SM. D'Alema II is not in SM.
#' ParlGov doesn't have De Gasperi I. Dini II not in SM.
#' ParlGov Moro I and II not in SM. SM Moro II is ParlGov Moro IV, Moro III is Moro V.
#' SM Parri is not in ParlGov.
#' 
#' Luxembourg: SM Dupong I - IV is Parlgov Dupong II - V.
#' 
#' Netherlands: Schermerhorn is not in ParlGov.
#' 
#' Norway: No dissimilarities found.
#' 
#' Portugal: SM Cavaco Silva is Silva in ParlGov.
#' SM Sá Carneiro is Carneiro in ParlGov.
#' ParlGov Soares IV is not in SM.
#' 
#' Spain: Navarro is not in ParlGov.
#' SM Suarez I is not in ParlGov, SM Suárez II and III is ParlGov Suarez I and II.
#' 
#' Sweden: ParlGov Carlsson III is not in SM. SM Carlsson III is ParlGov Carlsson IV.
#' 
#' United Kingdom: ParlGov Churchill III is SM Churchill II
#' 
#' @keywords dataset cabinet election parliament
#' @seealso \link{Portfolio}
#' @examples
#' data(StromMuller)
#' 

#' #Replicate model 2 in table 4.5 in Winter and Dumont in (ed.) Strom, Muller and Bergman:
#' 
#' StromMuller$inconclusive_bargaining_round <-
#' as.factor(as.character(StromMuller$inconclusive_bargaining_round))
#' 
#' summary(glm(inconclusive_bargaining_round ~ factor(Post_Election_Cabinet)
#'             + Max_Possible_Cab_Duration + Absolute_No._Parl_Parties
#'             + Bargaining_Power_Fragmentation,
#'             data=StromMuller[which(StromMuller$Minority_Situation_in_Parliament==1),],
#'             binomial(link = "logit")))
#'
#' # Replicate model 2 in table 4.6 in Winter and Dumont in (ed.) Strom, Muller and Bergman:
#' 
#' library(survival)
#' Model2 <- coxph(Surv(Cabinet_bargaining_duration_add1) ~ factor(Post_Election_Cabinet)
#'                 + Max_Possible_Cab_Duration + Absolute_No._Parl_Parties
#'                 + Bargaining_Power_Fragmentation,
#'                 data=StromMuller[which(StromMuller$Minority_Situation_in_Parliament==1),])
#' summary(Model2)
#' cox.zph(Model2)
#' #Two issues with their model: 1) The proportionality assumption is violated.
#' #2) It assumes that observations from the same country are independent.
#' 
#' #Lets fix 2):
#' 
#' 
#' ClusterModel2 <- (coxph(Surv(Cabinet_bargaining_duration_add1) ~ cluster(Country) +
#' factor(Post_Election_Cabinet) + Max_Possible_Cab_Duration + Absolute_No._Parl_Parties
#'                         + Bargaining_Power_Fragmentation,
#'                         data=StromMuller[which(StromMuller$Minority_Situation_in_Parliament==1),]))
#' cox.zph(ClusterModel2)
#' 
#' #The proportionality violation is now even more severe.
NULL