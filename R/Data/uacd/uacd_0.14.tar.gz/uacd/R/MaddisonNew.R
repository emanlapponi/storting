#' MaddisonNew - New Maddison Project Database
#' 
#' @description This historical data on GDP per capita from the New Maddison Project.
#' @format This is a data frame with 41907 observations and 3 variables.
#' It includes 182 areas (countries and regions) over the period 1 A.D. - 2010.
#' Each area is noted for 229 years, but with several missing country-years.
#' 
#' \describe{
#' \item{Country}{Country}
#' \item{Year}{Year}
#' \item{GDPpc}{GDP per capita in constant 1990 Geary-Khamis dollars}
#' }
#' 
#' @name MaddisonNew
#' @author Bjørn Høyland, Haakon Gjerløw og Aleksander Eilertsen
#' @keywords dataset economy
#' @source Homepage: \url{http://www.ggdc.net/maddison/maddison-project/data.htm}
#' @seealso Maddison
#' @references Bolt, J. and J. L. van Zanden (2013). The First Update of the Maddison Project; Re-Estimating Growth Before 1820. Maddison Project Working Paper 4.
#' @examples
#' data(MaddisonNew)
#' library(ggplot2)
#' MaddisonNew$Year <- as.numeric(as.character(MaddisonNew$Year))
#' MaddisonNew$GDPpc <- as.numeric(as.character(MaddisonNew$GDPpc))
#' Modern <- MaddisonNew[which(MaddisonNew$Year>1946),]
#' ggplot(MaddisonNew, aes(Year, GDPpc, group = Country)) +
#' 
#' geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("GDP per capita through the ages")
#' 
#' ggplot(Modern, aes(Year, GDPpc, group = Country)) +
#' 
#' geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("GDP per capita through the ages")
NULL