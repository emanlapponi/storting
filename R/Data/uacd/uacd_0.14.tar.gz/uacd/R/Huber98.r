#' Huber98  -  portfolio turnover and health expenditures from Huber (1998)
#' 
#' @description This dataset contains data on portfolio turnover and health expenditures from Huber (1998).
#' For full documentation, see \url{http://www.columbia.edu/~jdh39/Site/Data.html}. 
#' 
#' @format A balanced dataframe with 342 rows and 44 variables. 
#' It includes 18 countries in the period 1971 - 1989
#' \describe{
#' \item{country}{Country number. 
#' 
#' 1  Australia
#' 
#' 2	Austria
#' 
#' 3	Belgium
#' 
#' 4	Canada
#' 
#' 5	Denmark
#' 
#' 6	Finland
#' 
#' 7	France
#' 
#' 8	Germany
#' 
#' 10	Iceland
#' 
#' 11	Ireland
#' 
#' 13	Italy
#' 
#' 14	Japan
#' 
#' 15	Luxembourg
#' 
#' 17	Netherlands
#' 
#' 18	New Zealand
#' 
#' 19	Norway
#' 
#' 22	Sweden
#' 
#' 24	UK
#' 
#' }
#' \item{year}{Year.}
#' \item{fee}{Equals 1 if fee-for-service physician payment. }
#' \item{ptyvol}{Party Portfolio Volatility (current year). }
#' \item{idvol}{Ideological Portfolio Volatility (current year). }
#' \item{cabstab}{General Cabinet Instability (current year). }
#' \item{gov_ideol}{Government left-right location, current year.
#' Lower values = Right, Higher values = Left. NB! 0 is missing, not extreme right.  }
#' \item{h_gdp}{Health \% GDP. }
#' \item{docpc}{Unkown. Not in codebook. }
#' \item{lngdp}{Unkown. Not in codebook}
#' \item{popgt65}{Population greater than 65. }
#' \item{medcpi}{Unkown. Not in codebook. }
#' \item{global}{Equals 1 if global budgets are used for hospitals.}
#' \item{pf}{Public finance in health care in \%. }
#' \item{totvol}{Total Portfolio Volatility (current year). }
#' \item{part_instab}{Partisan Cabinet Instability (current year). }
#' \item{laghlth}{Lag of health expenditures. }
#' \item{chghlth}{Change in health expends. }
#' \item{chglngdp}{Unkown. Not in codebook. }
#' \item{chgpop}{Change in population}
#' \item{chgdoc}{Unkown. Not in codebook. }
#' \item{chgpf}{Change in public finance. }
#' \item{chgcpi}{Unkown. Not in codebook. }
#' \item{within}{Within-Party Reshuffles (curren year). }
#' \item{pchg3}{Mean of \code{ptyvol}, 3 previous years. }
#' \item{id3}{Mean of \code{idvol}, 3 previous years. }
#' \item{p1stab3}{Mean of \code{part_instab}, 3 previous years. }
#' \item{totchg3}{Mean of \code{totvol}, 3 previous years. }
#' \item{within3}{Mean of \code{within}, 3 previous years. }
#' \item{cgtotcg3}{Change in \code{totchg3}. \code{totchg3}-\code{totchg3}[_n-1]. }
#' \item{cgwtin3}{Change in \code{within3}. \code{within3}-\code{within3}[_n-1]. }
#' \item{cgpchg3}{Change in \code{pchg3}. \code{pchg3}-\code{pchg3}[_n-1]. }
#' \item{cgid3}{Change in \code{id3}-\code{id3}[_n-1]}
#' \item{cgp1stb3}{Change in \code{p1stab3}. \code{p1stab3}-\code{p1stab3}[_n-1]. }
#' \item{totchg3l}{Lag of \code{totchg3}. }
#' \item{id3l}{Lag of \code{id3} }
#' \item{pchg3l}{Lag of \code{pchg3}. }
#' \item{within3l}{Lag of \code{within3}. }
#' \item{p1stab3l}{Lag of \code{p1stab3}. }
#' \item{pop65l}{Lag of \code{pop65l}. }
#' \item{docpcl}{Lag of \code{docpc}. }
#' \item{pfl}{Lag of \code{pf}. }
#' \item{medcpil}{Lag of \code{medcpi}.}
#' \item{lngdpl}{Lag of \code{lngdp}. }
#' 
#' }
#' 
#' @name Huber98
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Huber 1998. 
#' @seealso BaldwinHuber GabelHuber
#' @keywords dataset economy cabinet position
#' @examples
#' ##This example replicates Hubers Model 6 in Table 2 in the article. 
#' data(Huber98)
#' library(lmtest)
#' 
#'model6 <- lm(chghlth~ laghlth + fee + global + chgpop + chgdoc + chgpf +
#'
#'chgcpi + chglngdp + pop65l + docpcl + pfl + medcpil + lngdpl + within3l +
#'
#'cgwtin3 + pchg3l + cgpchg3 + p1stab3l + cgp1stb3, 
#'                 data=Huber98, subset=year>=1975)
#'  library(AER)               
#' coeftest(model6, vcovHC(model6, type = "HC0"))
#' #Heteroskedasticity consistent standard errors 
NULL  