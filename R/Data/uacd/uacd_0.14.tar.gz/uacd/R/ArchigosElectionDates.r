#' ArchigosElectionDates - Election dates for leaders in Archigos 1919 - 2006 
#' 
#' @description This dataset contains information on election dates for leaders in Archigos dataset for the period 1919 - 2006.
#' It also contains information for the earlier period 1900 - 1918 but the authors note that these 
#' data are not comprehensive or complete. For full documentation see the orginal
#' \href{http://www.rochester.edu/college/faculty/hgoemans/Archigos.2.9-August.pdf}{codebook}.
#' @format A dataframe with 2625 rows and 9 variables. Each rows indicates at least one election.
#' Only elections years are included. It covers 1900 - 2006, but the data for 1900 - 1918 is not complete.
#' \describe{
#' \item{country}{Country name}
#' \item{countrynumber}{Country number}
#' \item{ccode}{Correlates of War country code}
#' \item{year}{Year. }
#' \item{Prezdate1}{Election date for the first presidential election in the given year }
#' \item{Prezdate2}{Election date for the second presidential election in the given year.
#' If there was only one election this year, this is blank. }
#' \item{Parldate1}{Election date for the first parliamentary election in the given year }
#' \item{Parldate2}{Election date for the second parliamentary election in the given year.
#' If there was only one election this year, this is blank.  }
#' \item{Parldate3}{Election date for the third parliamentary election in the given year.
#' If there was only one or two elections this year, this is blank.  }
#' } 
#' @name ArchigosElectionDates
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen 
#' @references Goemans, Gleditsch, Chiozza (2009). 
#' "Introducing Archigos: A Data Set of Political Leaders," Journal of Peace Research, 46(2), (March) 2009: 269-183.
#' @keywords dataset leaders election cabinet
#' @source Project homepage: \url{http://www.rochester.edu/college/faculty/hgoemans/data.htm}
#' @seealso \link{Archigos} \link{ArchigosTimeVarying}
#' @examples 
#' #This example merges ArchigosElectionDates with ParlGov
#' #and makes it easy to investigate differences in coded elections
#' data(ArchigosElectionDates)
#' data(ParlGov)
#' library(countrycode)
#' ParlGov$ccode <- countrycode(ParlGov$country_name_short,
#'                              "iso3c","cown",warn=TRUE)
#' ParlElections <- ParlGov[!duplicated(ParlGov$election_id),]
#' 
#' ArchigosElectionDates <- ArchigosElectionDates[which(
#'   ArchigosElectionDates$ccode== 20 | ArchigosElectionDates$ccode== 200 |
#'     ArchigosElectionDates$ccode== 205 | ArchigosElectionDates$ccode== 210 |
#'     ArchigosElectionDates$ccode== 211 | ArchigosElectionDates$ccode== 212 |
#'     ArchigosElectionDates$ccode== 220 | ArchigosElectionDates$ccode== 225 |
#'     ArchigosElectionDates$ccode== 230 | ArchigosElectionDates$ccode== 235 |
#'     ArchigosElectionDates$ccode== 255 | ArchigosElectionDates$ccode== 290 |
#'     ArchigosElectionDates$ccode== 305 | ArchigosElectionDates$ccode== 310 |
#'     ArchigosElectionDates$ccode== 316 | ArchigosElectionDates$ccode== 317 |
#'     ArchigosElectionDates$ccode== 325 | ArchigosElectionDates$ccode== 338 |
#'     ArchigosElectionDates$ccode== 349 | ArchigosElectionDates$ccode== 350 |
#'     ArchigosElectionDates$ccode== 352 | ArchigosElectionDates$ccode== 355 |
#'     ArchigosElectionDates$ccode== 360 | ArchigosElectionDates$ccode== 366 |
#'     ArchigosElectionDates$ccode== 367 | ArchigosElectionDates$ccode== 368 |
#'     ArchigosElectionDates$ccode== 375 | ArchigosElectionDates$ccode== 380 |
#'     ArchigosElectionDates$ccode== 385 | ArchigosElectionDates$ccode== 390 |
#'     ArchigosElectionDates$ccode== 395 | ArchigosElectionDates$ccode== 740 |
#'     ArchigosElectionDates$ccode== 900 | ArchigosElectionDates$ccode== 920),]
#' 
#' ArchElections <- merge(ParlElections,ArchigosElectionDates,
#'                        by.x=c("ccode","year"),all=TRUE)
#' 
#' ArchElections[which(ArchElections$country_name=="Norway"),c("year","country_name",
#'                                                             "election_date","Parldate1",
#'                                                             "Parldate2","Parldate3")]
#' 
NULL