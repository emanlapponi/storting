#' Chapel Hill expert survey 2006
#' 
#' @description This is the 2006 edition of the Chapel Hill expert opinion survey of party positions. The dataset contains the following variables
#' @format A cross-sectional dataframe with 1765 rows and 42 variables.
#' It includes 174 parties from 24 countries.
#' For full documentation, see \url{http://www.unc.edu/~hooghe/data_pp.php}
#' \describe{
#' 
#' \item{country_id}{country id}
#' \item{party_id}{party id}
#' \item{party}{Abbreviated name of party}
#' \item{expert_id}{expert id}
#' \item{eu_pos}{Party leadership position to european integration, categorized from 1 - 7. The higher value the more in favor of integration. Original name: Q1}
#' \item{eu_salience}{The relative importance of this issue for this party this year. Categorized from 1 - 4 and 4 is most salient, 1 the least. Original name: Q2}
#' \item{eu_dissent}{The degree of party dissent on the issue of european integration. From 1 (extremely united) to 10 (extremely divided).}
#' \item{eu_benefit}{Party leadership stance on whether the country has benefited from EU membership. Original name: Q4. 1 = benefitted, 2 = neither benefitted nor lost, 3 = Not benefitted}
#' \item{ep_power}{Position of the party leadership on the powers of the European Parliament. Higher value indicate more favored. Original name: Q5}
#' \item{internal_market}{Position of party leadership on EU internal market. Higher value indicates more in favor. Original name: Q6}
#' \item{eu_cohesion}{Position of party leadership on EU cohesion policy. Higher value indicate more in favor of cohesion policy. Original name: Q7}
#' \item{eu_foreignpol}{Position of party leadership on common foreign and security policy. Higher value indicate more in favor of common foreign and security policy.Original name: Q8}
#' \item{eu_turkey}{Position of party leadership on EU enlargement to Turkey. Higher value indicate more in favor of including Turkey. Original name: Q9}
#' \item{leftright}{Position of party in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q10}
#' \item{econlr}{Position of party on economic issues in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q11}
#' \item{galtan}{Position of party on democratic freedom and rights in the broad ideological spectrum. Democratic freedom and rights is understood as the role of government in life choices. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q12}
#' \item{spendvtax}{Position of party on improving public services vs. reducing taxes. Higher value indicate more in favor of reducing taxes. Original name: Q13}
#' \item{spendvtax_salience}{Relative importance/salience of the "improving public services vs. reducing taxes"-issue for the party. Higher value indicates higher importance. Original name: Q14}
#' \item{deregulation}{Position of party on deregulating markets. Higher value indicates more in favor of deregulating. Original name: Q15.}
#' \item{dereg_salience}{Relative importance/salience of the "deregulating markets"-issue for the party. Original name: Q16}
#' \item{redistribution}{Position of party on redistributing from the rich to the poor. Higher value indicates more opposition to redistribution. Original name: Q17}
#' \item{redist_salience}{Relative importance/salience of the "redistribution"-issue for the party. Original name: Q18.}
#' \item{civlib_laworder}{Position of party on civil liberties vs. law and order. Higher value indicates support to tough law and order. Original name: Q19}
#' \item{civlib_salience}{Relative importance/salience of the "civil liberties vs. law and order"-issue. Original name: Q20}
#' \item{sociallifestyle}{Position of party on social lifestyle, for example homosexuality. Higher value indicates opposition to liberal lifestyle. Original name: Q21}
#' \item{social_salience}{Relative importance/salience of social lifestyle issues for party. Original name: Q22}        
#' \item{religious_principle}{Position of party on role of religious principles. Higher value indicates support for religious principles. Original name: Q23}        
#' \item{relig_salience}{Relative importance/salience of "religious principles"-issue. Original name: Q24}        
#' \item{immigrate_policy}{Position of party on immigration policy. Higher value indicates support for tough policy. Original name: Q25}    
#' \item{immigra_salience}{Relative importance/salience of "immigration"-issue for party. Original name: Q26}
#' \item{immigrant_asylum}{Position of party on integration of immigrants and asylum seekers. Higher value indicates support for strong assimilation. Original name: Q27}       
#' \item{immasylum_salience}{Relative important/salience of "intergration"-issue for party. Original name: Q28}       
#' \item{urban_rural}{Position of party on urban vs. rural interests. Higher value indicate support for rural interests. Original name: Q28}       
#' \item{urb_rur_salience}{Relative importance/salience of "urban vs. rural interests"-issue for party. Original name: Q30}     
#' \item{cosmopolitan_nationalism}{Position of party on cosmopolitan vs. nationalism. Higher value indicates advocates for nationalism. Original name: Q31}           
#' \item{cosmonat_salience}{Relative importance/salience of "cosmopolitan vs. nationalism"-issue. Original name: Q32}       
#' \item{regions}{Position of party on political decentralization to regions/localities. Higher value indicates opposition to decentralization. Original name: Q33}            
#' \item{region_salience}{Relative importance/salience of "decentralization"-issue for party. Original name: Q34}        
#' \item{us}{Position of party on US power in world affairs. Higher value indicates favor of strong US leadership. Original name: Q35}
#' \item{us_salience}{Relative importance/salience of "US power"-issue for party. Original name: Q36}       
#' \item{ethnic_minorities}{Position of party towards ethnic minorities. Higher value indicates opposition to minorty-rights. Original name: Q37} 
#' \item{ethnic_salience}{Relative importance/salience of "ethnic minorities"-issue for party. Original name: Q38} 
#' 
#'  } 
#' @name ChapelHill2006
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Liesbet Hooghe, Ryan Bakker, Anna Brigevich, Catherine de Vries, Erica Edwards, Gary Marks, Jan Rovny, Marco Steenbergen (2010), "Reliability and Validity of Measuring Party Positions: The Chapel Hill Expert Surveys of 2002 and 2006", European Journal of Political Research, (4): 684-703.
#' @source \url{http://www.unc.edu/~hooghe/data_pp.php} 
#' @seealso ChapelHill2010 ChapelHill2002 ChapelHill1999 
#' @keywords dataset party position
#' @examples
#' # This example shows how parties' position on some typical
#' #dimensions affect their likelihood for being a government party in Europe in 2006.
#' data(ChapelHill2006)
#' data(ParlGov)
#' ParlGov <- ParlGov[which(ParlGov$year==2006 & ParlGov$DecemberandCensored > 0),]
#' 
#' ChapelHill2006 <- data.frame(lapply(ChapelHill2006, function(v) {
#'   if (is.character(v)) return(toupper(v))
#'   else return(v)
#' }))
#' ParlGov <- data.frame(lapply(ParlGov, function(v) {
#'   if (is.character(v)) return(toupper(v))
#'   else return(v)
#' }))
#' 
#' Parties <- merge(ChapelHill2006,ParlGov, by.x="party",by.y="party_name_short",all=TRUE)
#' summary(Parties$party_id.y) #615 ParlGov parties did not match
#' #abbreviated names in ChapelHill
#' #A more serious analysis should do a better check of which parties that do not match.
#' 
#' Parties <- Parties[!duplicated(Parties),]
#' 
#' library(lme4)
#' InPower06 <- glmer(cabinet_party ~ factor(eu_pos) + factor(leftright)
#'                    + factor(regions) + factor(ethnic_minorities) + (1 | country_id.x),
#'                    family="binomial",data=Parties)
#' summary(InPower06)
NULL