#' Boix, Miller and Rosato - Dichotomous Coding of Democracy
#' 
#' @description The coding rules and data references are included in the above paper. This version includes 16,308 democracy observations across 219 distinct countries. It is current for all sovereign countries (including micro-states) up to the year 2007.
#' @format An unbalanced dataset of 18199 rows and 10 variables.
#' It covers 218 countries over the time period 1800 - 2007.
#' The mean number of years per country is 83, and the median is 53.
#' \describe{
#' 
#' \item{country}{Country name}
#' \item{ccode}{COW country code}
#' \item{abbreviation}{World Bank 3-letter code}
#' \item{year}{Year}
#' \item{democracy}{Dichotomous democracy measure}
#' \item{sovereign}{Dichotomous indicator of sovereignty/independence (if 0, democracy is NA)}
#' \item{democracy_trans}{-1 if democratic breakdown, 0 if no change, 1 if democratic transition}
#' \item{democracy_breakdowns}{Previous number of democratic breakdowns}
#' \item{democracy_duration}{Consecutive years of current regime type}
#' \item{democracy_omitteddata}{Changes several democracy observations to NA for occupations during war or major civil wars; democracy codes these years as continuations of the same regime type}
#' 
#' }
#' @name BoixMillerRosato
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Carles Boix, Michael K. Miller, and Sebastian Rosato.(forthcoming) “A Complete Data Set of Political Regimes, 1800-2007.” Comparative Political Studies.
#' @keywords dataset regime
#' @examples
#' #This example shows how BoixMillerRosato and ParlGov can be merged.
#' #This is used to shows the correlation between the age of democracy
#' #and the duration of cabinets.
#' 
#' data(BoixMillerRosato)
#' data(ParlGov)
#' library(MASS);library(car)
#' ParlGov <- ParlGov[ParlGov$DecemberandCensored > 0 & ParlGov$NewCab==1,]
#' 
#' ParlGov$office <- as.numeric(as.character(ParlGov$year)) -
#'   as.numeric(as.character(ParlGov$Start_year))
#' 
#' BoixParl <- merge(ParlGov,BoixMillerRosato, by.x=c("country_name_short","year"),
#'                   by.y=c("abbreviation","year"),all==TRUE)
#' 
#' 
#' Office <- glm.nb(office ~ poly(democracy_duration,3),
#'                  data=BoixParl[!is.na(BoixParl$democracy_duration & BoixParl$caretaker==0),])
#' termplot(Office,se=TRUE)
#' abline(h=0)
#' summary(Office)
#' 
#' BoixParl <- BoixParl[order(BoixParl$country_name,BoixParl$year,BoixParl$cabinet_name),]
#' BoixParl2 <- BoixParl[!duplicated(BoixParl$cabinet_name),]
#' BoixParl2$cabinet_duration <- as.numeric(as.factor(BoixParl2$cabinet_duration))
#' 
#' scatterplot(office ~ log(democracy_duration),
#'             data=BoixParl[BoixParl$caretaker==0,],smoother=TRUE,
#'             xlab="LN Democracy Duration (Years)", ylab="Cabinet Duration (Years)", 
#'             main="Duration of democracy and government")
#' 
#' scatterplot(cabinet_duration ~ log(democracy_duration),
#'             data=BoixParl2[BoixParl2$caretaker==0,],smoother=TRUE,
#'             xlab="LN Democracy Duration (Years)", ylab="Cabinet Duration (Weeks)", 
#'             main="Duration of democracy and government")
#' 
NULL