#' HuberInglehart - party position data from Huber & Inglehart (1995)
#' 
#' @description This dataset contains party position data from Huber/Inglehart (1995).
#' This dataset is a copy of external_party_huber_inglehart.csv from ParlGov.
#' @format A cross-sectional dataframe with 300 rows and 10 variables.
#' It includes information of 231 parties from 42 countries
#' \describe{
#' 
#' \item{id}{Party id from Huber/Inglehart}
#' \item{country}{Country name}
#' \item{name_english}{Party name in english}
#' \item{name}{Party name (Could contain some encoding issues with special characters)}
#' \item{name_short}{Party name abbreviation}
#' \item{left_right}{Left-right position}
#' \item{range_left}{Lower bound of left-right position}
#' \item{range_right}{Upper bound of left-right position}
#' \item{sd}{standard deviation of left-right position}
#' \item{respondents}{Number of respondents}
#'  } 
#' @name HuberInglehart
#' @details Left-right position from this data set is also in \link{GabelHuber}
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Huber, John, and Roland Inglehart. 1995. “Expert Interpretations of Party Space and Party Locations in 42 Societies.” Party Politics 1(1):73–111.
#'@source Huber-Inglehart at ParlGov online: \url{http://www.parlgov.org/stable/documentation/table/external_party_huber_inglehart.html}
#' @keywords dataset party position
#' @seealso \link{GabelHuber}
#' @examples
#' data(HuberInglehart)
#' data(CastlesMair)
#' data(Party)
#' 
#' ####Give colname .CM and .HI endings, so where they come from can be identified
#' names(CastlesMair) <- sub("$",".CM",names(CastlesMair))
#' names(HuberInglehart) <- sub("$",".HI",names(HuberInglehart))
#' 
#' #Merge
#' HICM <- merge(Party,CastlesMair,
#'               by.x='castles_mair', by.y='id.CM', all=TRUE)
#' HICM <- merge(HICM,HuberInglehart,
#'               by.x='huber_inglehart', by.y='id.HI', all=TRUE)
#' 
#' #Get an idea of correlation between left_right in the
#' #different datasets.
#' library(corrgram)
#' corrgram(HICM[,c("left_right.CM","left_right.HI")],
#'          upper.panel=panel.pie,lower.panel=panel.pts)
#' 
#' #Center variables, so they can be used in OLS.
#' HICM$lr.HI <- scale(HICM$left_right.HI, center=TRUE, scale=FALSE)
#' HICM$lr.CM <- scale(HICM$left_right.CM, center=TRUE, scale=FALSE)
NULL