#' Portfolio
#' 
#' @description Portfolio allocation in Western Europe
#' @format A dataframe with 360 rows and 280 columns.
#' Each row is a unique cabinet from one of 14 countries between 1945 - 2000.
#' 
#' \describe{
#' 
#' \item{country_code}{Country code, Original: v001x. 01 = Austria, 02 = Belgium, 03 = Denmark, 04 = Finland, 05 = France, 06 = Germany, 07 = Greece, 08 = Iceland, 09 = Ireland, 10 = Italy, 11 = Luxembourg, 12 = the Netherlands, 13 = Norway, 14 = Portugal, 15 = Spain, 16 = Sweden, 17 = United Kingdom}
#' \item{cabinet_code}{Cabinet code. First digit: country code. Second digit: cabinet code. Original: v002x}
#' \item{cabinet}{Cabinet name. Original: v003x}
#' \item{indate}{Inaugeration date of cabinet. Original: v004x}
#' \item{outdate}{Date cabinet leaves office. Original: v005x}
#' \item{decade}{Decade of cabinet, Original: v006x. 40 = 1940-1949, 50 = 1950-1959, 60 = 1960-1969, and so on}
#' \item{pos_duration}{Maximum possible number of duration days. Original: v007x}
#' \item{duration}{Duration of cabinet in days. Original: v008x}
#' \item{rel_duration}{Relative number of duration days. This is \code{duration} divided by \code{max_duration}. Original: v009x}
#' \item{max_duration}{Did the cabinet sit 100 percent of its relative duration days, yes(1) or no(0). Original: v010x}
#' \item{cabinet_comp}{Composition of cabinet. Original: v011x}
#' \item{non_partisan_cab}{Was it a Non partisan cabinet, yes(1) or no(0). Original: v012x}
#' \item{cabinet_parties}{Number of cabinet parties. Original: v013x}
#' \item{coalition}{Coalition cabinet, yes(1) or no(0). Original: v014x}
#' \item{maj_cabinet}{Was it a majority cabinet, yes(1) or no(0). Original: v015x}
#' \item{surp_cabinet}{Was it a surplus majority cabinet, yes(1) or no(0). Original: v016x}
#' \item{new_government}{Does this cabinet represent the start of a new government, yes(1) or no(0). Original: v017x}
#' \item{election_proximity_gov_low}{This is a categorical variable measuring proximity to a lower chamber election, either at start or end of the cabinet duration. \code{election_proximity_gov_low} is ordered by government, and different from \code{election_proximity_cab_low} which is ordered by cabinet.  Original: v018x. \strong{F} = Cabinet immediately following an election, \strong{E} = Cabinet ended by an election, \strong{FE} = Cabinet immediately following an election and ended by the next election, \strong{N} = neither immediately following or ended by an election}
#' \item{election_proximity_cab_low}{This is a categorical variable measuring proximity to a lower chamber election, either at start or end of the cabinet duration. \code{election_proximity_cab_low} is ordered by cabinet, and different from \code{election_proximity_gov_low} which is ordered by government. Original: v019x.  \strong{F} = Cabinet immediately following an election, \strong{E} = Cabinet ended by an election, \strong{FE} = Cabinet immediately following an election and ended by the next election, \strong{N} = neither immediately following or ended by an election}
#' \item{seats1_low}{Party seats lower chamber, Party 1. Original: v020x}
#' \item{seats2_low}{Party seats lower chamber, Party 2. Original: v021x}
#' \item{seats3_low}{Party seats lower chamber, Party 3. Original: v022x}
#' \item{seats4_low}{Party seats lower chamber, Party 4. Original: v023x}
#' \item{seats5_low}{Party seats lower chamber, Party 5. Original: v024x}
#' \item{seats6_low}{Party seats lower chamber, Party 6. Original: v025x}
#' \item{seats7_low}{Party seats lower chamber, Party 7. Original: v026x}
#' \item{seats8_low}{Party seats lower chamber, Party 8. Original: v027x}
#' \item{seats9_low}{Party seats lower chamber, Party 9. Original: v028x}
#' \item{seats10_low}{Party seats lower chamber, Party 10. Original: v029x}
#' \item{seats11_low}{Party seats lower chamber, Party 11. Original: v030x}
#' \item{seats12_low}{Party seats lower chamber, Party 12. Original: v031x}
#' \item{seats13_low}{Party seats lower chamber, Party 13. Original: v032x}
#' \item{seats14_low}{Party seats lower chamber, Party 14. Original: v033x}
#' \item{seats15_low}{Party seats lower chamber, Party 15. Original: v034x}
#' \item{seats16_low}{Party seats lower chamber, Party 16. Original: v035x}
#' \item{seats17_low}{Party seats lower chamber, Party 17. Original: v036x}
#' \item{seats18_low}{Party seats lower chamber, Party 18. Original: v037x}
#' \item{seats19_low}{Party seats lower chamber, Party 19. Original: v038x}
#' \item{seats20_low}{Party seats lower chamber, Party 20. Original: v039x}
#' \item{seats21_low}{Party seats lower chamber, Party 21. Original: v040x}
#' \item{seats22_low}{Party seats lower chamber, Party 22. Original: v041x}
#' \item{seats23_low}{Party seats lower chamber, Party 23. Original: v042x}
#' \item{seats24_low}{Party seats lower chamber, Party 24. Original: v043x}
#' \item{seats25_low}{Party seats lower chamber, Party 25. Original: v044x}
#' \item{dim1_median_party_low}{Party label of the median legislator in lower chamber, first dimension. Original: v045x}
#' \item{total_seats_low}{Total number of seats in lower chamber. Original: v046x}
#' \item{cab_strength_low}{Cabinet strength in lower chamber. Original: v047x}
#' \item{cab_seatshare_low}{Cabinet share of seats in lower chamber. This is \code{cab_strength_low} divided by \code{total_seats_low}. Original: v048x}
#' \item{eff_parties_low}{Effective number of parliamentary parties in lower chamber. Original: v049x}
#' \item{dim2_median_party_low}{Party label of the median legislator in lower chamber, second dimension. Original: v050x}
#' \item{election_proximity_gov_up}{This is a categorical variable measuring proximity to a upper chamber election, either at start or end of the cabinet duration. \code{election_proximity_gov_up} is ordered by government, and different from \code{election_proximity_cab_up} which is ordered by cabinet. Original: v051x. \strong{F} = Cabinet immediately following an election, \strong{E} = Cabinet ended by an election, \strong{FE} = Cabinet immediately following an election and ended by the next election, \strong{N} = neither immediately following or ended by an election}
#' \item{election_proximity_cab_up}{This is a categorical variable measuring proximity to a upper chamber election, either at start or end of the cabinet duration. \code{election_proximity_cab_up} is ordered by cabinet, and different from \code{election_proximity_gov_up} which is ordered by government. Original: v052x.  \strong{F} = Cabinet immediately following an election, \strong{E} = Cabinet ended by an election, \strong{FE} = Cabinet immediately following an election and ended by the next election, \strong{N} = neither immediately following or ended by an election}
#' \item{seats1_up}{Party seats upper chamber, Party 1. Original: v053x}
#' \item{seats2_up}{Party seats upper chamber, Party 2. Original: v054x}
#' \item{seats3_up}{Party seats upper chamber, Party 3. Original: v055x}
#' \item{seats4_up}{Party seats upper chamber, Party 4. Original: v056x}
#' \item{seats5_up}{Party seats upper chamber, Party 5. Original: v057x}
#' \item{seats6_up}{Party seats upper chamber, Party 6. Original: v058x}
#' \item{seats7_up}{Party seats upper chamber, Party 7. Original: v059x}
#' \item{seats8_up}{Party seats upper chamber, Party 8. Original: v060x}
#' \item{seats9_up}{Party seats upper chamber, Party 9. Original: v061x}
#' \item{seats10_up}{Party seats upper chamber, Party 10. Original: v062x}
#' \item{seats11_up}{Party seats upper chamber, Party 11. Original: v063x}
#' \item{seats12_up}{Party seats upper chamber, Party 12. Original: v064x}
#' \item{seats13_up}{Party seats upper chamber, Party 13. Original: v065x}
#' \item{seats14_up}{Party seats upper chamber, Party 14. Original: v066x}
#' \item{seats15_up}{Party seats upper chamber, Party 15. Original: v067x}
#' \item{seats16_up}{Party seats upper chamber, Party 16. Original: v068x}
#' \item{seats17_up}{Party seats upper chamber, Party 17. Original: v069x}
#' \item{seats18_up}{Party seats upper chamber, Party 18. Original: v070x}
#' \item{seats19_up}{Party seats upper chamber, Party 19. Original: v071x}
#' \item{seats20_up}{Party seats upper chamber, Party 20. Original: v072x}
#' \item{seats21_up}{Party seats upper chamber, Party 21. Original: v073x}
#' \item{seats22_up}{Party seats upper chamber, Party 22. Original: v074x}
#' \item{seats23_up}{Party seats upper chamber, Party 23. Original: v075x}
#' \item{seats24_up}{Party seats upper chamber, Party 24. Original: v076x}
#' \item{seats25_up}{Party seats upper chamber, Party 25. Original: v077x}
#' \item{total_seats_up}{Total number of seats in upper chamber. Original: v078x}
#' \item{cab_strength_up}{Cabinet strength in upper chamber. Original: v079x}
#' \item{eff_parties_up}{Effective number of parliamentary parties in upper chamber. Original: v080x}
#' \item{dim1_median_party_up}{Party label of the median legislator in upper chamber, first dimension. Original: v081x}
#' \item{dim2_median_party_up}{Party label of the median legislator in upper chamber, second dimension. Original: v082x}
#' \item{parl_parties}{Total number of parties in parliament. Original: v083x}
#' \item{barg_rounds}{Total number of inconclusive bargaining rounds. Original: v084x}
#' \item{parties_barg_round1}{Parties involved in first inconclusive bargaining round. Original: v085x}
#' \item{parties_barg_round2}{Parties involved in second inconclusive bargaining round. Original: v086x}
#' \item{parties_barg_round3}{Parties involved in third inconclusive bargaining round. Original: v087x}
#' \item{parties_barg_round4}{Parties involved in fourth inconclusive bargaining round. Original: v088x}
#' \item{parties_barg_round5}{Parties involved in fifth inconclusive bargaining round. Original: v089x}
#' \item{parties_barg_round6}{Parties involved in sixth inconclusive bargaining round. Original: v090x}
#' \item{parties_barg_round7}{Parties involved in seventh inconclusive bargaining round. Original: v091x}
#' \item{parties_barg_round8}{Parties involved in eigth inconclusive bargaining round. Original: v092x}
#' \item{parties_barg_round9}{Parties involved in ninth inconclusive bargaining round. Original: v093x}
#' \item{parties_barg_round10}{Parties involved in tenth inconclusive bargaining round. Original: v094x}
#' \item{barg_days}{Number of days required in cabinet formation. Original: v095x}
#' \item{coalition_agreement}{A categorical variable for at what point in time the coalition agreement was written. Original: v096x. \strong{N} No written coal agreement, \strong{PRE} Preelectoral written coal agreement, \strong{POST} Postelectoral written coal agreement, \strong{IE} Written agreement not immediately following elections, \strong{PRE,POST} Pre- and postelectoral written agreement}
#' \item{coalition_agreement2}{A categorical variable for at what point in time the coalition agreement was written. Identical to "coalition_agreement", but with numbers instead. Original: v097x. \strong{0} No written coal agreement, \strong{1} Preelectoral written coal agreement, \strong{2} Postelectoral written coal agreement, \strong{3} Written agreement not immediately following elections, \strong{4} = Pre- and postelectoral written agreement}
#' \item{agreement_public}{Was the agreement public, yes(1) or no(0). Original: v098x}
#' \item{election_rule}{Election rule, yes(1) or no(0). Original: v099x}
#' \item{manage_mech}{Type of management mechanism. Original: v100x. \strong{IC} = Inner cabinet, \strong{CaC} = Cabinet committee(s), \strong{CoC} = Coalition committee, \strong{Parl} = Parliamentary leaders, \strong{Pca} = Combination of cabinet members and parliamentarians, \strong{PS} = Party summit, \strong{O} = Other}
#' \item{common_manage_mech}{Most common type of management mechanism. Original: v101x. \strong{IC} = Inner cabinet, \strong{CaC} = Cabinet committee(s), \strong{CoC} = Coalition committee, \strong{Parl} = Parliamentary leaders, \strong{Pca} = Combination of cabinet members and parliamentarians, \strong{PS} = Party summit, \strong{O} = Other}
#' \item{serious_manage_mech}{Most common type of management mechanism in the most serious conflicts. Original: v102x. \strong{IC} = Inner cabinet, \strong{CaC} = Cabinet committee(s), \strong{CoC} = Coalition committee, \strong{Parl} = Parliamentary leaders, \strong{Pca} = Combination of cabinet members and parliamentarians, \strong{PS} = Party summit, \strong{O} = Other}
#' \item{coalition_discipline_leg}{Coalition discipline in legislation. Original: v103x. 1 = Yes always, 2 = Yes, on all policies except those explicitly exempted, 3 = No, except those policies explicitly specified, 4 = No}
#' \item{coalition_discipline_other}{Coalition discipline in other parliamentary behavior. Original: v104x. 1 = Yes always, 2 = Yes, on all policies except those explicitly exempted, 3 = No, except those policies explicitly specified, 4 = No}
#' \item{freedom_appointment}{Party freedom in appointment. Original: v105x. 0 = No (=subject to coalition approval/veto), 1 = Yes}
#' \item{coalition_pol_agree}{Coalition policy agreement, Original: v106x. 0 = No explicit agreement, 1 = On few selected policies, 2 = On a variety of issues, but not comprehensive, 3 = Comprehensive policy platform}
#' \item{junior_agree}{Junior ministers included in agreement, yes(1) or no(0). Original: v107x}
#' \item{noncab_position_agree}{Non-cabinet positions included in agreement, yes(1) or no(0). Original: v108x}
#' \item{agreement_size}{Agreement size in number of words. Original: v109x}
#' \item{gen_procedural_rules}{General procedural rules in percent. Original: v110x}
#' \item{polspec_procedural_rules}{Policy specific procedural rules in percent. Original: v111x}
#' \item{dist_office}{Distribution of offices in percent. Original: v112x}
#' \item{dist_competences}{Distribution of competences in percent. Original: v113x}
#' \item{policies}{Policies in percent. Original: v114x}
#' \item{minister1}{Party code of minister 1, the prime minister. Original: v115x}
#' \item{junior_minister1}{Party code of junior minister 1. Original: v116x}
#' \item{minister2}{Party code of minister 2, the deputy prime minister. Original: v117x}
#' \item{junior_minister2}{Party code of junior minister 2. Original: v0118x}
#' \item{minister3}{Party code of minister 3, the financial minister. Original: v119x}
#' \item{junior_minister3}{Party code of junior minister 3. Original: v120x}
#' \item{minister4}{Party code of minister 4, foreign affairs. Original: v121x}
#' \item{junior_minister4}{Party code of junior minister 4. Original: v122x} 
#' \item{minister5}{Party code of minister 5. Original: v123x}
#' \item{junior_minister5}{Party code of junior minister 5. Original: v124x}
#' \item{minister6}{Party code of minister 6. Original: v125x}
#' \item{junior_minister6}{Party code of junior minister 6. Original: v126x}
#' \item{minister7}{Party code of minister 7. Original: v127x}
#' \item{junior_minister7}{Party code of junior minister 7. Original: v128x}
#' \item{minister8}{Party code of minister 8. Original: v129x}
#' \item{junior_minister8}{Party code of junior minister 8. Original: v130x}
#' \item{minister9}{Party code of minister 9. Original: v131x}
#' \item{junior_minister9}{Party code of junior minister 9. Original: v132x}
#' \item{minister10}{Party code of minister 10. Original: v133x}
#' \item{junior_minister10}{Party code of junior minister 10. Original: v134x}
#' \item{minister11}{Party code of minister 11. Original: v135x}
#' \item{junior_minister11}{Party code of junior minister 11. Original: v136x}
#' \item{minister12}{Party code of minister 12. Original: v137x}
#' \item{junior_minister12}{Party code of junior minister 12. Original: v138x}
#' \item{minister13}{Party code of minister 13. Original: v139x}
#' \item{junior_minister13}{Party code of junior minister 13. Original: v140x}
#' \item{minister14}{Party code of minister 14. Original: v141x}
#' \item{junior_minister14}{Party code of junior minister 14. Original: v142x}
#' \item{minister15}{Party code of minister 15. Original: v143x}
#' \item{junior_minister15}{Party code of junior minister 15. Original: v144x}
#' \item{minister16}{Party code of minister 16. Original: v145x}
#' \item{junior_minister16}{Party code of junior minister 16. Original: v146x}
#' \item{minister17}{Party code of minister 17. Original: v147x}
#' \item{junior_minister17}{Party code of junior minister 17. Original: v148x}
#' \item{minister18}{Party code of minister 18. Original: v149x}
#' \item{junior_minister18}{Party code of junior minister 18. Original: v150x}
#' \item{minister19}{Party code of minister 19. Original: v151x}
#' \item{junior_minister19}{Party code of junior minister 19. Original: v152x}
#' \item{minister20}{Party code of minister 20. Original: v153x}
#' \item{junior_minister20}{Party code of junior minister 20. Original: v154x}
#' \item{minister21}{Party code of minister 21. Original: v155x}
#' \item{junior_minister21}{Party code of junior minister 21. Original: v156x}
#' \item{minister22}{Party code of minister 22. Original: v157x}
#' \item{junior_minister22}{Party code of junior minister 22. Original: v158x}
#' \item{minister23}{Party code of minister 23. Original: v159x}
#' \item{junior_minister23}{Party code of junior minister 23. Original: v160x}
#' \item{minister24}{Party code of minister 24. Original: v161x}
#' \item{junior_minister24}{Party code of junior minister 24. Original: v162x}
#' \item{minister25}{Party code of minister 25. Original: v163x}
#' \item{junior_minister25}{Party code of junior minister 25. Original: v164x}
#' \item{minister26}{Party code of minister 26. Original: v165x}
#' \item{junior_minister26}{Party code of junior minister 26. Original: v166x}
#' \item{minister27}{Party code of minister 27. Original: v167x}
#' \item{junior_minister27}{Party code of junior minister 27. Original: v168x}
#' \item{minister28}{Party code of minister 28. Original: v169x}
#' \item{junior_minister28}{Party code of junior minister 28. Original: v170x}
#' \item{minister29}{Party code of minister 29. Original: v171x}
#' \item{junior_minister29}{Party code of junior minister 29. Original: v172x}
#' \item{minister30}{Party code of minister 30. Original: v173x}
#' \item{junior_minister30}{Party code of junior minister 30. Original: v174x}
#' \item{minister31}{Party code of minister 31. Original: v175x}
#' \item{junior_minister31}{Party code of junior minister 31. Original: v176x}
#' \item{minister32}{Party code of minister 32. Original: v177x}
#' \item{junior_minister32}{Party code of junior minister 32. Original: v178x}
#' \item{minister33}{Party code of minister 33. Original: v179x}
#' \item{junior_minister33}{Party code of junior minister 33. Original: v180x}
#' \item{minister34}{Party code of minister 34. Original: v181x}
#' \item{junior_minister34}{Party code of junior minister 34. Original: v182x}
#' \item{minister35}{Party code of minister 35. Original: v183x}
#' \item{junior_minister35}{Party code of junior minister 35. Original: v184x}
#' \item{minister36}{Party code of minister 36. Original: v185x}
#' \item{junior_minister36}{Party code of junior minister 36. Original: v186x}
#' \item{minister37}{Party code of minister 37. Original: v187x}
#' \item{junior_minister37}{Party code of junior minister 37. Original: v188x}
#' \item{minister38}{Party code of minister 38. Original: v189x}
#' \item{junior_minister38}{Party code of junior minister 38. Original: v190x}
#' \item{minister39}{Party code of minister 39. Original: v191x}
#' \item{junior_minister39}{Party code of junior minister 39. Original: v192x}
#' \item{minister40}{Party code of minister 40. Original: v193x}
#' \item{junior_minister40}{Party code of junior minister 40. Original: v194x}
#' \item{minister41}{Party code of minister 41. Original: v195x}
#' \item{junior_minister41}{Party code of junior minister 41. Original: v196x}
#' \item{minister42}{Party code of minister 42. Original: v197x}
#' \item{junior_minister42}{Party code of junior minister 42. Original: v198x}
#' \item{minister43}{Party code of minister 43. Original: v199x}
#' \item{junior_minister43}{Party code of junior minister 43. Original: v200x}
#' \item{minister44}{Party code of minister 44. Original: v201x}
#' \item{junior_minister44}{Party code of junior minister 44. Original: v202x}
#' \item{minister45}{Party code of minister 45. Original: v203x}
#' \item{junior_minister45}{Party code of junior minister 45. Original: v204x}
#' \item{minister46}{Party code of minister 46. Original: v205x}
#' \item{junior_minister46}{Party code of junior minister 46. Original: v206x}
#' \item{minister47}{Party code of minister 47. Original: v207x}
#' \item{junior_minister47}{Party code of junior minister 47. Original: v208x}
#' \item{minister48}{Party code of minister 48. Original: v209x}
#' \item{junior_minister48}{Party code of junior minister 48. Original: v210x}
#' \item{minister49}{Party code of minister 49. Original: v211x}
#' \item{junior_minister49}{Party code of junior minister 49. Original: v212x}
#' \item{minister50}{Party code of minister 50. Original: v213x}
#' \item{junior_minister50}{Party code of junior minister 50. Original: v214x}
#' \item{Honorary_Deputy_PM}{Does the deputy PM hold a honorary title in combination with ordinary portfolio? 0 = Ordinary portfolio. 1 = Honorary title. Original: v215x}
#' \item{N_ministers}{Number of ministries. Original: v216x}
#' \item{N_cab_mem}{Number of cabinet members. Original: v217x}
#' \item{term_election}{Cabinet terminated with regular election, yes(1) or no(0). Original: v218x}
#' \item{term_other}{Cabinet terminated because of other constitutional reason, yes(1) or no(0). Original: v219x}
#' \item{term_death}{Cabinet terminated due to death of the prime minister, yes(1) or no(0). Original: v220x}
#' \item{term_early_elec}{Cabinet terminated because of early election, yes(1) or no(0). Original: v221x}
#' \item{term_enlarge}{Cabinet terminated because of voluntary enlargement, yes(1) or no(0). Original: v222x}
#' \item{term_defeat}{Cabinet terminated due to defeat in parliament, yes(1) or no(0). Original: v223x}
#' \item{term_conf_policy}{Cabinet terminated because of conflict between coalition partner over policy issue, yes(1) or no(0). Original: v224x}
#' \item{term_conf_personal}{Cabinet terminated because of conflict between coalition partner over a personal issue, yes(1) or no(0). Original: v225x}
#' \item{term_conf_parties}{For cases where a cabinet ended due to conflict between coalition partners, this variable lists which parties were involved. Original: v226x}
#' \item{term_conf_intra}{Cabinet terminated due to an intra party conflict, yes(1) or no(0). Original: v227x}
#' \item{term_conf_intraparties}{For cases where a cabinet ended due to intra party conflict, this variable labels the party. Original: v228x}
#' \item{term_conf_intratype}{For cases where a cabinet ended due to intra party conflict, this categorizes the type of conflict, Original: v229x. \strong{L} = Conflict in national party leadership, \strong{NL} = Conflict between united national party leadership and non-leaders, \strong{LNL} = Conflict in national party leadership involving non-leaders}
#' \item{term_nonparl_election}{Cabinet terminated due to a non-parliamentary election, yes(1) or no(0). Original: v230x}
#' \item{term_opinion}{Cabinet terminated due to a popular opinion shock, yes(1) or no(0). Original: v231x}
#' \item{term_security}{Cabinet terminated due to an international or national security event, yes(1) or no(0). Original: v232x}
#' \item{term_economy}{Cabinet terminated due to an economic event, yes(1) or no(0). Original: v233x}
#' \item{term_personal}{Cabinet terminated due to a personal event, yes(1) or no(0). Original: v234x}
#' \item{policy_area_dominant}{Policy area dominant, yes(1) or no(0). The codebook doesn't provide any more information on this variable. It probably refers to if the policy area that experienced an event that terminated the cabinet was a dominant policy area for that cabinet. Original: v235x}
#' \item{minister_involved}{Which ministries were involved in a terminal event. Original: v236x}
#' \item{desc_dominant_policy}{Description of dominant poicy area summarized in one word. Original: v237x}
#' \item{term_tech}{Did the cabinet end due to a technical issue, yes(1) or no(0). Technical issues: Regular parliamentary election, other constitutional reasons and death of prime minister. Original: v238x}
#' \item{term_event}{Did the cabinet end due to a terminal event, yes(1) or no(0). Terminal events: Non-parliamentary election, popular opinion shock, international or national security issue, economic event and personal event. Original: v239x}
#' \item{term_behave}{Did the cabinet end due to a behavioral/discretionary reason, yes(1) or no(0). Behavioral/discretyionary terminations: Early parliamentary election, voluntary enlargement of coalition, cabinet defeat in parliament, conflict between coalition parties both over policy and personal issues and intra party conflict. Original: v240x} 
#' \item{office}{Was cabinet in office at election, yes(1) or no(0). Original: v241x}
#' \item{election_year}{Election year following cabinet. Original: v242x}
#' \item{result1}{Gain/loss of cabinet parties, party 1. Original: v243x} 
#' \item{result2}{Gain/loss of cabinet parties, party 2. Original: v244x} 
#' \item{result3}{Gain/loss of cabinet parties, party 3. Original: v245x} 
#' \item{result4}{Gain/loss of cabinet parties, party 4. Original: v246x} 
#' \item{result5}{Gain/loss of cabinet parties, party 5. Original: v247x} 
#' \item{result6}{Gain/loss of cabinet parties, party 6. Original: v248x} 
#' \item{result7}{Gain/loss of cabinet parties, party 7. Original: v249x} 
#' \item{result8}{Gain/loss of cabinet parties, party 8. Original: v250x} 
#' \item{result9}{Gain/loss of cabinet parties, party 9. Original: v251x} 
#' \item{result10}{Gain/loss of cabinet parties, party 10. Original: v252x} 
#' \item{result11}{Gain/loss of cabinet parties, party 11. Original: v253x} 
#' \item{result12}{Gain/loss of cabinet parties, party 12. Original: v254x} 
#' \item{result13}{Gain/loss of cabinet parties, party 13. Original: v255x} 
#' \item{result14}{Gain/loss of cabinet parties, party 14. Original: v256x} 
#' \item{result15}{Gain/loss of cabinet parties, party 15. Original: v257x} 
#' \item{result16}{Gain/loss of cabinet parties, party 16. Original: v258x} 
#' \item{result17}{Gain/loss of cabinet parties, party 17. Original: v259x} 
#' \item{result18}{Gain/loss of cabinet parties, party 18. Original: v260x} 
#' \item{result19}{Gain/loss of cabinet parties, party 19. Original: v261x} 
#' \item{result20}{Gain/loss of cabinet parties, party 20. Original: v262x} 
#' \item{result21}{Gain/loss of cabinet parties, party 21. Original: v263x} 
#' \item{result22}{Gain/loss of cabinet parties, party 22. Original: v264x} 
#' \item{result23}{Gain/loss of cabinet parties, party 23. Original: v265x} 
#' \item{result24}{Gain/loss of cabinet parties, party 24. Original: v266x} 
#' \item{result25}{Gain/loss of cabinet parties, party 25. Original: v267x} 
#' \item{result_cabinet}{Gain/loss of cabinet. Original: v268x} 
#' \item{investiture_votes}{Number of unsuccessful investiture votes before cabinet was installed. Original: v269x} 
#' \item{invstiture_pro}{Number of investiture votes pro government in the final investiture vote. Original: v270x} 
#' \item{investiture_against}{Number of investiture votes against government in the final investiture vote. Original: v271x} 
#' \item{invstiture_abstain}{Number of abstained votes in the final investiture vote. Original: v272x} 
#' \item{invstiture_other}{Number of other votes in the final investiture vote. Original: v273x}
#' \item{confidence_vote}{Number of no confidence votes. Original: v274x}
#' \item{term_confidence}{Cabinet removed by no confidence vote, yes(1) or no(0). Original: v275x}
#' \item{resign_confidence}{Cabinet resigned to preempt no confidence vote. Original: v276x}
#' \item{specific_confidence_vote}{Number of confidence votes under specific constitutional mechanism. Original: v277x}
#' \item{failed_confidence}{Cabinet removed by failed confidence vote, yes(1) or no(0). Original: v278x}
#' \item{early_election}{Cabinet ended with early election, yes(1) or no(0). Original: v279x}
#' \item{dissolver}{This identifies the main constitutional actor that caused the early election. Not the formal signatory, but rather the person or body that made the final decision. Original: v280x. 1 = HoS, 2 = PM, 3 = Cabinet, 4 = Parliamentary majority, 5 = Automatic constitutional provision}
#' 
#'  } 
#' @name Portfolio
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Strøm, Kaare; Müller, Wolfgang C. and Bergman, Torbjörn, eds. (2008). \emph{Cabinets and Coalition Bargaining: the Democratic Life Cycle in Western Europe}. Oxford: Oxford University Press.
#' Project homepage: \url{www.pol.umu.se/ccpd}
#' @keywords dataset cabinet election parliament
#' @source Project homepage: \url{www.pol.umu.se/ccpd}
#' @details "Original:" under the variable descriptions indicate the original names of the variables.
#' @seealso \url{StromMuller}
#' @examples
#' data(Portfolio)
#' library(survival)
#' 
#' #This example identifies some common features which affects how
#' #long it takes to bargain a cabinet
#' Portfolio$eff_parties_low[which(Portfolio$eff_parties_low==99999)] <- NA
#' Portfolio$surp_cabinet[which(Portfolio$surp_cabinet==99999)] <- NA
#' Portfolio$maj_cabinet[which(Portfolio$maj_cabinet==99999)] <- NA
#' Portfolio$parl_parties[which(Portfolio$parl_parties==99999)] <- NA
#' Portfolio$cab_seatshare_low[which(Portfolio$cab_seatshare_low==99999)] <- NA
#' Portfolio$new_government[which(Portfolio$new_government==99999)] <- NA
#' Portfolio$new_government[which(Portfolio$new_government==3)] <- NA
#' 
#' summary(coxph(Surv(barg_days) ~ cluster(country_code) + cabinet_parties + factor(coalition)
#'               + factor(maj_cabinet) + factor(new_government) + factor(surp_cabinet) +
#'               eff_parties_low + cab_seatshare_low
#'               ,data=Portfolio))
#' #New cabinets takes longer to bargain.
#' #The more parties in parliament, the longer it takes to bargain.
#' #The more seats the cabinet parties have in parliament, the longer it takes to bargain.
#' 
#' 
#' data(Portfolio)
#' library(ggplot2)
#' #This figure shows and increasing trend in number of no confidence votes
#' ggplot(Portfolio, aes(decade, confidence_vote, group = country_code)) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("N confidence votes") + 
#'   scale_x_continuous("Decade")
#' 
NULL