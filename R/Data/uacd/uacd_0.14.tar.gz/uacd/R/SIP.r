#' SIP  -  Scalar of Polities from Gates, Hegre, Jones, Strand (2006).
#' 
#' @description This dataset contains 14291 rows and 30 columns.
#' This is a start-stop data set with countries as entities.
#' 
#' @format A dataframe with 14291 rows and 30 variables. 
#' It includes 68 countries between 1800 - 2000.
#' \describe{
#' \item{gwno}{Gleditsch and Ward country code.}
#' \item{polid}{Since each country can have several 
#' polities during it’s history, we separate different polities from each other through different Polity IDs.}
#' \item{startd}{The start date as a DATE type variable.}
#' \item{endd}{The end date as a DATE type variable. This, and the previous variable, is only included in order
#' to ease the readability of the dataset.}
#' \item{startnd}{The start date represented as the number of days since 1 January 1800.}
#' \item{endnd}{The end date represented as the number of days since 1 January 1800. }
#' \item{xconst}{The ’Executive Constraints’ dimension (Polity IV codebook, p.21).}
#' \item{xrec}{The ’Executive Recruitment’ dimension. 
#' This variable is constructed out of three \link{PolityIV} indicators: XRCOMP, XRREC, and XROPEN.}
#' \item{part}{ The ’Participation’ dimension. This variable is calculated from Tatu Vanhanen’s (2000) Polyarchy dataset. 
#' Primarily, we define this dimension parallel to Vanhanen’s participation indicator, which measures the fraction of the 
#' population which participated in an election. However, since we theoretically are interested in capturing the extent to 
#' which the capacity of changing the composition of the government is distributed in a society, we have taken the effective 
#' competition in the election into account, so that the participation score is multiplied with the fraction [Competition/30}
#' \item{status}{This variable defines whether the polity ended on the end date or not. Our data end at 31 December 2000, 
#' and all polities in existence at this day are ended. However, this should not be analyzed as the end of a polity, 
#' since it is just the end of us observing the polity. This is often referred to as ’censoring’ in the survival analysis literature. 
#' For analytical purposes, it is practical to add a number of censored observations, which effectively increases the number of 
#' control cases, and which further improves the strength of the analysis. All these additional control cases will be recorded with 
#' status equal to 0, similar to those observations that end on 3 December 2000. For the analysis in 
#' "Institutional Inconsistency and Political Instability: Polity Duration, 1800-2000", we censor every 
#' observation at the end of every year, which consequently means that the number 0’s vastly outnumbers the 1’s.}
#' \item{duration}{The duration of that polity, measured in the number of days.}
#' \item{demindex}{Distance from (0,0,0), Ideal Autocracy. Absence of Participation, Executive recruitment and Executive Constraints}
#' \item{dist001}{Distance from (0,0,1). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist010}{Distance from (0,1,0). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist011}{Distance from (0,1,1). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist100}{Distance from (1,0,0). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist101}{Distance from (1,0,1). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist110}{Distance from (1,1,0). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{dist111}{Distance from (1,1,1). Ideal democracy. A regime with Participation, Executive Constraints and Executive recruitment.}
#' \item{distmid}{Distance from (1/2,1/2,1/2). First digit: Participation.
#' Second digit: Executive Recruitment. Third digit: Executive constraints}
#' \item{mindist}{Most Proximate Corner. }
#' \item{ourtype}{Regime Categorization, without Ceasaristic regimes. }
#' \item{ourtype_ncaes}{Not in codebook.}
#' \item{sip2}{Scalar Index of Polities}
#' \item{year}{Year.}
#' \item{sip2status}{Scalar Index of Polities Change (not in use). }
#' \item{sip2ysc}{Calender years since the previous change in the SIP2 score.}
#' \item{sip2_previous}{The SIP2 score of the previous polity.}
#' \item{stsetpolid}{Variables for specifying Stata analysis.}
#' \item{stsetorig}{Variables for specifying Stata analysis.}
#' 
#' }
#' @name SIP
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Gates, Hegre, Jones, Strand  (2006). "Institutional Inconsistency and Political Instability: Polity Duration, 1800–2000",
#'American Journal of Political Science: 50(4).
#'@source \url{http://www.prio.no/Data/Governance/MIRPSSIP/}
#'
#' \url{http://onlinelibrary.wiley.com/doi/10.1111/j.1540-5907.2006.00222.x/abstract}.
#' @seealso PolityIV PolityIVcoups ACImpev DD 
#' @keywords dataset regime 
#' @examples
#' #This is an unsuccessful attempt to replicate table 1 in the article
#' data(SIP)
#' SIP$demindex[SIP$demindex==-999] <- NA
#' SIP$dist111[SIP$dist111 >=1000] <- NA
#' SIP$distmid[SIP$distmid >=999] <- NA
#' 
#' 
#' SIP$agedummy <- ifelse(SIP$year <= 1839,0,
#'                        ifelse(SIP$year >= 1849 & SIP$year<=1879,1,
#'                               ifelse(SIP$year >=1880 & SIP$year<=1919,2,
#'                                      ifelse(SIP$year >=1920 & SIP$year<=1959,3,
#'                                             ifelse(SIP$year >=1960 & SIP$year<=2000,4,
#'                                                    NA)))))
#' 
#' 
#' SIP$regime <- ifelse(SIP$distmid < SIP$dist111 & SIP$distmid < SIP$demindex,0,
#'                      ifelse(SIP$demindex < SIP$dist111 &
#'                               SIP$demindex < SIP$distmid,1,
#'                             ifelse(SIP$dist111 < SIP$distmid &
#'                                      SIP$dist111 < SIP$demindex,2,NA)))
#' 
#' library(survival);library(eha)
#' #This should replicate table 1 in the article, but it is not similar.
#' #scale set at 365.25 is from their .do-file.
#' Table1 <- survreg(Surv(endnd,status) ~ cluster(stsetpolid) + factor(regime)
#'                   + factor(agedummy),
#'                   data=SIP,dist="loglogistic")
#' 
#' round(exp(Table1$coefficients),2)
#' summary(Table1)
#' 
NULL 