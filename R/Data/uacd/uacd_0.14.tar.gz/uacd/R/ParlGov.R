#' ParlGov - ParlGov's data 
#' 
#' @description This is a dataset in Country-Year-Cabinet-Party-format.
#' It is created by merging four original tables from the ParlGov database: view_cabinet, view_election, view_party and election.
#' 
#' @format An unbalanced dataframe with 21085 rows and 51 columns.
#' It includes 35 countries. Most countries are covered for the period 1945 - october 2012.
#' Australia, Switzerland and Finland have data before 1940s.
#' It includes 1177 parties, 949 cabinets and 675 elections.
#' \describe{
#' \item{party_id}{ParlGov database's party ID code}
#' \item{election_id}{ParlGov database's election ID code}
#' \item{party_name_english}{Party name in english}
#' \item{election_date}{Election date. YYYY-MM-DD format}
#' \item{country_name_short}{Country name abbreviation. iso alpha format.}
#' \item{start_date}{Cabinet inauguration date. YYYY-MM-DD format}
#' \item{cabinet_name}{Cabinet name (Could have some encoding errors for certain symbols)}
#' \item{caretaker}{Caretaker government, {\strong{1)}} Yes {\strong{2)}} No}
#' \item{cabinet_party}{Party in cabinet, {\strong{1)}} Yes {\strong{2)}} No}
#' \item{prime_minister}{Prime minister's party, {\strong{1)}} Yes {\strong{2)}} No}
#' \item{seats}{Party's number of seats in parliament}
#' \item{election_seats_total}{Total number of seats in parliament}
#' \item{party_name_short}{Party name abbreviation}
#' \item{party_name}{Party name (Could have some encoding errors for certain symbols)}
#' \item{cabinet_id}{ParlGov database's cabinet ID code}
#' \item{previous_cabinet_id}{ParlGov database's cabinet ID code for previous cabinet}
#' \item{end_date}{Date when next cabinet is inaugerated, and thus when the existing cabinet steps down. This is coded by copying the {\code{start_date}} of the following.}
#' \item{censored_cab}{This dummy is created to identify cabinets that were in power at the ParlGov database's version date, "2012-10-15". These cabinets have been given "2012-10-15" as end date, but can be identified by the fact that they have value 1 on {\code{censored_cab}}}
#' \item{election_type}{Type of election. {\strong{parliament)}} National parliamentary election {\strong{ep)}} European Parliament election}
#' \item{vote_share}{Percentage of votes for the given party in the given election}
#' \item{early}{Early (snap) election before constitutionally mandated term end. {\strong{Coding of variable incomplete. Do not use it for empirical analysis}}}
#' \item{electorate}{number citizens eligible to vote}
#' \item{votes_cast}{number of votes cast in an election, including invalid and blank votes}
#' \item{votes_valid}{number of votes cast in an election, not including invalid and blank votes}
#' \item{family_name}{Party family}
#' \item{party_name_ascii}{Party name in ascii format}
#' \item{country_name}{Country name}
#' \item{left_right}{Party placement on left-right dimension.
#' Lower values indicate positions more to the left.
#' Data form Castles/Mair 1983, Huber/Inglehart 1995, Benoit/Laver 2006 and CHESS 2010}
#' \item{state_market}{Party mean value in 'regulation of economy', data from Benoit/Laver 2006 and CHESS 2010}
#' \item{liberty_authority}{Party mean value in  'libertarian/authoritarian', data from Benoit/Laver 2006 and CHESS 2010}
#' \item{eu_anti_pro}{Party mean value in 'EU integration', data from Ray 1999, Benoit/Laver 2006 and CHESS 2010}
#' \item{cabinet_seats}{Total number of seats in parliament held by cabinet parties.}
#' \item{minority_seats}{This is a dummy variable indicating if it is a minority cabinet or not, based on the cabinets share of seats in the parliament. This variable is coded 1 if {\code{cabinet_seats}} / {\code{election_seats_total}} < 0.5.}
#' \item{cabinet_votes}{This is the share of votes for cabinet parties. It is the sum of {\code{vote_share}} for parties with value 1 on {\code{cabinet_party}}}.
#' \item{minority_votes}{This is a dummy variable indicating if a cabinet got less than 50 percent of the votes. It coded so that entries with a value less than 50 on {\code{cabinet_votes}} get 1.}
#' \item{cumulative_election_cabinets}{This variable counts the number of cabinets within an election period. It is coded so that if the {\code{cabinet_id}} changes while {\code{election_id}} stays the same, it adds 1 to this variable.}
#' \item{total_election_cabinets}{This variable is the total number of cabinets that sat during the given election period. It is coded by copying the given elections max value on the {\code{cumulative_election_cabinets}} to all other rows for that election.}
#' \item{total_cabinet_parties}{This variable is the total number of parties in the given cabinet. It is coded by counting the number of rows with value 1 on {\code{cabinet_party}} for the given cabinet.}
#' \item{coalition_cabinet}{This is a dummy variable indicating coalition cabinets. It is coded 1 if {\code{total_cabinet_parties}} is >= 2.}
#' \item{NewCab}{This variable is coded 1 each time there is a new cabinet or a new year. This variable makes it easy to move from a [country, year, cabinet, party]-format to a [country, year, cabinet]-format. The latter format is achieved by removing all rows with value 0 on {\code{NewCab}}}
#' \item{cabinet_duration}{The difference between {\code{start_date}} and {\code{end_date}} in weeks.}
#' \item{Start_year}{This is the year extracted from the {\code{start_date}}-variable}
#' \item{End_year}{This is the year extracted from the {\code{end_date}}-variable}
#' \item{Election_year}{This is the year extracted from the {\code{election_date}}-variable}
#' \item{CabinetYears}{This is ({\code{End_year}} - {\code{Start_year}})+1}
#' \item{year}{Year}
#' \item{december_dummy}{This variable is 1 if the cabinet {\code{start_date}} is earlier than and {\code{end_date}} is later than or equal to
#' 31st December in the given year. See also {\code{DecemberandCensored}}}
#' \item{july_dummy}{This variable is 1 if the cabinet {\code{start_date}} is earlier than or equal to and {\code{end_date}} is later than
#' 1st July in the given year.}
#' \item{january_dummy}{This variable is 1 if the cabinet {\code{start_date}} is earlier than or equal to and {\code{end_date}} is later than
#' 1st January in the given year.}
#' \item{DecemberandCensored}{This dummy is the row sum of {\code{december_dummy}} and {\code{censored_cab}}.
#' Since the data set version is october 2012, then all observations from 2012 will be deleted if the data are
#' subsetted based on {\code{december_dummy}} only. No cabinets have existed 31. December 2012 in the data set,
#' since the data set version is 2012-10-15. Instead, subset by removing all rows with value 0 on {\code{DecemberandCensored}} }
#' } 
#' @name ParlGov
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @details There are still some errors in the data. Notice that {\code{early}} cannot be used for statistical analysis because it is not yet correctly coded by ParlGov.
#' 
#' 
#' Notice that in Slovakia in 2009, the number of valid votes recorded are almost twice of the recorded electorate size.
#' @references Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' @source ParlGov online: \url{http://www.parlgov.org/stable/documentation/table.1.html}
#' @keywords dataset cabinet election party position parliament
#' @seealso Party, Cabinet, Election, ElectionandVoting, acquire, CahibubInvestiture
#' @examples
#' data(ParlGov)
#' 
#' # Get a [country, year, cabinet]-format:
#' CabinetFormat <- ParlGov[which(ParlGov$NewCab==1),]
#' 
#' # Get only those cabinets who were in power mid-year:
#' MidCabinetFormat <- CabinetFormat[which(CabinetFormat$july_dummy==1),]
#' 
#' # Get only those cabinets who were in power at the end of the year in addition to
#' # censored cabinets in 2012:
#' EndCabinetFormat <- CabinetFormat[which(CabinetFormat$DecemberandCensored!=0),]
#' 
#' 
#'
#' 
#' # This examples test if different governments have different success in employment policies.
#' data(ParlGov)
#' data(WEO)
#' WEO <- WEO[,c("ISO","Year","unemployment_per")]
#' 
#' DecemberGovs <- ParlGov[which(ParlGov$DecemberandCensored!=0 & ParlGov$year>=1945),]
#' 
#' GovEmploy <- merge(DecemberGovs,WEO,by.x=c("year","country_name_short"),
#'                    by.y=c("Year","ISO"),all.x=TRUE)
#' 
#' GovEmploy <- GovEmploy[order(GovEmploy$country_name_short,GovEmploy$year),]
#' GovEY <- GovEmploy[!duplicated(GovEmploy[,c("country_name_short","year")]),]
#' 
#' GovEY$unemployment_per <- as.numeric(as.character(GovEY$unemployment_per))
#' GovEY$cumulative_election_cabinets <- as.numeric(as.character(GovEY$cumulative_election_cabinet))
#' GovEY$total_cabinet_parties <- as.numeric(as.character(GovEY$total_cabinet_parties))
#' 
#' #OLS fixed effects model
#' emp <- lm(unemployment_per ~ minority_seats + coalition_cabinet
#'           + cumulative_election_cabinets + total_cabinet_parties
#'           + factor(country_name_short) + factor(year),data=GovEY)
#' summary(emp)
NULL