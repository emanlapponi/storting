#' WEO - World Economic Outlook
#' 
#' @description World Economic Outlook from International Monetary Fund
#' @format A dataframe with 7332 rows and 50 variables.
#' It includes 188 countries between 1980 - 2018 (some cells have estimated values and are not observed).
#' \describe{
#' 
#' \item{WEO_ccode}{Country code from World Economic Outlook}
#' \item{Country}{Country name}
#' \item{ISO}{Country abbreviation in ISO encoding}
#' \item{Year}{Year}
#' \item{balance}{Current account balance in US Dollars. Scale: Billions. WEO subject code: BCA}
#' \item{balance_per}{Current account balance as percent of GDP. WEO subject code: BCG_NGDPD}
#' \item{offered_rate}{Six-month London interbank offered rate (LIBOR) in percent. WEO subject code: FLIBORG6}
#' \item{revenue}{General government revenue in national currency Scale: Billions. WEO subject code: GGR}
#' \item{revenue_per}{General government revenue as percent of GDP. WEO subject code: GGR_NPGDP}
#' \item{structural_balance}{General government structural balance in national currency Scale: Billions. WEO subject code: GGSB}
#' \item{structural_balance_per}{General government structural balance as percent of GDP. WEO subject code: GGSB_NPGDP}
#' \item{gov_expend}{General government total expenditure in  national currency Scale: Billions. WEO subject code: GGX}
#' \item{gov_expend_per}{General government total expenditure as percent of GDP. WEO subject code: GGX_NGDP}
#' \item{loans}{General government net lending/borrowing in national currency Scale: Billions. WEO subject code: GGXCNL}
#' \item{loans_per}{General government net lending/borrowing as percent of GDP. WEO subject code: GGXCNL_NGDP}
#' \item{primary_loans}{General government primary net lending/borrowing in national currency Scale: Billions. WEO subject code:GGXONLB}
#' \item{primary_loans_per}{General government primary net lending/borrowing as percent of GDP. WEO subject code: GGXONLB_NGDP}
#' \item{gross_debt}{General government gross debt in national currency Scale: Billions. WEO subject code: GGXWDG}
#' \item{gross_debt_per}{General government gross debt as percent of GDP. WEO subject code: GGXWDG_NGDP}
#' \item{net_debt}{General government net debt in national currency Scale: Billions. WEO subject code: GGXWDN}
#' \item{net_debt_per}{General government net debt as percent of GDP. WEO subject code: GGXWDN_NGDP}
#' \item{employment}{Employment, in persons. Scale: Millions. WEO subject code: LE}
#' \item{population}{Population, in persons. Scale: Millions. WEO subject code: LR}
#' \item{unemployment_per}{Unemployment rate as percent of total labor force. WEO subject code: LUR}
#' \item{output_gap}{Output gap in percent of potential GDP. WEO subject code: NGAP_NPGDP}
#' \item{GDP_current}{Gross domestic product, current prices in national currency Scale: Billions. WEO subject code: NGDP}
#' \item{GDP_deflator}{Gross domestic product, deflator index. WEO subject code: NGDP_D}
#' \item{GDP_fiscal_year}{Gross domestic product corresponding to fiscal year, current prices in national currency. Scale: Billions. WEO subject code: NGDP_FY}
#' \item{GDP_constant}{Gross domestic product, constant prices in national currency. Scale: Billions. WEO subject code: NGDP_R}
#' \item{GDP_constant_per}{Gross domestic product, constant prices, in percent change. WEO subject code: NGDP_RPCH}
#' \item{GDP_current_us}{Gross domestic product, current prices in US dollars. WEO subject code: NGDPD}
#' \item{GDPpc_current_us}{Gross domestic product per capita, current prices  in US dollars. WEO subject code: NGDPDPC}
#' \item{GDPpc_current}{Gross domestic product per capita, current prices in national currency. WEO subject code: NGDPPC}
#' \item{GDPpc_constant}{Gross domestic product per capita, constant prices in national currency. WEO subject code: NGDPRPC}
#' \item{savings_per}{Gross national savings as percent of GDP. WEO subject code: NGSD_NGDP}
#' \item{investment_per}{Total investment as percent of GDP. WEO subject code: NID_NGDP}
#' \item{inflation_average}{Inflation index, average consumer prices. WEO subject code: PCPI}
#' \item{inflation_end}{Inflation index, end of period consumer prices. WEO subject code: PCPIE}
#' \item{inflation_end_per}{Inflation, end of period consumer prices, as percent change. WEO subject code: PCPIEPCH}
#' \item{inflation_average_per}{Inflation, average consumer prices, as percent change. WEO subject code: PCPIPCH}
#' \item{implied_PPP}{Implied PPP conversion rate, in national currency per current international dollar. WEO subject code: PPPEX}
#' \item{GDP_PPP}{Gross domestic product based on purchasing-power-parity (PPP) valuation of country GDP, in current international dollar. Scale: Billions. WEO subject code: PPPGDP}
#' \item{GDPpc_PPP}{Gross domestic product based on purchasing-power-parity (PPP) per capita GDP in current international dollar. WEO subject code: PPPPC}
#' \item{GDP_PPP_per}{Gross domestic product based on purchasing-power-parity (PPP) share of world total, percent. WEO subject code: PPPSH}
#' \item{import_per}{Volume of imports of goods and services, in percent change. WEO subject code: TM_RPCH}
#' \item{goods_import_per}{Volume of Imports of goods, in percent change. WEO subject code: TMG_RPCH}
#' \item{oil_import_us}{Value of oil imports in US dollars. Scale: Billions. WEO subject code: TMGO}
#' \item{export_per}{Volume of exports of goods and services in percent change. WEO subject code: TX_RPCH}
#' \item{goods_export_per}{Volume of exports of goods in percent change. WEO subject code: TXG_RPCH}
#' \item{oil_export_us}{Value of oil exports in US dollars. Scale: Billions. WEO subject code: TXGO}
#' 
#'  } 
#' @name WEO
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @details Data set verison April 16 2013. NB! Some values are predicted estimates. There are differences between the countries, and some country-variables are estimated for the whole period. Check \link{WEOOriginal} before analysis. 
#' @references 
#' IMF homepage: \url{https://files.nyu.edu/mrg217/public/elections.html}
#' @keywords dataset economy
#' @source Project homepage: \url{http://www.imf.org/external/pubs/ft/weo/2013/01/weodata/index.aspx}
#' @seealso WEOOriginal
#' @examples
#' # This examples test if different governments have different success in employment policies.
#' data(ParlGov)
#' data(WEO)
#' WEO <- WEO[,c("ISO","Year","unemployment_per")]
#' 
#' DecemberGovs <- ParlGov[which(ParlGov$DecemberandCensored!=0 & ParlGov$year>=1945),]
#' 
#' GovEmploy <- merge(DecemberGovs,WEO,by.x=c("year","country_name_short"),
#'                    by.y=c("Year","ISO"),all.x=TRUE)
#' 
#' GovEmploy <- GovEmploy[order(GovEmploy$country_name_short,GovEmploy$year),]
#' GovEY <- GovEmploy[!duplicated(GovEmploy[,c("country_name_short","year")]),]
#' 
#' GovEY$unemployment_per <- as.numeric(as.character(GovEY$unemployment_per))
#' GovEY$cumulative_election_cabinets <- as.numeric(as.character(GovEY$cumulative_election_cabinets))
#' GovEY$total_cabinet_parties <- as.numeric(as.character(GovEY$total_cabinet_parties))
#' 
#' # OLS fixed effects model
#' emp <- lm(unemployment_per ~ minority_seats + coalition_cabinet
#'           + cumulative_election_cabinets + total_cabinet_parties
#'           + factor(country_name_short) + factor(year),data=GovEY)
#' summary(emp)
NULL