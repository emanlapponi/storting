#' VanbergCoPol - Replication data for "Coalition Policymaking and Legislative Review"
#' 
#' @description Lanny W. Martin and Gerog Vanbergs replication data for "Coalition Policymaking and Legislative Review"
#' @format A dataframe with 337 rows and 58 variables.
#' Each row is a unique government bill in Netherlands (1982 - 1994) or Germany (1983 - 1994).
#' \describe{
#' \item{intrnrefn}{No info found}
#' \item{lciep}{No info found}
#' \item{agendadur}{No info found}
#' \item{lnagendadur}{No info found}
#' \item{dim1}{No info found. By inspection this seems to be a categorical variables indacting the dimension. Thus this is a substitute for the dimensions dummies (later in this document)}
#' \item{ministry}{No info found}
#' \item{censorlow}{The "end" of a bill. However, it is uncertain whether value 1 implies passed or defeated (or expired).}
#' \item{censorup}{No info found}
#' \item{length1}{Expiration of bill before the plenary vote}
#' \item{length2}{No info found}
#' \item{censor}{No info found}
#' \item{nocomm}{Number of committees to which the government bill is referred.}
#' \item{govt}{No info found}
#' \item{policing}{No info found}
#' \item{no_pages}{No info found}
#' \item{pageperart}{No info found}
#' \item{pageperart_std}{No info found}
#' \item{logno_articles}{Number of articles in the draft bill logged}
#' \item{no_articles}{Number of articles in the draft bill}
#' \item{no_changed}{No info found}
#' \item{no_stricken}{No info found}
#' \item{no_added}{No info found}
#' \item{totalchanges_wyes}{Number of articles in the bill that were changed during the lagislation process}
#' \item{totalchanges__wno}{No info found}
#' \item{country}{Country. Germany or Netherlands}
#' \item{germany}{Dummy for Germany}
#' \item{consent}{No info found}
#' \item{cabinit}{No info found}
#' \item{brgovcontrol}{No info found}
#' \item{brgovdontrol2}{No info found}
#' \item{lnlength1}{No info found}
#' \item{minister}{No info found}
#' \item{minweigth}{No info found}
#' \item{ptnrweight}{No info found}
#' \item{jmpartner}{Dummy indicating if the ministry from which the draft bill is initiated contains a junior minister from the partner party of the proposing minister}
#' \item{coaldiv}{No info found}
#' \item{wcoaldiv}{No info found}
#' \item{minsal}{No info found}
#' \item{minrelsal}{No info found}
#' \item{wlegimp}{No info found}
#' \item{coalimp}{No info found}
#' \item{wcoalimp}{Government issue saliency. The issue saliency of the bill for coalition members. OBS: Documentation from \link{VanbergPolBarg} - it is assumed that variables with equal names in these two data sets are equal}
#' \item{divsal}{No info found}
#' \item{wdivsal}{Government issue divisiveness. Ideological divergence within a coalition.}
#' \item{woppdist}{No info found}
#' \item{woppimp}{Opposition issue saliency. Saliency of the issue from the point of the opposition. OBS: Documentation from \link{VanbergPolBarg} - it is assumed that variables with equal names in these two data sets are equal }
#' \item{woppdivsal}{Opposition issue divisiveness. Ideological differences between the parties in the opposition and the minister responsible for initiating the bill}
#' \item{dimension1}{Tax policy type of bill dummy. Income taxes, the value-added tax, tax allowances, welfare or health services benefits, disabled workers benefits, family allowances.}
#' \item{dimension2}{Foreign policy type of bill dummy. Relations with the Soviet Union or Warsaw Pact, cooperation with NATO initiatives relevant to East-West relations (Note: No bills after 1989 were collected on this dimension)}
#' \item{dimension3}{Industrial policy type of bill dummy. Industrial production levels, industrial relations, state-owned corporations, market (de) regulation, unions and employer associations, wage policy, job training, conomic competitiveness}
#' \item{dimension4}{Social policy type of bill dummy. Abortion, homosexuality, alternative lifestyles, domestic cohabitation, pornography, moral issues}
#' \item{dimension5}{Clerical policy type of bill dummy. State intervention into religious affairs (Note: in the current sample, no legislation falls into this category. All entries are zero)}
#' \item{dimension6}{Agricultural policy type of bill dummy. Price regulation of agricultural goods, agricultural subsidies, quotas on agricultural products}
#' \item{dimension7}{Regional policy type of bill dummy. Centralization or decentralization, alterations to municipal or regional laws, redistricting of communal boundaries, regional institutional reforms}
#' \item{dimension8}{Environmental policy type of bill dummy. Air, soil, or water pollution, regulation of emissions standards, chlorofluorocarbons, ecological preservation}
#' 
#' }
#' @details This is a data set over changes made to ministerial draft bills in the course of parliamentary review in Germany (1983 - 1994) and Netherlands (1982 - 1994).
#' 
#' The data set includes many variables that are not included in the article, and no other codebook has been found. Therefore, this document still lacks information for these variables. If you have information about the operationalization of these variables, please contact the uacd-team.
#' @name VanbergCoPol
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Martin, W. Lanny and Georg Vanberg (2005). "Coalition Policymaking and Legislative Review" in \emph{American Political Science Review} Vol. 99 No. 1, p. 93 - 106
#' @keywords dataset parliament policy
#' @source Georg Vanbergs homepage: \url{http://people.duke.edu/~gsv5/styled-2/index.html}
#' @seealso VanbergPolBarg VanbergIdeology
#' @examples
#' # This example replicates the Negative binomial model in table 2 page 102 in the article.
#' 
#' data(VanbergCoPol)
#' library(MASS)
#' 
#' # Page 101 in article they claim to run a overdispersion negative binomial:
#' summary(glm.nb(totalchanges_wyes ~ wdivsal + woppdivsal + factor(jmpartner) + nocomm
#'                  + logno_articles + length1 + censor + factor(germany)
#'                  + factor(dimension2) + factor(dimension3) + factor(dimension4)
#'                  + factor(dimension6) + factor(dimension7) + factor(dimension8), data=VanbergCoPol))
#' # Results are (quite) similar
NULL