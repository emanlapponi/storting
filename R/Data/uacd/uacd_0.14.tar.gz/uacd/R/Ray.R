#' Ray - Ray, Marks/Steenberg Party Dataset
#' 
#' @description This dataset combines the data from Leonard Ray for 1984, 1988, 1992, 1996 with the data collected by Gary Marks and Marco Steenbergen for 1999 (with the help of Liesbet Hooghe, DavidScott, and Carole Wilson.)
#' @format A dataframe with 686 rows and 26 variables.
#' It includes 184 parties from 14 countries.
#' For full documentation, see \url{http://chesdata.eu/}
#' \describe{
#' 
#' \item{eastwest}{Eastern or western Europe.}
#' \item{eumember}{Membership status.}
#' \item{country}{Two- or Three-letter country abbreviation}
#' \item{expert}{Number of experts who evaluated this party}
#' \item{var00001}{Not in codebook.}
#' \item{party_id}{Party id}
#' \item{year}{Year expert was asked to evaluate the party}
#' \item{party}{Party name abbreviation}
#' \item{vote}{Share of votes party got in the election most prior to the year.}
#' \item{family}{classification is primarily based on Hix and Lord (1997), except that they place confessional and agrarian parties in separate categories.
#' Family association for parties in Central/Eastern Europe is based primarily on Derksen classification (now incorporated in Wikipedia), triangulated by
#' a) membership or affiliation with international and EU party associations, and b) self-identification.}
#' \item{position}{overall orientation of the party leadership towards European integration, from 1 - 7 where 7 is most in favor of integration.}
#' \item{salience1}{relative salience of European integration in the party’s public stance. 1 - 5 where 5 indicates high importance.}
#' \item{dissent1}{degree of dissent in party on European integration. 1 - 5 where 5 represents extreme division.}
#' \item{future}{stance of a party in 1999 on the future of European integration [1999 only]}
#' \item{ep}{position of the party leadership on the powers of the European Parliament. 1 - 7 where 7 indicates strong favor for power to the European parliament.}
#' \item{fiscal}{Position of party leadership on tax harmonization in the EU.
#' Higher value indicate more in favor of tax harmonization. Only asked in 1999}
#' \item{employ}{Position of party leadership on common employment policy in EU. Higher value indicate more in favor of employment policy. Only asked in 2002}
#' \item{ecohesion}{position of the party leadership on EU cohesion or regional policy (e.g. the structural funds). 1 - 7 where 7 indicates strong favor for cohesion.}
#' \item{environ}{Position of party leadership on common EU environmental policy. Higher value indicate more in favor of common EU environmental policy. Only asked in 1999 and 2002}
#' \item{asylum}{osition of party leadership on common policy on political asylum. Higher value indicate more in favor of common policy on political asylum. Only asked in 1999 and 2002}
#' \item{foreign}{position of the party leadership on EU foreign and security policy. 1 - 7 where 7 indicates strong favor for common EU policy.}
#' \item{eu_turkey}{position of the party leadership on EU enlargement to Turkey. 1 - 7 where 7 is most favorable to enlargement. Only asked in 2006 and 2010}
#' \item{lrgen}{Overall ideological left-right placement. 0=Extreme left, 10=Extreme Right}
#' \item{lrecon}{position of the party in terms of its ideological stance on economic issues. Parties can be classified in terms of their stance on economic issues. Parties on the economic left want government to play an active role in the economy. Parties on the economic right emphasize a reduced economic role for government: privatization, lower taxes, less regulation, less government spending, and a leaner welfare state. 0 = extreme left, 10 = extreme right.}
#' \item{galtan}{position of the party in terms of of their views on democratic freedoms and rights. “Libertarian” or “postmaterialist” parties favor expanded personal freedoms, for example, access to abortion, active euthanasia, same-sex marriage, or greater democratic participation. “Traditional” or “authoritarian” parties often reject these ideas; they value order, tradition, and stability, and believe that the government should be a firm moral authority on social and cultural issues. 0 = Libertarian/postmaterialst, 10=Traditional/Authoritarian}
#' \item{pro_anti}{Variable \code{position} recoded into a trichotomous variable.0 = anti, 1 = netural, 2 = pro}
#'  } 
#' @name Ray
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references 
#' Budge, Ian, Hans-Dieter Klingemann, Andrea Volkens, Judith Bara. 2001. Mapping Policy Preferences : Estimates for Parties, Electors, and Governments, 1945-1998. Oxford: Oxford University Press.
#' 
#' Castles, Francis G., and Peter Mair. 1984. “Left-Right Political Scales: Some 'Expert' Judgments.” European Journal of Political Research 12 (1): 73-88.
#' 
#' Huber, John, and Ronald Inglehart. 1995. “Expert Interpretations of Party Space and Party Locations in 42 Societies.” Party Politics 1 (1): 73-111.
#' 
#' Ray, Leonard. 1999. “Measuring Party Orientations toward European Integration: Results from an Expert Survey.” European Journal of Political Research 36(3): 283-306
#' @source \url{http://chesdata.eu/} 
#' @seealso \link{CHES} \link{ChapelHill2010} \link{ChapelHill2006} \link{ChapelHill2002} \link{ChapelHill1999} 
#' @keywords dataset party position
#' @examples
#' library(uacd)
#' data(Ray)
NULL