#' ManifestoFull - The Full Manifesto Project Dataset (v.2012b)
#' 
#' @description This is the Full Manifesto Project Dataset (v.2012b) dataset which covers 3611 political party manifestos 
#' for 905 parties over 623 elections in 55 countries. It covers various free and	competitive	elections	between	1920 and 2012. 
#' Note that per1011 –	per7062 are subcategories for CEE countries. For comparisons	between	OECD and CEE countries,	
#' subcategories can be	aggregated	into	one	of	the	56	standard	categories	used	in	all	countries.
#' Hint: If you are searching for dataset files that cover only the most recent update or all 
#' updates since MPPII you can simply download the most recent full dataset and use the variable 
#' dataset_origin to filter the observations in that sense. For full documentation see the origninal codebook at 
#' \url{https://manifestoproject.wzb.eu/. }
#' @format An unbalanced dataframe with 3611 rows and 137 variables.
#' It includes 905 parties from 623 elections in 55 countries.
#' The data frame is in country-election-party format.
#' \describe{
#' 
#' \item{country}{Two-digit country code.}
#' \item{countryname}{Name of country in English	(string	variable).}
#' \item{edate}{In the original codebook: Day, month,	and	year	of	national	election	(DD.MM.YY). In our dataset this variable is a 
#' numeric variable that counts the number of days since January 1, 1960. See the below example for conversion.}
#' \item{date}{Year and month	of	national election, in format: yyyymm. }
#' \item{party}{The party	identification	 code	 consists of six digits.	The	 first	
#' three	digits	 repeat	 the	country	code.	The	 third,	fourth,	and	 fifth	digits	are	running	numbers.}
#' \item{partyname}{Abbreviations of	 names of	 parties in	 original	 language	 and	names	of	
#' parties	in	English	(string	variable).}
#' \item{parfam}{Tentative grouping	of	political	parties	and	alliances	into	the	following	party	families: 
#' 10 = Ecology parties; 20 = Communist parties, 30 = Social democratic	parties; 40 = Liberal parties; 
#' 50 = Christian democratic	parties; 60=Conservative parties; 70 = Nationalist parties; 80 = Agrarian parties;
#' 90 = Ethnic and	regional	parties; 95=Special issue	parties; 98/00 = Electoral alliances	of	divers	origin	
#' without	dominant	party; 999 = Missing information. }
#' \item{coderid}{Identification number	of	coder, three	digit	code: First digit: 1	=	MRG/CMP	group	member; 
#' 2 = hired	coder; 8 = specifically	trained	coder. }
#' \item{coderyear}{Year during	which	codings	took	place. }
#' \item{manual}{Codings based	on	manual	version	0	(no	manual),	1,	2,	or	3.}
#' \item{testresult}{Result of	entry test as	 given in	 coding	 handbook:	 test	 of	
#' reliability	in	 comparison	 to	 the	master copy, Krippendorff’s	Alpha	for	ordinal	data:
#' -1.00 very bad; +1.00 very good; 999 no handbook	during	first	phase	of	codings/no	test	by	MRG	member.}
#' \item{pervote}{Percentage of	votes	gained	 by	each	 party;	in CEE	countries	
#' also	percentage	of	votes	gained	by	parties	or	party	blocs;	for	mixed	 electoral systems	 with	 a	 
#' proportional	 and	a	majoritarian	component	votes	 for	proportional	component, only; 
#' no votes	available	Northern	Ireland,	Sri	Lanka, Belarus 1995	and	Montenegro	1990.	}
#' \item{voteest}{0: As a	rule,	election statistics	present	votes	and	seats	for	each	
#' party	in parliament. However, in	CEE	 countries	 electoral	coalitions	are	quite	frequent	 
#' so	 that votes and	 seats are	available	for	blocs	of	parties,	only. 1: In OECD	 countries, blocs	 of	 
#' parties are less	frequent and	seats	are	given	for	each single party	in the electoral	
#' coalition.	 In	 these	 cases,	 votes for parties in	 electoral coalitions	 have	 been	 estimated	
#' on	 the basis of	the	distribution of seats	between	them.}
#' \item{presvote}{Percentage of	 votes	 in	 presidential	elections;	 for	USA	 only,	998	for	all	other	countries. }
#' \item{absseat}{Absolute number	of	seats	held	by	each	party	or	party	bloc;	999	
#' not	available	for	Northern	Ireland	and	Sri	Lanka. }
#' \item{totseats}{Total number	of	seats	in	parliament; 999	not	available	for	Northern	Ireland	and	Sri	Lanka.}
#' \item{progtype}{1: Program of	a	single	party; 2: Program of	two	or	more	parties; 3: Estimate; 4: 
#' Program taken	 from	 main	 party	of	electoral	coalition; 5: Average of	all	members	of	an	electoral	coalition;
#' 6: General program; 8: Party bloc	program; 9: Other type	of	program; 99: Missing program. }
#' \item{datasetorigin}{10: MPPI; 20: MPPII; 30: Update 2009; 40: Update 2010; 41: Update 2010b; 50: Update 2011a; 
#' 51: Update 2011b; 60: Update 2012a; 61: Update 2012b; 100: MPPI+MPPII. }
#' \item{per101}{Foreign Special	Relationships:	Positive. Favourable mentions	of	particular	countries	with	which	 the	
#' manifesto	country	has	a	special	relationship.	For	example, in the	British	 case: former	 colonies; in	 the	German case: East	
#' Germany;	in	the	Swedish	 case: the	rest	of	Scandinavia; the	need	for	cooperation	with	and/or aid	to such	countries.}
#' \item{per102}{Foreign Special	Relationships:	Negative. Negative mentions	 of	 particular	 countries	 with	 which	 the	
#' manifesto	 country	 has	 a	 special	relationship;	 otherwise	 as	101,	but	negative. }
#' \item{per103}{Anti-Imperialism: Positive. Negative references	 to	 exerting	 strong	 influence	 (political,
#' military	 or	 commercial)	over other states;	negative	references	to	controlling	other	countries	as	if	they	were
#' 	part of	 an	 empire; avourable mentions	 of	 decolonisation;	favourable	references	to	greater	self-government and	
#' independence	 for	colonies;	 negative	 references	 to	 the	imperial	behaviour	of	the	manifesto	and/or other	countries.}
#' \item{per104}{Military: Positive. Need to	maintain	 or	 increase	 military	 expenditure;	modernising	 armed	forces and
#' improvement	 in	 military	strength;	 rearmament	 and	self-defence; need	 to	 keep	military treaty	 obligations;	 
#' need	 to	 secure	 adequate	manpower in	the	military;	importance	external	security.}
#' \item{per105}{Military: Negative. Favourable mentions	 of	 decreasing	 military	 expenditures; 
#' disarmament;	 “evils	 of	 war”;	 promises	 to	 reduce	conscription,	otherwise	as	104,	but	negative.}
#' \item{per106}{Peace: Positive. Peace as	a	general	goal;	declarations	of	belief	in	peace	and	
#' peaceful	 means	 of	 solving	 crises;	 desirability	 of	 countries	joining	in	negotiations	with	hostile	countries.}
#' \item{per107}{Internationalism: Positive. Need for	 international	 cooperation;	 cooperation	 with	specific	 countries	 other	 than	 those	 coded	 in	 101;	 need	 for	
#' aid	 to	 developing	 countries;	 need	 for	world	 planning	 of	resources;	 need	 for	 international	
#' courts; support for	 any	international	goal or	world	state;	support	for	UN.}
#' \item{per108}{European Community/Union:	Positive. Favourable mentions	 of	 European	 Community/Union in	general;	
#' desirability	 of	 expanding	 the	 European	Community/Union	 and/or	 of	 increasing	 its	 competence; 
#' desirability	of	expanding	 the	competences	of	 the	European	Parliament; desirability	of	 the	manifesto	country	joining	
#' (or remaining	a	member).}
#' \item{per109}{Internationalism: Negative. Favourable mentions of	 national	 independence	 and	
#' sovereignty	 as	 opposed	 to	 internationalism;	 otherwise	as	107,	but	negative.}
#' \item{per110}{European Community/Union:	Negative. Hostile mentions	of the European	 Community/Union;	
#' opposition	to	specific	European	policies	which	are	preferred	by	European	authorities; opposition	to	the	net-contribution	
#' of the	 manifesto	 country	 to	 the	 EU	 budget; otherwise as	108,	but	negative.}
#' \item{per201}{Freedom and	Human	Rights. Favourable mentions	 of	 importance	 of	 personal	 freedom	
#' and	civil	rights;	freedom	from	bureaucratic	control;	freedom	of speech; freedom	from	coercion	in the political and	
#' economic spheres;	 individualism	 in	 the	manifesto	country	and	in	other	countries.}
#' \item{per202}{Democracy. Favourable mentions	 of	 democracy as	 a	method	 or	 goal	 in	
#' national	and	other	organisations;	involvement	of	all	citizens	in decision-making,	 
#' as	 well	 as	 generalised	 support for the	manifesto	country’s	democracy.}
#' \item{per203}{Constitutionalism: Positive. Support for	 specific	 aspects of	 the	constitution;	 use of	
#' constitutionalism	as	 an	 argument for policy	 as	 well	 as	
#' general	approval of	the	constitutional	way	of	doing	things.}
#' \item{per204}{Constitutionalism: Negative. Opposition to	 the	 constitution	 in	 general	 or	 to	 specific	
#' aspects;	otherwise	as	203,	but	negative. }
#' \item{per301}{Decentralisation. Support for federalism	 or	 devolution;	 more	 regional	autonomy for
#' policy	 or	 economy;	 support for keeping	up	local	 and	regional	customs	 and	symbols; favourable
#' mentions	of	special	consideration	for	local	areas;	deference	to local expertise;	 favourable	 mentions	 of 
#' the territorial	subsidiary	principle.}
#' \item{per302}{Centralisation. Opposition to	 political	 decision-making	 at	 lower	 political 
#' levels;	support for	 more	 centralisation	 in	 political and	administrative	procedures;	otherwise	as	301,	but	negative.}
#' \item{per303}{Governmental and	Administrative	Efficiency. Need for	 efficiency	 and	 economy	 in	 government	 and	
#' administration;	 cutting	 down	 civil	 service;	 improving	governmental	 procedures;	 general	 appeal	 to	 make	 the	
#' process of	 government	 and	administration	 cheaper	and	more	effective.}
#' \item{per304}{Political Corruption. Need to	 eliminate	 corruption,	 and	associated	 abuse,	 in	political	and	public	life.}
#' \item{per305}{Political Authority. Favourable mentions	 of	 strong	 government,	including	
#' government	 stability;	 manifesto	 party’s	 competence	 to	govern	and/or	other	party’s	lack	of	such	competence.}
#' \item{per401}{Free Enterprise. Favourable mentions	 of	 free	 enterprise	 capitalism;	
#' superiority	 of	 individual	 enterprise	 over	 state	 and	 control	systems;	favourable	 mentions	 of	 
#' private property	 rights,	personal	 enterprise	 and initiative; need	 for unhampered	individual	enterprises.}
#' \item{per402}{Incentives. Need for	 wage	 and tax policies	 to	 induce	 enterprise;	
#' encouragement	to	 start enterprises;	 need	 for	financial	and	other	incentives	such	as	subsidies.}
#' \item{per403}{Market Regulation. Need for regulations designed	 to	 make	 private	 enterprises
#' work	 better;	actions	 against	 monopolies	 and	 trusts, and in	defence	 of	 consumer	 and	 small	business;	 
#' encouraging	economic	competition;	social	market	economy.}
#' \item{per404}{Economic Planning. Favourable mentions	of	long-standing	economic	planning	of	
#' a	consultative	or	indicative	nature,	need for	government	to	create	such	a	plan.}
#' \item{per405}{Corporatism. Favourable mentions	 of	 the	 need	 for the	collaboration	 of	
#' employers and trade	union	 organisations	in	overall	economic planning	 and	direction	 through the
#' medium	 of	tripartite bodies	 of	 government,	employers, and trade	unions.	This	category	was	 not	used for	
#' Austria	 up	 to	 1979,	for	New	Zealand	up	to	1981,	and	for	Sweden	up	to	1988.}
#' \item{per406}{Protectionism: Positive. Favourable mentions	of	extension	or	maintenance	of	tariffs	
#' to	 protect	 internal	 markets;	 other	 domestic	 economic	protectionism	such	as	quota	restrictions.}
#' \item{per407}{Protectionism: Negative. Support for	the	concept	of	free	trade;	otherwise	as	406,	but	negative.}
#' \item{per408}{Economic Goals. Statements of intent	 to	 pursue	 any economic	 goals	not	
#' covered	by	other	 categories	 in	 domain	 4.	 This	 category	 is	
#' created	to	catch	an	overall	interest	of	parties	in	economics	and,	therefore,	covers	a	variety	of	economic	goals.}
#' \item{per409}{Keynesian Demand	Management. Demand-oriented economic	policy;	economic	policy	devoted	to	the	 reduction	
#' of	 depressions	 and/or	 to	 increase	 private	demand	 through	 increasing	 public	 demand	 and/or	 through	
#' increasing	social	expenditures.}
#' \item{per410}{Productivity. Need to	encourage	or	facilitate	greater	production;	need	to take measures	to	aid	this;	
#' appeal	for	greater	production	and	importance	 of	 productivity	 to	 the	 economy;	 increasing	
#' foreign	trade;	the	paradigm	of	growth.}
#' \item{per411}{Technology and	Infrastructure. Importance of	 modernisation of	industry	and	 methods	 of	
#' transport	 and	 communication;	 importance	 of	 science	 and	technological	developments	in	 industry; need	 for training	
#' and	research.	This	does	not	imply	education	in	general	(see category	 506). This	 also	 covers	 public	 spending	 on	
#' infrastructure	such	as	streets	and	harbours.}
#' \item{per412}{Controlled Economy. General need	 for	 direct	 government	 control	of	economy;	
#' control	over	prices,	wages,	rents,	etc;	state	intervention	into	the	economic	system.}
#' \item{per413}{Nationalisation. Favourable mentions	 of	 government	 ownership,	 partial or	
#' complete,	including	government	ownership	of	land.}
#' \item{per414}{Economic Orthodoxy. Need for	 traditional	 economic	 orthodoxy, e.g.	reduction	of	budget 
#' deficits, retrenchment	 in	 crisis,	 thrift	 and	 savings;	support	 for traditional economic	institutions such	as stock	
#' market	and	banking	system;	support	for	strong currency.}
#' \item{per415}{Marxist Analysis. Positive references	(typically but not	necessary	 by	communist	 parties)	 to	 the	 specific	 
#' use	 of	 Marxist-Leninist terminology	 and	 analysis	 of	 situations	which	 are	otherwise	uncodable.	
#' This category	 was	 not	 used	 for	 Austria	 1945-1979,	for	Australia, Japan	and	the	United	States	up	to	1980;	
#' for	 Belgium,	Ireland,	The	Netherlands	and	New	 Zealand up	to	1981;	for Italy	 and Britain	 up	 to	 1983; 
#' for	Denmark,	Luxembourg	and	Israel up	 to	 1984; for Canada,	France	and	Sweden	up	to	1988.}
#' \item{per416}{Anti-Growth Economy:	Positive. Favourable mentions	of	anti-growth	politics	and	steady	state	
#' economy;	 sustainable	development.	This category	 was not	used for Austria	1945-1979,	for Australia,	
#' Japan	 and	the	United	States up	 to	1980;	for	Belgium, Ireland,	The	Netherlands	 and	New	 Zealand
#' up	 to	 1981;	for	 Italy and	Britain	up	to	1983;	 for	Denmark,	Luxembourg	and	Israel	up	to	1984;	for	Canada,	
#' France	and	Sweden	up	to	1988;	and	for	Norway	up	to	1989.	Test	codings,	however,	have	shown	that	
#' parties	 before	 the beginning	 of	 the	 1990s	 hardly	 ever	advocated	anti-growth	policies.}
#' \item{per501}{Environmental Protection. Preservation of countryside,	 forests,	 etc.;	general 
#' preservation	 of	 natural	 resources against selfish	interests;	proper	use	of	national	parks;	soil banks,	etc;	
#' environmental	improvement.}
#' \item{per502}{Culture. Need to	 provide cultural	and	leisure	facilities including	arts and	sport; 
#' need	 to	spend	money	on	museums,	art	galleries	etc.;	need	to	encourage worthwhile leisure activities and	cultural	mass	media.}
#' \item{per503}{Social Justice. Concept of	equality; need for fair	 treatment of all	people;	
#' special protection	for underprivileged;	 need	 for fair	distribution of	 resources;	removal	of class 
#' barriers; end of	discrimination	such	as	racial	or	sexual	discrimination,	etc. }
#' \item{per504}{Welfare State	Expansion. Favourable mentions	of need	 to	 introduce,	 maintain	 or	expand	any	
#' social	service	or social	security	scheme;	support	for	 social	 services	 such	 as	 health	 service or	social housing.	
#' Note: This	category	excludes	education.}
#' \item{per505}{Welfare State	Limitation. Limiting expenditure on	 social	 services	 or	 social	 security;	
#' otherwise	as	504,	but	negative. }
#' \item{per506}{Education Expansion. Need to	expand	and/or	improve	educational	provision	at	all	levels.	
#' This	excludes	technical	training	which	is	coded	under	411.}
#' \item{per507}{Education Limitation. Limiting expenditure on education; otherwise	as	506, but negative. }
#' \item{per601}{National Way	of	Life:	Positive. Appeals to patriotism	 and/or	 nationalism;	 suspension	 of	some
#' freedoms	 in	 order	to protect the state	against	subversion;	support	for	established	national	ideas.}
#' \item{per602}{National Way	of	Life:	Negative. Against patriotism	and/or nationalism;	opposition to	 the	
#' existing	national state;	otherwise	as	601,	but	negative.}
#' \item{per603}{Traditional Morality:	Positive. Favourable mentions	 of	 traditional moral values;	prohibition,	
#' censorship	 and suppression	of immorality	 and	unseemly behaviour;	 maintenance and	stability	of family;	religion.}
#' \item{per604}{Traditional Morality:	Negative. Opposition to	 traditional	moral	values;	 support	 for	divorce,	
#' abortion	etc.;	otherwise	as	603,	but	negative.}
#' \item{per605}{Law and	Order. Enforcement of	all	laws;	actions	against	crime;	support	and	
#' resources	for	police;	tougher	attitudes	in	courts;	importance	of	internal	security.}
#' \item{per606}{Social Harmony. Appeal for	national	effort	and	solidarity;	need	for	society	to	see	itself	as	
#' united;	appeal	for	public	spiritedness;	decrying	anti-social	attitudes	in	times	of	crisis;	support	for	the	public	
#' interest; favourable	mention	 of	 the civil	society	(Note: This category neither	captures	what	your	country	
#' can	do	for	you	nor	what	you	can	do	for	your	country,	but	what	you	can	do	for	your	fellow	citizens.).	}
#' \item{per607}{Multiculturalism: Positive. Cultural diversity, communalism,	 cultural	 plurality	 and	
#' pillarisation;	preservation	of	autonomy	of	religious,	linguistic	heritages	 within	 the	 country including
#' special educational	provisions.}
#' \item{per608}{Multiculturalism: Negative. Enforcement or	 encouragement	 of	 cultural	 integration;	
#' otherwise	as	607,	but	negative.}
#' \item{per701}{Labour Groups:	Positive. Favourable references	to	labour	groups, working	 class,	
#' unemployed; support	for	 trade	unions;	 good	 treatment of	manual and	other	employees.}
#' \item{per702}{Labour Groups:	Negative. Abuse of power of	 trade unions;	otherwise	 as	 701,	 but negative.}
#' \item{per703}{Farmers. Support for	 agriculture and farmers;	 any policy	 aimed	specifically	at	benefiting	these.}
#' \item{per704}{Middle Class	and	Professional	Groups. Favourable references	 to	middle	 class,	 professional	groups,	
#' such	as	physicians	or	lawyers;	old	and	new	middle	class.}
#' \item{per705}{Underprivileged Minority	Groups. Favourable references	to	underprivileged	minorities	who	are	
#' defined	neither	in	economic	nor	in	demographic	terms,	e.g.	the	handicapped,	homosexuals,	immigrants,	etc.}
#' \item{per706}{Non-economic Demographic	Groups. Favourable mentions	of,	or	need	for,	assistance	 to	women,
#' old people,	 young	 people,	 linguistic	 groups,	 etc;	 special	interest	groups	of	all	kinds.}
#' \item{per1011}{Russia/USSR/CIS: Positive. Favourable mentions	of	Russia,	the	USSR,	the	CMEA	bloc	or	
#' the	Community	of	Independent	States.}
#' \item{per1012}{Western States:	Positive. Favourable mentions	 of	 Western states,	including	 the USA	and	Germany.}
#' \item{per1013}{Eastern European	Countries:	Positive. Favourable mentions	 of	 Eastern	 European	countries	 in	general.}
#' \item{per1014}{Baltic States:	Positive. Favourable mentions	 of	 the	 Baltic	 states,	 including	 other	
#' states	bordering	the	Baltic	Sea.}
#' \item{per1015}{Nordic Council:	Positive. Favourable mentions	of	the	Nordic	Council. }
#' \item{per1016}{SFR Yugoslavia:	Positive. Favourable mentions	of	countries	formerly	belonging	to	SFR 
#' Yugoslavia	including	special	 relationships	with	Montenegro,	Macedonia,	Slovenia,	Croatia	and	Bosnia-Hercegovina.}
#' \item{per1021}{Russia/USSR/CIS: Negative. Negative mentions	of	Russia,	the	USSR	or	the	Community	of	Independent	States.}
#' \item{per1022}{Western States:	Negative. Negative mentions	of	Western	states,	including	the	USA	and	Germany.}
#' \item{per1023}{East European	Countries:	Negative. Negative mentions	of	Eastern	European	countries	in	general.}
#' \item{per1024}{Baltic States:	Negative. Negative references	to	the	Baltic	states.}
#' \item{per1025}{Nordic Council:	Negative. Negative references	to	the	Nordic	Council.}
#' \item{per1026}{SFR Yugoslavia:	Negative. Negative mentions	 of	 countries	 formerly	 belonging	 to	 SFR	
#' Yugoslavia	 including	 negative	 references	 to	 Montenegro,	Macedonia,	Slovenia,	Croatia	and	Bosnia-Hercegovina}
#' \item{per1031}{Russian Army:	Negative. Need to	withdraw	the	Russian	army	from	the	territory	of	the	manifesto	 country;	 
#' need	 to	 receive	 reparations	 for	 the	damage	 caused	 by	 the	 Russian	 army	 or	 other	 Soviet	institutions.}
#' \item{per1032}{Independence: Positive. Favourable mentions	 of	 the	 independence	 and	 sovereignty	of	the	manifesto	country.}
#' \item{per1033}{Rights of	Nations:	Positive. Favourable mentions	 of	 freedom,	 rights	 and	 interests	 of	nations.}
#' \item{per2021}{Transition to	Democracy. General references	 to	 the	 transition	 process	 of	 one-party	
#' states	to	pluralist	democracy.}
#' \item{per2022}{Restrictive Citizenship:	Positive. Favourable mentions	 of	 restrictions	 in	 citizenship;	
#' restrictions	 in	 enfranchisement	 with	 respect	 to	 (ethnic)	groups.}
#' \item{per2023}{Lax Citizenship:	Positive. Favourable mentions	of	lax	citizenship	and	election	laws;	no 
#' or	few	restrictions	in	enfranchisement.}
#' \item{per2031}{Presidential Regime:	Positive. Support for	 current	 presidential	 regime;	 statements	 in	favour	of	a	powerful	presidency.}
#' \item{per2032}{Republic: Positive. Support for	the	republican	 form	of	government	as	opposed	to	monarchy.}
#' \item{per2033}{Checks and	Balances:	Positive. Support for	checks	and	balances	and	separation	of	powers,	
#' and	specifically	for	limiting	the	powers	of	the	presidency	byincreasing	 legislative/judicial	 powers,	
#' or	 transferring	 some	executive	powers	to	the	legislature	or	judiciary.}
#' \item{per2041}{Monarchy: Positive. Support for	 a	 monarchy,	 including	 conceptions	 of	constitutional	monarchy.}
#' \item{per3011}{Republican Powers:	Positive. Favourable mentions	of	stronger	republican	powers.}
#' \item{per3051}{Public Situation:	Negative. Negative references	 to	 the	 situation	 in	 public	 life	 after	 the	founding	elections.}
#' \item{per3052}{Communist: Positive. Co-operation with	 former	 authorities/communists	 in	 the	
#' transition	 period; pro-communist	 involvement	 in	 the	transition	process;	and	'let	sleeping	dogs	lie' 
#' in	dealing	with	the	nomenclature.}
#' \item{per3053}{Communist: Negative. Against communist	involvement	in	democratic	government;	weeding	out the collaborators	 
#' from	 governmental	 service;	need	for	political	coalition	except	communist	parties.}
#' \item{per3054}{Rehabilitation and	Compensation:	Positive. References to	 civic	 rehabilitation	 of	 politically	 persecuted	
#' people	 in	 the	 communist era;	 references	 to	 juridical	compensation	concerning	communist	expropriations;	moral	compensation.}
#' \item{per3055}{Political Coalitions:	Positive. Positive references	to	the	need	of	broader	political	coalition; 
#' need for co-operation	 at	 the	 political	 level;	 necessity of	collaboration	among	all	political	forces.}
#' \item{per4011}{Privatisation: Positive. Favourable references	to	privatisation.}
#' \item{per4012}{Control of	Economy:	Negative. Negative references	 to	 the	 general	 need	 for	 direct	
#' governmental	control	of	the	economy.}
#' \item{per4013}{Property-Restitution: Positive. Favourable references	to	the	physical	restitution	of	property	
#' to	previous	owners.}
#' \item{per4014}{Privatisation Vouchers:	Positive. Favourable references	to	privatisation	vouchers. }
#' \item{per4121}{Social Ownership:	Positive. Favourable references	to	the	creation	or	preservation	of	
#' cooperative or	 non-state	 social	 ownership	 within	 a	 market	economy.}
#' \item{per4122}{Mixed Economy:	Positive. Favourable references	 to	mixed	ownership	within	a	market	economy.}
#' \item{per4123}{Publicly-Owned Industry:	Positive. Positive references	 to	 the	 concept	 of	 publicly-owned	industries.}
#' \item{per4124}{Socialist Property:	Positive. Positive references	to	socialist	property,	including	public	and	
#' co-operative	property;	negative	references	to	privatisation.}
#' \item{per4131}{Property-Restitution: Negative. Negative references	 to	 the	 physical	 restitution	 of	 property	to	previous	owners.}
#' \item{per4132}{Privatisation: Negative. Negative references	 to	 the	 privatisation	 system;	 need	 to	
#' change	the	privatisation	system.}
#' \item{per5021}{Private-Public Mix in	Culture:	Positive. Necessity of	private	provisions	due	to	economic	constraints;	
#' private	funding	in	addition	to	public	activity.}
#' \item{per5031}{Private-Public Mix	in	Social Justice:	Positive. Necessity of	private	initiatives	due	to	economic	constraints.}
#' \item{per5041}{Private-Public Mix	in	Welfare:	Positive. Necessity of	 private	 welfare	 provisions	 due to	 economic	
#' constraints;	 desirability	 of	 competition in	 welfare	 service	provisions;	private	funding	in	addition	to	public	activity.}
#' \item{per5061}{Private-Public Mix	in	Education:	Positive. Necessity of	private	education	due	to	economic	constraints;	
#' desirability	of	competition	in	education.}
#' \item{per6011}{The Karabakh	Issue:	Positive. Positive references	to	the	unity	of	Karabakh	and	Armenia	or	
#' the recognition	of	 the independent	Republic	 of	 Karabakh;	rendering	assistance	to	Karabakh.}
#' \item{per6012}{Rebuilding the	USSR:	Positive. Favourable mentions	of	the	reunification	of	all	republics	
#' and	nations	living	on	the	former	territory	of	the	USSR	into	a	new	common	 (democratic)	 state	 or	 into	 a	
#' common	 economic	space	whereby	the	new	union	would	be	the	guarantor	of	the	manifesto	country's	sovereignty;	negative 
#' references	to	the	dissolution	of	the	USSR	and	the	respective	treaties.}
#' \item{per6014}{Cyprus  Issue. All   references	concerning	 the	 division	 of	 Cyprus	 in	 a	Greek	and	a	Turkish	part.}
#' \item{per6061}{General  Crisis. Identification  of	a	general	crisis	in	the	country.}
#' \item{per6071}{Cultural  Autonomy:	Positive. Favourable  mentions	of	cultural	autonomy.}
#' \item{per6072}{Multiculturalism  pro	Roma:	Positive. avourable  mentions	of	cultural	autonomy	of	Roma. }
#' \item{per6081}{Multiculturalism  pro	Roma:	Negative. Negative  mentions	of	cultural	autonomy	of	Roma.}
#' \item{per7051}{Minorities  Inland:	Positive. References   to	 manifesto	 country	 minorities	 in	 foreign	
#' countries;	 positive	 references	 to	 manifesto	 country	minorities.}
#' \item{per7052}{Minorities  Abroad:	Positive. References   to	 ethnic	 minorities	 living	 in	 the	 manifesto	
#' country	such	as	Latvians	living	in	Estonia.}
#' \item{per7061}{War  Participants:	Positive. Favourable   mentions	 of,	 or	 need	 for,	 assistance	 to	 people	
#' who	 left	 their	 homes	 because	 of	 the	 war	 (for	 instance,	on the	territory	of	ex-Yugoslavia)	or	were 
#' forcibly	displaced.}
#' \item{per7062}{Refugees: Positive.Favourable   mentions	 of,	or	 need	 for,	 assistance	 to	 people	
#' who	 left	 their	 homes	 because	 of	 the	 war	 (for	 instance, on	the	territory	of	ex-Yugoslavia) or	
#' were	forcibly	displaced.}
#' \item{peruncod}{Percentage  of	uncoded	(quasi-) sentences. Missing  information: Sweden  1948-1982	=	99,99; 
#' Norway  1945-1989	=	99,99. }
#' \item{total}{Total  number	of	quasi-sentences. Missing  information: Norway  in 1989	=	9999.}
#' \item{rile}{Right-left   position of	 party as	 given	in Michael	Laver/Ian. Budge (eds.).
#' -100 (Left) +100 (Right)	 
#' 
#' Party	 Policy	 and	 Government	 Coalitions,	Houndmills,	Basingstoke,	Hampshire:	The	MacMillan	Press	1992:
#' (per104 +	per201 + per203 + per305 + per401 + per402 +	per407+	per414 + per505 + per601 +	per603 + per605	 +
#' per606) - (per103 +	 per105	+	per106	+	per107 +	per403 + per404	+	per406 +	per412 +	per413 + per504 + per506 +
#' per701	+	per202).}
#' \item{planeco}{per403  +	per404	+	per412.}
#' \item{markeco}{per401  +	per414.}
#' \item{welfare}{per503  +	per504.}
#' \item{intpeace}{per102  +	per105	+	per106. }
#' 
#'  } 
#' @name ManifestoFull 
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Budge et. al (2001). "Mapping Policy Preferences. Estimates for Parties, Electors, and Governments 1945-1998", 
#' Oxford: Oxford University Press. Klingemann et. al (2006). "Mapping Policy Preferences II. 
#' Estimates for Parties, Electors, and Governments in Eastern Europe, the European Union and the OECD, 1990-2003", 
#' Oxford: Oxford University Press.
#' Volkens et. al (2012). "The Manifesto Data Collection. Manifesto Project (MRG/CMP/MARPOR)",  
#' Berlin: Wissenschaftszentrum Berlin für Sozialforschung (WZB).
#' @keywords dataset party election position
#' @source Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @seealso \link{ManifestoVoter},\link{ManifestoGovDec},
#' \link{ManifestoElectionLevel}, \link{ManifestoGovNotes}
#' @examples
#' data(ManifestoFull)
#' 
#' #This example converts the numeric edate-variable into a 
#' #Date-variable in the following format: dd-mm-yyyy. 
#' ManifestoFull$edate <- as.Date(ManifestoFull$edate, origin = "1960-01-01") 
#' ManifestoFull$edate<- format(ManifestoFull$edate,"%d-%m-%Y")
#' 
#' data(ManifestoFull)
#' 
#' 
#' #Get the latest entry of for the parties
#' ManifestoFull <- ManifestoFull[order(ManifestoFull$party, -ManifestoFull$edate),]
#' PartyChange <- ManifestoFull[!duplicated(ManifestoFull$party),]
#' 
#' #Plot party positions
#' PartyChange$yvalue <- 0.5
#' par(mfrow=c(length(levels(factor(PartyChange$countryname))),1))
#' par(mar=c(0,4.1,0,2.8))
#' par(oma=c(2,0.5,2,0.5))
#' for(i in 1:length(levels(factor(PartyChange$countryname)))){
#'   plot(PartyChange$rile[which(PartyChange$countryname==
#'                                 levels(factor(PartyChange$countryname))[i])],
#'        PartyChange$yvalue[which(PartyChange$countryname==
#'                                   levels(factor(PartyChange$countryname))[i])],
#'        ylim=c(0,1), xlim=c(min(PartyChange$rile,na.rm=TRUE),max(PartyChange$rile,na.rm=TRUE)),
#'        ylab="",yaxt="n",xaxt="n",xlab="",type="p",pch=3)
#'   abline(v=c(-40,0,40),lty="dashed")
#'   mtext(as.character(levels(factor(PartyChange$countryname))[i]),side=2,
#'         las=1,cex=0.5,line=0.50)
#' }
#' axis(3,at=c(min(PartyChange$rile,na.rm=TRUE),-40,0,40,max(PartyChange$rile,na.rm=TRUE)),
#'      labels=c("Left","-40","0","40","Right"),outer=TRUE)
#' mtext("Party left - right position",side=1,font=2,line=0.5,outer=TRUE)
#' 
#' 
#' data(ManifestoFull)
#' 
#' #This example shows the norwegian party system and their demand for
#' #Keynesian demand policies
#' ManifestoFull$edate <- as.Date(ManifestoFull$edate, origin = "1960-01-01")
#' ManifestoFull$edate<- format(ManifestoFull$edate,"%d-%m-%Y")
#' ManifestoFull$edate <- sapply(strsplit(ManifestoFull$edate, "-"), "[[", 3)
#' 
#' 
#' Norway <- ManifestoFull[which(ManifestoFull$country==12),]
#' Keynes <- aggregate(Norway$per409,by=list(Norway$edate),"mean")
#' Keynes2 <- aggregate(Norway$per409,by=list(Norway$edate,Norway$party),"mean")
#' Partyname <- Norway[!duplicated(Norway$party),c("party","partyname")]
#' Keynes2 <- merge(Keynes2,Partyname,by.x="Group.2",by.y="party",all=TRUE)
#' 
#' DNA <- Keynes2[which(Keynes2$partyname=="DNA Labour Party"),]
#' H <- Keynes2[which(Keynes2$partyname=="H Conservative Party"),]
#' FRP <- Keynes2[which(Keynes2$partyname=="Anders Lange's Party"),]
#' SV <- Keynes2[which(Keynes2$partyname=="Socialist People's Party"),]
#' SP <- Keynes2[which(Keynes2$partyname=="Farmers' Party"),]
#' KRF <- Keynes2[which(Keynes2$partyname=="KrF Christian People's Party"),]
#' V <- Keynes2[which(Keynes2$partyname=="V Liberal Party"),]
#' 
#' plot(Norway$edate,Norway$per409, type="n",main="Average use of keynesian theory
#'      in norwegian party platforms",
#'      xlab="Year",ylab="Sentences on Keynesian demand politics")
#' lines(Keynes$Group.1,Keynes$x, type="l",lty="dashed",lwd=1)
#' lines(SV$Group.1,SV$x,col="darkred",lwd=2)
#' lines(DNA$Group.1,DNA$x,col="red",lwd=1)
#' lines(SP$Group.1,SP$x,col="darkgreen",lwd=2)
#' lines(V$Group.1,V$x,col="green",lwd=1)
#' lines(KRF$Group.1,KRF$x,col="yellow",lwd=1)
#' lines(H$Group.1,H$x,col="blue",lwd=1)
#' lines(FRP$Group.1,FRP$x,col="darkblue",lwd=2)
#' legend("topright",col=c("black","darkred","red","darkgreen",
#'                         "green","yellow","blue","darkblue"),lwd=c(1,2,1,2,1,1,1,2),
#'        legend=c("Average","Socialists","Labout","Agrarian","Liberal",
#'                 "Christian Democratic","Conservative","Radical right"),
#'        lty=c("dashed","solid","solid","solid","solid","solid",
#'              "solid","solid","solid"),bty="n",cex=1)
NULL