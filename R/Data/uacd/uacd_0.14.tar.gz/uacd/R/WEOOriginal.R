#' WEOOriginal - World Economic Outlook
#' 
#' @description The original downloaded table from World Economic Outlook, International Monetary Fund
#' @format A dataframe with 8649 rows and 49 variables.
#' It includes 188 countries between 1980 - 2018 (some cells have estimated values and are not observed).
#' \describe{
#' 
#' \item{WEO.Country.Code}{Country code from World Economic Outlook}
#' \item{Country}{Country name}
#' \item{ISO}{Country abbrevation in ISO encoding}
#' \item{WEO.Subject.Code}{World Economic Outlook code for the measure.}
#' \item{Subject.Descriptor}{Describes what is being measured.}
#' \item{Subject.Notes}{A more elaborated description of the measure}
#' \item{Units}{Units of measurement. For NA values, the units are intuitive based on Subject.Descriptor or Subject.Notes}
#' \item{Scale}{Scale of measurement, unless this is intuitive based on Subject.Descriptor or Subject.Notes}
#' \item{Country.Series.specific.Notes}{Notes specificly for that country. Usually a list of sources.}
#' \item{X1980}{1980}
#' \item{X1981}{1981}
#' \item{X1982}{1982}
#' \item{X1983}{1983}
#' \item{X1984}{1984}
#' \item{X1985}{1985}
#' \item{X1986}{1986}
#' \item{X1987}{1987}
#' \item{X1988}{1988}
#' \item{X1989}{1989}
#' \item{X1990}{1990}
#' \item{X1991}{1991}
#' \item{X1992}{1992}
#' \item{X1993}{1993}
#' \item{X1994}{1994}
#' \item{X1994}{1995}
#' \item{X1994}{1996}
#' \item{X1994}{1997}
#' \item{X1994}{1998}
#' \item{X1994}{1999}
#' \item{X2000}{2000}
#' \item{X2001}{2001}
#' \item{X2002}{2002}
#' \item{X2003}{2003}
#' \item{X2004}{2004}
#' \item{X2005}{2005}
#' \item{X2006}{2006}
#' \item{X2007}{2007}
#' \item{X2008}{2008}
#' \item{X2009}{2009}
#' \item{X2010}{2010}
#' \item{X2011}{2011}
#' \item{X2012}{2012}
#' \item{X2013}{2013}
#' \item{X2014}{2014}
#' \item{X2015}{2015}
#' \item{X2016}{2016}
#' \item{X2017}{2017}
#' \item{X2018}{2018}
#' \item{Estimates.Start.After}{After the year denoted here, the values for this variable in this country are estimates.}
#' 
#'  } 
#' @name WEOOriginal
#' @details Data set verison April 16 2013.
#' 
#' This is the original WEO-file as it is downloaded from the internet. Parts of the measures are not observed, but estimated. The information for when the different indicators in the different countries starts being estimated is available in this table.
#' Due to the lack of flexibility with this data set format, the UACD team have reshaped it into a standard country-year format, available in the file \link{WEO}.
#' \link{WEOOriginal} is mainly a tool to investigate when the variables starts being estimated and not observed.
#' 
#' To find the information for the \link{WEO} variable that you are looking for, use the subject code noted in the documentation file for \link{WEO} to extract that variable from \link{WEOOriginal} (see example).
#' Notice that the countries vary for what year estimates starts for a given measure.
#' 
#' @references 
#' IMF homepage: \url{https://files.nyu.edu/mrg217/public/elections.html}
#' @keywords dataset
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @source Project homepage: \url{http://www.imf.org/external/pubs/ft/weo/2013/01/weodata/index.aspx}
#' @seealso WEO
#' @examples
#' data(WEOOriginal)
#' 
#' # How to extract information for the variable of interest. Example with constant GDP per capita:
#' GDPpc_constant <- WEOOriginal[which(WEOOriginal$WEO.Subject.Code=="NGDPRPC"),]
#' levels(factor(GDPpc_constant$Estimates.Start.After))
NULL