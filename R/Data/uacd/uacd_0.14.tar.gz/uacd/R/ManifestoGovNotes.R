#' ManifestoGovNotes - Comparative Manifesto Project - Government Notes
#' 
#' @description Comparative Manifesto Project - Government Notes
#' @format A dataframe with 888 rows and 13 variables.
#' Each row represents a government.
#' These 888 are from 47 countries in the period 1921 - 2005
#' \describe{
#' 
#' \item{nationid}{Country code}
#' \item{natname}{Country name}
#' \item{govtseq}{Not found in codebook. It counts the rows within each country.}
#' \item{govyear}{Year}
#' \item{govmonth}{Month}
#' \item{govday}{Day}
#' \item{elecdate}{Year-Month of election}
#' \item{rile}{Right(+100)-left(-100) position of party as given in Michael Laver/Ian Budge (eds.): Party Policy and Government Coalitions, Houndmills, Basingstoke, Hampshire: The MacMillan Press 1992: (per104 + per201 + per203 + per305 + per401 + per402 + per407 + per414 + per505 + per601 + per603 + per605 + per606) - (per103 + per105 + per106 + per107 + per403 + per404 + per406 + per412 + per413 + per504 + per506 + per701 + per202)}
#' \item{planeco}{Planned economy. Calculated as per403 + per404 + per412}
#' \item{markeco}{Market economy. Calculated as per401 + per414}
#' \item{welfare}{Welfare references. Calculated as per503 + per504}
#' \item{intpeace}{International peace. Calculated as per102 + per105 + per106}
#' \item{eu}{European integration. Calculated as per108 - per110}
#'  } 
#' @name ManifestoGovNotes
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references (2006) Budge, Ian, Hans-Dieter Klingemann, Andrea Volkens, Judith Bara, Michael McDonald. "Mapping Policy Preferences. Estimates for Parties, Electors, and Governments 1945-1998." Oxford: Oxford University Press
#' Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @keywords dataset positions cabinet
#' @source Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @details It is unclear how this data set from their second book is distinguished from ManifestoGocDec from their first book.
#' 
#' The per-variables are different topics and their space (measured as percentage) in the party platform. It follows Hee-Min Kim and Richard C. Fording's use of the policy estimates, which describe party positions, to allow inferences to be made about the voters' positions.
#' @seealso \link{ManifestoVoter},\link{ManifestoFull},
#' \link{ManifestoElectionLevel}, \link{ManifestoGovDec}
#' @examples
#' #This example illustrates governments' left-right position over time and compares
#' #ManifestoGovDec and ManifestoGovNotes.
#' library(ggplot2)
#' 
#' data(ManifestoGovDec)
#' ManifestoGovDec$rile <- ManifestoGovDec$PER104 +
#' ManifestoGovDec$PER201 + ManifestoGovDec$PER203 +
#'   ManifestoGovDec$PER305 + ManifestoGovDec$PER401 +
#'   ManifestoGovDec$PER402 + ManifestoGovDec$PER407 +
#'   ManifestoGovDec$PER414 + ManifestoGovDec$PER505 +
#'   ManifestoGovDec$PER601 + ManifestoGovDec$PER603 +
#'   ManifestoGovDec$PER605 + ManifestoGovDec$PER606 -
#'   ManifestoGovDec$PER103 + ManifestoGovDec$PER105 +
#'   ManifestoGovDec$PER106 + ManifestoGovDec$PER107 +
#'   ManifestoGovDec$PER403 + ManifestoGovDec$PER404 +
#'   ManifestoGovDec$PER406 + ManifestoGovDec$PER412 +
#'   ManifestoGovDec$PER413 + ManifestoGovDec$PER504 +
#'   ManifestoGovDec$PER506 + ManifestoGovDec$PER701 + ManifestoGovDec$PER202
#' ManifestoGovDec$year <- gsub("^.*-.*-","19",ManifestoGovDec$INAUGDAT)
#' ManifestoGovDec$year <- as.numeric(as.character(ManifestoGovDec$year))
#' 
#' GovDec <- ggplot(ManifestoGovDec, aes(year, rile, group = COUNTRY_NAME)) +
#'   geom_rect(aes(ymax=100,ymin=50,xmax=2000,xmin=1945),
#'             alpha=0.009,fill="blue",inherit.aes=FALSE) +
#'   geom_rect(aes(ymax=50,ymin=0,xmax=2000,xmin=1945),
#'             alpha=0.009,fill="red",inherit.aes=FALSE) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Right-Left dimension") +
#'   scale_x_continuous("Year") +
#'   ggtitle("ManifestoGovDec")
#' 
#' 
#' data(ManifestoGovNotes)
#' ManifestoGovPostWar <- ManifestoGovNotes[which(ManifestoGovNotes$govyear>=1945),]
#' 
#' GovNotes <- ggplot(ManifestoGovPostWar, aes(govyear, rile, group = natname)) +
#'   geom_rect(aes(ymax=50,ymin=0,xmax=2005,xmin=1945),
#'             alpha=0.009,fill="blue",inherit.aes=FALSE) +
#'   geom_rect(aes(ymax=-62,ymin=0,xmax=2005,xmin=1945),
#'             alpha=0.009,fill="red",inherit.aes=FALSE) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Right-Left dimension") +
#'   scale_x_continuous("Year") +
#'   ggtitle("ManifestoGovNotes")
#' 
#' multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
#'   require(grid)
#'   
#'   # Make a list from the ... arguments and plotlist
#'   plots <- c(list(...), plotlist)
#'   
#'   numPlots = length(plots)
#'   
#'   # If layout is NULL, then use 'cols' to determine layout
#'   if (is.null(layout)) {
#'     # Make the panel
#'     # ncol: Number of columns of plots
#'     # nrow: Number of rows needed, calculated from # of cols
#'     layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
#'                      ncol = cols, nrow = ceiling(numPlots/cols))
#'   }
#'   
#'   if (numPlots==1) {
#'     print(plots[[1]])
#'     
#'   } else {
#'     # Set up the page
#'     grid.newpage()
#'     pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
#'     
#'     # Make each plot, in the correct location
#'     for (i in 1:numPlots) {
#'       # Get the i,j matrix positions of the regions that contain this subplot
#'       matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
#'       
#'       print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
#'                                       layout.pos.col = matchidx$col))
#'     }
#'   }
#' }
#' 
#' multiplot(GovDec,GovNotes)
NULL