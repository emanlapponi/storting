#' GolderFiscalPolicyEU - Replication data for: Fiscal Policy and the Democratic Process in the European Union
#' 
#' @description Matt Golders replication data for Fiscal Policy and the Democratic Process in the European Union
#' @format An unbalanced dataframe with 420 rows and 35 variables.
#' 15 countries between 1970 - 1997.
#' \describe{
#' \item{country}{Number of country. The codebook does not state what kind of number this is. It is not equal to gwno or cow-codes. Be therefore cautious when merging this with other country codes.}
#' \item{year}{Year}
#' \item{name}{Country name}
#' \item{seats}{Number of seats in lower house}
#' \item{district}{Number of lower tier districts}
#' \item{logmag}{Log of median district magnitude}
#' \item{lnamag}{Log of average district magnitude}
#' \item{avemag}{Average district magnitude. Number of seats in lower house divided by number of districts in lower house.}
#' \item{medmag}{Median district magnitude}
#' \item{upseat}{Number of seats allocatd in an upper tier}
#' \item{upper}{Percentage of seats allocated in an upper tier}
#' \item{eu}{Dummy variable for european union countries. 1 for member countries}
#' \item{european}{Dummy variable for european countries. In the dataset, all countries equals 1.}
#' \item{ddebt}{Change in gross government debt over GDP}
#' \item{ddebt1}{Change in gross government debt over GDP, lagged one year}
#' \item{dbtserv2}{Change in real interest rate minus the change in the growth rate times the gross deficit in the previous year}
#' \item{growth}{Change in GDP}
#' \item{pol1}{Dummy variable for 2-3 party government}
#' \item{pol2}{Dummy variable for 4-5 party government}
#' \item{pol3}{Dummy variable for minority government}
#' \item{strongfm}{Dummy variable for strong finance minister}
#' \item{targets}{Dummy variable for negotiated targets}
#' \item{unemp}{Unemployment rate at the national level}
#' \item{debt}{Gross government debt}
#' \item{wkbpart}{Woldendorp, Keman, & Budge measure of partisanship}
#' \item{partbbd2}{Blais, Blake & Dion measure of partisanship}
#' \item{bbdstfm}{BBD partisanship measure * strong finance minister}
#' \item{bbdtarg}{BBD partisanship measure * targets}
#' \item{bbdrlmag}{BBD partisanship measure * logmag}
#' \item{bbdrtarg}{BBD partisanship measure * targets. bbdrtarg and bbdtarg are identical.}
#' \item{enep}{Effective number of elective parties}
#' \item{enpp}{Effective number of parliamentary parties}
#' \item{enep_lijphart}{Effective number of elective parties according to Lijphart 1994}
#' \item{enpp_lijphart}{effective number of parliamentary parties according to Lijphart 1994}
#' }
#' @name GolderFiscalPolicyEU
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references William Clark; Matt Golder; Sona Golder, 2007, "Replication data for: Fiscal Policy and the Democratic Process in the European Union", http://hdl.handle.net/1902.1/10482 UNF:3:Bzp8zn4sG9N+PQV1DkX/cg== Matt Golder [Distributor] V1 [Version]
#' @keywords dataset election parliament economy EU
#' @source Matt Golder's dataverse homepage: \url{http://dvn.iq.harvard.edu/dvn/dv/mgolder}
#' @seealso desaw, GolderExtremeRight
#' @examples
#' #This example will replicate Model 1 B in table 1 in the article
#' 
#' data(GolderFiscalPolicyEU)
#' Eup <- GolderFiscalPolicyEU[which(GolderFiscalPolicyEU$year>1980 &
#' 
#' GolderFiscalPolicyEU$year<1993),] 
#' model <- lm(ddebt ~ partbbd2 + logmag + factor(strongfm) +
#' factor(targets) + bbdrlmag
#' + bbdrstfm + bbdrtarg + ddebt1 + unemp + growth + dbtserv2 +
#' factor(pol1) + factor(pol2) + factor(pol3), data=Eup)
#' summary(model)
NULL