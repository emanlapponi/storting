#' ManifestoVoter - Comparative Manifesto Project - Median Voter
#' 
#' @description Comparative Manifesto Project - Median Voter
#' @format An unbalanced dataframe with 482 rows and 11 variables.
#' It includes voter positions in 51 countries in the period 1945 - 2004.
#' \describe{
#' 
#' \item{country}{Country code}
#' \item{country_}{Country name}
#' \item{elecyr}{Election year}
#' \item{date}{This is a four digit code: First two digits is the year, second two digits is the month.}
#' \item{edate}{Day-Month-Year of election.}
#' \item{peacemed}{Voter position on peace. Calculated as per102 + per105 + per106 (see details)}
#' \item{welfmed}{Voter position on welfare. Calculated as per503 +  per504 (see details)}
#' \item{markmed}{Voter position on market economy. Calculated as per401 +  per414 (see details)}
#' \item{planmed}{Voter position on planned economy. Calculated as per403 + per404 + per412 (see details)}
#' \item{eumed}{Voter position on European Integration. Calculated as per108 - per 110 (see details)}
#' \item{riteleft}{Voter position on Left-Right spectrum. Coded as left(-100) <---> right(+100).}
#' 
#'  } 
#' @name ManifestoVoter
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references (2006) Budge, Ian, Hans-Dieter Klingemann, Andrea Volkens, Judith Bara, Michael McDonald. "Mapping Policy Preferences. Estimates for Parties, Electors, and Governments 1945-1998." Oxford: Oxford University Press
#' Project homepage: \url{https://manifestoproject.wzb.eu/}
#' 
#' Kim and Fording in Budge et al. Mapping Policy Preferences II: Estimates for Parties, Electors and Governments in Eastern Europe, European Union and OECD 1990 - 2003 (Oxford: Oxford University Press, 2001). 
#' @keywords dataset position election
#' @source Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @details The per-variables are different topics and their space (measured as percentage) in the party platform. It follows Hee-Min Kim and Richard C. Fording's use of the policy estimates, which describe party positions, to allow inferences to be made about the voters' positions.
#' 
#' 
#' Right(+100)-left(-100) (rile) is calculated as (per104 + per201 + per203 + per305 +
#' per401 + per402 + per407 + per414 + per505 + per601 + per603 + per605 + per606) -
#' (per103 + per105 + per106 + per107 + per403 + per404 + per406 + per412 + per413 +
#' per504 + per506 + per701 + per202).
#' @seealso \link{ManifestoGovDec}, \link{ManifestoElectionLevel},
#' \link{ManifestoGovNotes}, \link{ManifestoFull}
#' @examples
#' # This example plots the left-right position in all countries.
#' library(uacd)
#' data(ManifestoVoter)
#' 
#' trim <- function (x) gsub("^\\s+|\\s+$", "", x)
#' 
#' ManifestoVoter$country_ <- trim(ManifestoVoter$country_)
#' 
#' ManifestoVoter$fulltime <- NA
#' for(i in 1:nrow(ManifestoVoter)){
#'   ManifestoVoter$fulltime[i] <- ifelse(ManifestoVoter$elecyr[i] <= 1950,1,0)
#' }
#' ManifestoVoter <- ManifestoVoter[order(ManifestoVoter$country_,ManifestoVoter$elecyr),]
#' for(i in 2:nrow(ManifestoVoter)){
#'   ManifestoVoter$fulltime[i] <- ifelse(ManifestoVoter$country_[i]==ManifestoVoter$country_[i-1],
#'                                        ManifestoVoter$fulltime[i-1],ManifestoVoter$fulltime[i])
#' }
#' 
#' Full <- ManifestoVoter[which(ManifestoVoter$fulltime==1),]
#' 
#' 
#' #Plot all countries
#' par(mfrow=c(length(levels(factor(Full$country_))),1))
#' par(mar=c(0.2,4.1,0.2,2.8))
#' par(oma=c(1,0.5,2,0.5))
#' for(i in 1:length(levels(factor(Full$country_)))){
#'   plot(Full$elecyr[which(Full$country_==
#'                            levels(factor(Full$country_))[i])],
#'        Full$rite[which(Full$country_==
#'                          levels(factor(Full$country_))[i])],type="l",cex=0.5,
#'        ylim=c(min(Full$rite,na.rm=TRUE),max(Full$rite,na.rm=TRUE)),
#'        xlim=c(1945,2004),
#'        ylab="",las=1,yaxt="n",xaxt="n",xlab="",lwd=2)
#'   mtext(as.character(levels(factor(Full$country_))[i]),side=2,
#'         las=1,cex=0.5,line=0.50)
#'   axis(4,at=c(min(Full$rite,na.rm=TRUE),max(Full$rite,na.rm=TRUE)),
#'       labels=c("Left","Right"),cex.axis=0.8,las=1)
#'   abline(h=0,lty="dashed",col="red")
#' }
#' mtext("Voter position",font=2,outer=TRUE)
#' 
#' 
#' #This plot lets you highlight one country and compare it to the others.
#' #Simply switch "Sweden" with whatever country you wish to highlight.
#' ManifestoVoter$colorcountryofinterest <- NA
#' for(i in 1:nrow(ManifestoVoter)){
#'   ManifestoVoter$colorcountryofinterest[i] <- ifelse(ManifestoVoter$country_[i]=="Sweden",
#'                                                      "purple","black")
#' }
#' ManifestoVoter$sizecountryofinterest <- NA
#' for(i in 1:nrow(ManifestoVoter)){
#'   ManifestoVoter$sizecountryofinterest[i] <- ifelse(ManifestoVoter$country_[i]=="Sweden",3,1)
#' }
#' 
#' par(mfrow=c(1,1))
#' par(mar=c(5.1,4.1,4.1,2.1))
#' par(oma=c(0,0,0,0))
#' plot(0,0,xlim=c(min(ManifestoVoter$rite,na.rm=TRUE),max(ManifestoVoter$rite,na.rm=TRUE)),
#'      ylim=c(1945,2004),ylab="Election year",xlab="Left --- Right",
#'      main="Average voter position",type="n",bty="n")
#' rect(xleft=min(ManifestoVoter$rite,na.rm=TRUE), ybottom=1945,
#'      xright=0,ytop=2004,col="red",density=20)
#' rect(xleft=0, ybottom=1945, xright=max(ManifestoVoter$rite,na.rm=TRUE),ytop=2004,
#'      col="blue",density=20)
#' for(i in 1:length(levels(factor(ManifestoVoter$country_)))){
#'   lines(ManifestoVoter$rite[which(ManifestoVoter$country_==
#'                                     levels(factor(ManifestoVoter$country_))[i])],
#'         ManifestoVoter$elecyr[which(ManifestoVoter$country_==
#'                                       levels(factor(ManifestoVoter$country_))[i])],type="l",
#'         col=ManifestoVoter$colorcountryofinterest[
#'         which(ManifestoVoter$country_==levels(factor(ManifestoVoter$country_))[i])],
#'         lwd=ManifestoVoter$sizecountryofinterest[
#'         which(ManifestoVoter$country_==levels(factor(ManifestoVoter$country_))[i])])
#' }
#' abline(v=0,lty="dashed",lwd=3)
NULL