#' Party - ParlGov's parties-data
#' 
#' @description This dataset has information on Parties from 38 countries.
#' This dataset is a copy of view_party.csv from ParlGov.
#' @format A cross-section dataframe with 1350 rows and 23 variables.
#' Each row belong to a unique party.
#' \describe{
#' 
#' \item{Country_name_short}{Country name abbrevation}
#' \item{country_name}{Country name}
#' \item{party_name_short}{Party name abbrevation}
#' \item{party_name_english}{Party name in english}
#' \item{party_name}{Party name (Could have some encoding errors for certain symbols)}
#' \item{party_name_ascii}{Party name without special characters}
#' \item{family_name_short}{Party family abbrevation}
#' \item{family_name}{Party family}
#' \item{left_right}{Party mean value on left-right dimension, data form Castles/Mair 1983, Huber/Inglehart 1995, Benoit/Laver 2006 and CHESS 2010}
#' \item{state_market}{Party mean value in 'regulation of economy', data from Benoit/Laver 2006 and CHESS 2010}
#' \item{liberty_authority}{Party mean value in  'libertarian/authoritarian', data from Benoit/Laver 2006 and CHESS 2010}
#' \item{eu_anti_pro}{Party mean value in 'EU integration', data from Ray 1999, Benoit/Laver 2006 and CHESS 2010}
#' \item{cmp}{Comparative Manifestos Project (CMP) party ID}
#' \item{euprofiler}{EU Profiler (Trechsel/Mair 2009) party ID}
#' \item{ees}{European Election Study (2009) party ID}
#' \item{castles_mair}{Castles/Mair (1983) expert survey party ID}
#' \item{huber_inglehart}{Huber/Inglehart (1995) expert survey party ID}
#' \item{ray}{Ray (1999) expert survey party ID}
#' \item{benoit_laver}{Benoit/Laver (2006) expert survey party ID}
#' \item{chess}{Chapel Hill expert survey series (CHESS) party ID (Hooghe ea. 2010; Marks/Steenbergen 2007)}
#' \item{country_id}{Country id code}
#' \item{party_id}{Party id code}
#' \item{family_id}{ParlGov party family id code}
#'  } 
#' @name Party
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' @source view_party online: \url{http://www.parlgov.org/stable/documentation/table/view_party.html}
#' @keywords dataset party position
#' @examples
#' data(HuberInglehart)
#' data(CastlesMair)
#' data(Party)
#' 
#' ####Give colname .CM and .HI endings, so where they come from can be identified
#' names(CastlesMair) <- sub("$",".CM",names(CastlesMair))
#' names(HuberInglehart) <- sub("$",".HI",names(HuberInglehart))
#' 
#' #Merge
#' HICM <- merge(Party,CastlesMair,
#'               by.x='castles_mair', by.y='id.CM', all=TRUE)
#' HICM <- merge(HICM,HuberInglehart,
#'               by.x='huber_inglehart', by.y='id.HI', all=TRUE)
#' 
#' #Get an idea of correlation between left_right in the
#' #different datasets.
#' library(corrgram)
#' corrgram(HICM[,c("left_right.CM","left_right.HI")],
#'          upper.panel=panel.pie,lower.panel=panel.pts)
#' 
#' #Center variables, so they can be used in OLS.
#' HICM$lr.HI <- scale(HICM$left_right.HI, center=TRUE, scale=FALSE)
#' HICM$lr.CM <- scale(HICM$left_right.CM, center=TRUE, scale=FALSE)
NULL
