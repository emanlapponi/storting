#' CheibubInvestiture - Investiture data from Cheibub et al.
#' @description ParlGov and Investiture data from Cheibub et al.
#' @format An unbalanced data frame with 21115 rows and 77 variables.
#' It includes 35 countries. Most countries are covered for the period 1945 - october 2012.
#' Australia, Switzerland and Finland have data before 1940s.
#' It includes 1177 parties, 948 cabinets and 675 elections.
#' \describe{
#' \item{country}{Country name}
#' \item{year}{Year}
#' \item{country_id}{ParlGov country_id-code}
#' \item{party_id}{Party id code}
#' \item{election_id}{Election id code}
#' \item{party_name_english}{Name of party in english}
#' \item{election_date}{Election date}
#' \item{country_name_short}{Country name abbreviation. ISO3 format.}
#' \item{start_date}{Cabinet inauguration date}
#' \item{cabinet_name}{Cabinet name (Could have some encoding errors for certain symbols)}
#' \item{caretaker}{Caretaker government, 1=Yes}
#' \item{cabinet_party}{Party in cabinet, 1=Yes}
#' \item{prime_minister}{Prime ministers party, 1=Yes}
#' \item{seats}{Partys number of seats in parliament}
#' \item{election_seats_total}{Total number of seats in parliament}
#' \item{party_name_short}{Party name abbreviation}
#' \item{party_name}{Party name (Could have some encoding errors for certain symbols)}
#' \item{cabinet_id}{Cabinet id code}
#' \item{left_right.y}{Party placement on left-right dimension, data form Castles/Mair 1983, Huber/Inglehart 1995, Benoit/Laver 2006 and CHESS 2010}
#' \item{previous_cabinet_id}{Previous cabinet id code}
#' \item{end_date}{Date when next cabinet is inaugerated, and thus when the existing cabinet steps down. This is coded by copying the {\emph{start_date}} of the following.}
#' \item{party_name_ascii}{Party name without special characters}
#' \item{family_name}{Party family}
#' \item{country_name.y}{Name of country}
#' \item{state_market}{Party mean value in regulation of economy, data from Benoit/Laver 2006 and CHESS 2010}
#' \item{liberty_authority}{Party mean value in  libertarian/authoritarian, data from Benoit/Laver 2006 and CHESS 2010}
#' \item{eu_anti_pro}{Party mean value in EU integration, data from Ray 1999, Benoit/Laver 2006 and CHESS 2010}
#' \item{election_type}{Type of election, national parliament (parliament) or european parliament (ep)}
#' \item{early}{Early election before constitutionally mandated term end. Coding of variable incomplete. Do not use it for empirical analysis}
#' \item{electorate}{Number citizens eligible to vote}
#' \item{votes_cast}{Number of votes cast in an election, including invalid and blank votes}
#' \item{votes_valid}{Number of votes cast in an election, not including invalid and blank votes}
#' \item{duration}{The difference between {\emph{start_date}} and {\emph{end_date}} in weeks.}
#' \item{Start_year}{This is the year extracted from the {\emph{start_date}}-variable}
#' \item{End_year}{This is the year extracted from the {\emph{end_date}}-variable}
#' \item{Election_year}{This is the year extracted from the {\emph{election_date}}-variable}
#' \item{CabinetYears}{This is ({\emph{End_year}} - {\emph{Start_year}})+1}
#' \item{vote_share}{Partys share of votes in the given election.}
#' \item{cabinet_seats}{Total number of seats in parliament held by cabinet parties.}
#' \item{minority_seats}{This is a dummy variable indicating if it is a minority cabinet or not, based on the cabinets share of seats in the parliament. This variable is coded 1 if {\emph{cabinet_seats}} / {\emph{election_seats_total}} < 0.5.}
#' \item{cabinet_votes}{This is the share of votes for cabinet parties. It is the sum of {\emph{vote_share}} for parties with value 1 on {\emph{cabinet_party}}}.
#' \item{minority_votes}{This is a dummy variable indicating if a cabinet got less than 50 percent of the votes. It coded so that entries with a value less than 50 on {\emph{cabinet_votes}} get 1.}
#' \item{cumulative_election_cabinets}{This variable counts the number of cabinets within an election period. It is coded so that if the {\emph{cabinet_id}} changes while {\emph{election_id}} stays the same, it adds 1 to this variable.}
#' \item{total_election_cabinets}{This variable is the total number of cabinets that sat during the given election period. It is coded by copying the given elections max value on the {\emph{cumulative_election_cabinets}} to all other rows for that election.}
#' \item{total_cabinet_parties}{This variable is the total number of parties in the given cabinet. It is coded by counting the number of rows with value 1 on {\emph{cabinet_party}} for the given cabinet.}
#' \item{coalition_cabinets}{This is a dummy variable indicating coalition cabinets. It is coded 1 if {\emph{total_cabinet_parties}} is >= 2.}
#' \item{NewCab}{This variable is coded 1 each time there is a new cabinet or a new year.
#' The intention with this variable is to easily move from a [country, year, cabinet, party]-format to a
#' [country, year, cabinet]-format. The latter format is achieved by eliminating all rows with value 0 on {\emph{NewCab}}.}
#' \item{Start_year_date}{This is simply the 31st of December in the cabinets start year.
#' The intention with this variable is to be able to create the {\emph{Duration_startyear}} which indicates how long a
#' cabinet sat in its first year in office.}
#' \item{End_year_date}{This is simply the 1st of January in the cabinets end year.
#' The intention with this variable is to be able to create the {\emph{Duration_endyear}} which indicates how long
#' a cabinet sat in its last year in office.}
#' \item{Duration_startyear}{This is the number of weeks between {\emph{Start_year_date}} and {\emph{start_date}}.
#' It indicates how long a cabinet sat in its first year in office.}
#' \item{Duration_endyear}{This is the number of weeks between {\emph{End_year_date}} and {\emph{end_date}}.
#' It indicates how long a cabinet sat in its last year in office.}
#' \item{cabinets_this_year}{This variable is the total number of cabinets that sat in a given year.
#' F.eks. if the cabinet changes twice in the given year,
#' this variable = 3: 1 for the first cabinet, two after the first change,
#' then 3 for the cabinet after the second change.}
#' \item{cabinet_changes_this_year}{This variable is {\emph{cabinets_this_year}} -1.}
#' \item{censored_cab}{This dummy is created to identify cabinets that were in power are the data set version date
#' "2012-10-15". These cabinets have been given "2012-10-15" as {\emph{end_date}}, but can be identified by the fact that they
#' have value 1 on {\emph{censored_cab}}.}
#' \item{december_dummy}{This variable is 1 if the cabinet {\emph{start_date}} is earlier than and {\emph{end_date}} is later than or equal to
#' 31st December in the given year. See also {\emph{DecemberandCensored}}}
#' \item{july_dummy}{This variable is 1 if the cabinet {\emph{start_date}} is earlier than or equal to and {\emph{end_date}} is later than
#' 1st July in the given year.}
#' \item{january_dummy}{This variable is 1 if the cabinet {\emph{start_date}} is earlier than or equal to and {\emph{end_date}} is later than
#' 1st January in the given year.}
#' \item{DecemberandCensored}{This dummy is the row sum of {\emph{december_dummy}} and {\emph{censored_cab}}.
#' Since the data set version is october 2012, then all observations from 2012 will be deleted if the data are
#' subsetted based on {\emph{december_dummy}} only. No cabinets have existed 31. December 2012 in the data set,
#' since the data set version is 2012-10-15. Instead, subset by removing all rows with value 0 on {\emph{DecemberandCensored}} }
#' \item{flagc}{No information yet}
#' \item{ee}{No information yet}
#' \item{hognomin}{No information yet}
#' \item{hogappoint}{No information yet}
#' \item{invest}{No information yet}
#' \item{invest_source}{No information yet}
#' \item{investround}{No information yet}
#' \item{timing}{No information yet}
#' \item{exante_rule_1st}{No information yet}
#' \item{exante_1st_fails}{No information yet}
#' \item{exante_rule_last}{No information yet}
#' \item{exante_last_fails}{No information yet}
#' \item{expost_rule_1st}{No information yet}
#' \item{expost_1st_fails}{No information yet}
#' \item{expost_rule_last}{No information yet}
#' \item{expost_last_fails}{No information yet}
#' \item{investmidterm}{No information yet}
#' \item{dissolution}{No information yet}
#' \item{X}{No information yet}
#' 
#' }
#' @details There are still a lot of missing information, since the invstiture-data is work-in-progress. 
#' @name CheibubInvestiture
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Cheibub, Jose Antonio, Bjørn Erik Rasch and Shane Martin (2013) "The Investiture Vote and the Formation and Survival of Minority Parliamentary Governments", EPSA Conference paper. 
#' 
#' Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' @keywords dataset election cabinet party position investiture parliament
#' @source ParlGov online: \url{http://www.parlgov.org/stable/documentation/table.1.html}
#' @seealso ParlGov, Cabinet, Election, ElectionandVoting, Party
#' @examples
#' # A (so far) trivial survival analysis on cabinet durations.
#' data(CheibubInvestiture)
#' 
#' library(survival);library(eha)
#' CabinetJuly <- CheibubInvestiture[which(CheibubInvestiture$NewCab==
#' 1 & CheibubInvestiture$july_dummy==1),]
#' CabinetJuly$duration <- as.numeric(as.character(CabinetJuly$duration))
#' CabinetJuly$total_cabinet_parties <- as.numeric(
#' as.character(CabinetJuly$total_cabinet_parties))
#' 
#' Duration <- coxph(Surv(duration) ~ cluster(country) + cluster(cabinet_id)
#'                   + factor(minority_seats) + total_cabinet_parties
#'                   + factor(caretaker), data=CabinetJuly)
#' cox.zph(Duration)
#' summary(Duration) 
NULL