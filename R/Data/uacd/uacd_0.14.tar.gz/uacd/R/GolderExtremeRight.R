#' GolderExtremeRight - Replication data for: Explaining variation in the electoral success of extreme right parties in Western Europe
#' 
#' @description Matt Golders replication data for Explaining variation in the electoral success of extreme right parties in Western Europe
#' @format Am unbalanced dataframe with 165 rows and 14 variables.
#' It covers 19 countries in the period 1970 - 2000.
#' \describe{
#' \item{country}{Country name}
#' \item{year}{Election year}
#' \item{populist}{Percentage of vote won by populist parties}
#' \item{neofascist}{Percentage of vote won by neofescist parties}
#' \item{extreme}{Percentage of vote won by neofascist and populist parties}
#' \item{immigration}{Percentage of the population comprised of foreign citizens}
#' \item{unemployment}{Percentage of total labor force that is unemployed at the national level}
#' \item{seats}{Number of seats in lower house}
#' \item{districts}{Number of lower tier districts}
#' \item{averagemagnitude}{Average district magnitude. Number of seats in lower house divided by number of districts in lower house.}
#' \item{magnitude}{Unkown. Not in codebook}
#' \item{upperseats}{Number of seats allocatd in an upper tier}
#' \item{uppertier}{Percentage of seats allocated in an upper tier}
#' \item{UnempImmig}{unemployment * immigration. An interaction variable}
#' }
#' @details Some of the countries have some duplicated country-years. This is because these were election years, and some of the variables change values in these years. When this dataset is merged with Kingdom it will therefore produce some extra rows in Kingdom because these country-years will be duplicated.
#' @name GolderExtremeRight
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Matt Golder, 2007, "Replication data for: Explaining Variation in the Electoral Success of Extreme Right Parties in Western Europe". 
#' @keywords dataset election economy
#' @source Matt Golder's dataverse homepage: \url{http://dvn.iq.harvard.edu/dvn/dv/mgolder}
#' @seealso desaw, GolderFiscalPolicyEU
#' @examples
#' # This example will replicate model 2 in table 2 in the article
#' data(GolderExtremeRight)
#' library(AER)
#' tobit(extreme ~ unemployment + immigration + UnempImmig +
#' log(magnitude) + uppertier + factor(country),left=0,data=GolderExtremeRight)
NULL