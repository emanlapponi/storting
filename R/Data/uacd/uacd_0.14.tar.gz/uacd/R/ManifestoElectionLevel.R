#' ManifestoElectionlevel - Comparative Manifesto Project - Election Level
#' 
#' @description Comparative Manifesto Project - Election Level
#' @format An unbalanced dataframe with 623 rows and 14 variables.
#' Rows are election-years.
#' It includes elections in 55 countries during the period 1920 - 2012.
#' Mean number of year per country is 11.
#' \describe{
#' 
#' \item{country}{Manifesto Project country code.
#' 
#' 11 Sweden
#' 
#' 12 Norway
#' 
#' 13 Denmark 
#' 
#' 14 Finland 
#' 
#' 15 Iceland
#' 
#' 21 Belgium
#' 
#' 22 Netherlands
#' 
#' 23 Luxembourg
#' 
#' 31 France
#' 
#' 32 Italy
#' 
#' 33 Spain
#' 
#' 34 Greece
#' 
#' 35 Portugal
#' 
#' 41 Germany
#' 
#' 42 Austria
#' 
#' 43 Switzerland
#' 
#' 51 Great Britain
#' 
#' 52 Northern Ireland
#' 
#' 53 Ireland
#' 
#' 54 Malta
#' 
#' 55 Cyprus
#' 
#' 61 United States
#' 
#' 62 Canada
#' 
#' 63 Australia
#' 
#' 64 New Zealand
#' 
#' 71 Japan
#' 
#' 72 Israel
#' 
#' 73 Sri Lanka
#' 
#' 74 Turkey
#' 
#' 75 Albania
#' 
#' 76 Armenia
#' 
#' 77 Azerbaijan
#' 
#' 78 Belarus
#' 
#' 79 Bosnia-Herzegovina
#' 
#' 80 Bulgaria
#' 
#' 81 Croatia
#' 
#' 82 Czech Republic
#' 
#' 83 Estonia
#' 
#' 84 Georgia
#' 
#' 85 German Democratic Republic
#' 
#' 86 Hungary
#' 
#' 87 Latvia
#' 
#' 88 Lithuania
#' 
#' 89 Macedonia
#' 
#' 90 Moldova
#' 
#' 91 Montenegro
#' 
#' 92 Poland
#' 
#' 93 Romania
#' 
#' 94 Russia
#' 
#' 95 Serbia
#' 
#' 96 Slovakia
#' 
#' 97 Slovenia
#' 
#' 98 Ukraine
#' 
#' 113 Korea
#' 
#' 171 Mexico}
#' \item{year}{Year of election}
#' \item{edate}{Month/Day/Year of election.}
#' \item{datasetorigin}{Dataset(s) in which the last datapoint of an election first appeared}
#' \item{cnt_parties}{Number of parties covered for the election}
#' \item{sum_pervotes}{Sum of vote share of parties covered for the election}
#' \item{polarization_left}{Polarization left (minimal rile). Rile is Manifestos right-left party-position score}
#' \item{polarization_right}{Polarization right (maximal rile). Rile is Manifestos right-left party-position score}
#' \item{median_party}{Median party}
#' \item{median_party_rile}{Rile of median party. Rile is Manifestos right-left party-position score. Lower scores indicate more to the left}
#' \item{median_voter}{Median voter (Kim-Fording)}
#' \item{median_voter_adj}{Adjusted median voter (adj. Kim-Fording)}
#' \item{median_voter_party}{Median party (based on median voter)}
#' \item{median_voter_party_rile}{Rile of median voter party. Rile is Manifestos right-left party-position score. Lower scores indicate more to the left}
#' 
#'  } 
#' @name ManifestoElectionLevel
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references (2006) Budge, Ian, Hans-Dieter Klingemann, Andrea Volkens, Judith Bara, Michael McDonald. "Mapping Policy Preferences. Estimates for Parties, Electors, and Governments 1945-1998." Oxford: Oxford University Press
#' Project homepage: \url{https://manifestoproject.wzb.eu/}
#' 
#' Laver, Michael and Ian Budge (eds.) (1992): Party Policy and Government Coalitions, Houndmills, Basingstoke, Hampshire: MacMillan Press. 
#' @keywords dataset election position
#' @source Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @details Version 2012-09-25. This is a prerelease. The dataset contains missing values for elections where a) the sum of the vote shares is either less than 80 percent or larger than 110 percent and/or b) the Manifesto Project dataset only covers one party.
#' 
#' Rile is Manifestos right-left party-position score, invented by Michael Laver and Ian Budge (eds.) 1992. For more information on per-variables, see ManifestoFull. It is calculated as: (per104 + per201 + per203 + per305 + per401 + per402 + per407 + per414 + per505 + per601 + per603 + per605 + per606) - (per103 + per105 + per106 + per107 + per403 + per404 + per406 + per412 + per413 + per504 + per506 + per701 + per202)
#' @seealso \link{ManifestoVoter},\link{ManifestoFull},
#' \link{ManifestoGovDec}, \link{ManifestoGovNotes}
#' @examples
#' 
#' data(ManifestoElectionLevel)
#' data(ManifestoFull)
#' ManifestoFull <- ManifestoFull[,c("countryname","country")]
#' 
#' ManifestoElectionLevel <- merge(ManifestoElectionLevel,ManifestoFull,
#'                                 by="country")
#' ManifestoElectionLevel <- ManifestoElectionLevel[!duplicated(ManifestoElectionLevel) & 
#'                                                    ManifestoElectionLevel$year>=1945, ]
#' 
#' #Full time series only, since some countries have short time series
#' ManifestoElectionLevel$fulltime <- NA
#' for(i in 1:nrow(ManifestoElectionLevel)){
#'   ManifestoElectionLevel$fulltime[i] <- ifelse(ManifestoElectionLevel$year[i] <= 1950,1,0)
#' }
#' ManifestoElectionLevel <- ManifestoElectionLevel[order(ManifestoElectionLevel$countryname,
#' ManifestoElectionLevel$year),]
#' for(i in 2:nrow(ManifestoElectionLevel)){
#'   ManifestoElectionLevel$fulltime[i] <- ifelse(ManifestoElectionLevel$countryname[i]==
#'   ManifestoElectionLevel$countryname[i-1],
#'   ManifestoElectionLevel$fulltime[i-1],ManifestoElectionLevel$fulltime[i])
#' }
#' 
#' ManifestoElectionLevel <- 
#' na.omit(ManifestoElectionLevel[which(ManifestoElectionLevel$fulltime==1),])
#' 
#' #Plot difference between median partye rile and median voter party rile
#' par(mfrow=c(length(levels(factor(ManifestoElectionLevel$country))) + 1,1))
#' par(mar=c(0.2,4.1,0.2,2.8))
#' par(oma=c(0.5,0.5,3,0.5))
#' for(i in 1:length(levels(factor(ManifestoElectionLevel$countryname)))){
#'   plot(ManifestoElectionLevel$year
#'   [which(ManifestoElectionLevel$countryname==
#'   levels(factor(ManifestoElectionLevel$countryname))[i])],
#'        ManifestoElectionLevel$median_party_rile
#'        [which(ManifestoElectionLevel$countryname==
#'        levels(factor(ManifestoElectionLevel$countryname))[i])],
#'        xlim=c(1945,2012), ylim=c(-60,60),
#'        col="red",ylab="",yaxt="n",xaxt="n",xlab="",type="l",pch=1)
#'   lines(ManifestoElectionLevel$year
#'   [which(ManifestoElectionLevel$countryname==
#'   levels(factor(ManifestoElectionLevel$countryname))[i])],
#'         ManifestoElectionLevel$median_voter_party_rile
#'         [which(ManifestoElectionLevel$countryname==
#'         levels(factor(ManifestoElectionLevel$countryname))[i])],
#'         type="l",lty="dashed",col="blue",pch=1)
#'   mtext(as.character(levels(factor(ManifestoElectionLevel$countryname))[i]),side=2,
#'         las=1,cex=0.5,line=0.50)
#'   axis(4,at=c(-60,60),labels=c("Left","Right"),cex.axis=0.8,las=1)
#'   abline(h=0,lty="dotted")
#' }
#' plot(0,0,xlim=c(1945,2012), ylim=c(-60,60),type="n",bty="n",ylab="",
#'      yaxt="n",xaxt="n",xlab="",)
#' legend("left",col=c("red","blue","black"),
#'        lty=c("solid","dashed","dotted"),legend=c("Median party","Median voter party",
#'                                                  "Rile score zero"),
#'        bty="n",horiz=TRUE)
#' axis(3,at=c(seq(1945,2012,10),2012),outer=TRUE)
#' 
NULL