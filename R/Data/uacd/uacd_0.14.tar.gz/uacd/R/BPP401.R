#' BPP401 - Beyond Parliamentarism and Presidentialism 401 Constitutions
#' 
#' @description This is one of three datasets used in the article "Beyond Parliamentarism and Presidentialism".
#' @format 401 constitutions and their attributes. 401 rows and 39 variables.
#' \describe{
#' 
#' \item{cowcode}{Correlates of War country code}
#' \item{country}{Country name}
#' \item{year}{Calendar year}
#' \item{region_ccp}{Region of the world where constitution was written}
#' \item{system_num}{No information}
#' \item{assconf}{coded 1 if the constitution states that the government requires assembly confidence in order to exist, 0 otherwise.
#' 
#' 
#' Assconf is coded 1 only when the constitution explicitly states that the government is collectively responsible to the legislative assembly and that, once confidence is removed, the government must resign. Thus, if the constitution states that the government is collectively (or individually) responsible but does not say anything about the government having to be removed if it loses confidence, we do not code it as having assembly confidence. Similarly, if the constitution only provides for the responsibility of individual ministers, we code it as not having assembly confidence,
#' even if the	constitution says the minister must resign if
#' he/she loses confidence}
#' \item{execlelc}{coded as 1 if popular direct election;
#' 2 if popular indirect election;
#' 3 if indirect election by legislature;
#' 4 if indirect election by a body that includes members of non-legislative organizations or of sub-national legislatures;
#' 5 if not elected}
#' \item{whoishead}{Coded 1: President, 2: Governor-general (representing a monarch), 3: Monarch, 4: Other}
#' \item{execnum}{How many executives are specified in constitutions. 1 if Non; 2 if one; 3 if two; 96 if other; 97 if unable to determine; 98 if not specified}
#' \item{hosdec}{Does the head of state have decree power? 1 if yes; 2 if no; 97 if unable to determine; 98 if not specified; 99 if not applicable}
#' \item{hogdec}{Does the head of government have decree power? 1 if yes; 2 if no; 97 if unable to determine; 98 if not specified; 99 if not applicable}
#' \item{cabappt_1}{Head of state appoints cabinet}
#' \item{cabappt_2}{Head of government appoints cabinet}
#' \item{em}{Does the constitution have provisions for calling a state of emergence? 1 if yes; 2 if no; 96 if other; 97 if unable to determine}
#' \item{legdiss}{Who, if any, can dismiss the legislature? 1 if head of state; 2 if head of government; 3 if two; 96 if other; 97 if unable to determine; 98 if not specified}
#' \item{intexec}{Does the legislature have the power to interpallate members of the executive branch, or similarly, is the executive responsible for reporting its activities to the legislature on a regular basis?
#' 1 if legislature can call executive to report as it sees fit; 2 if executive must rport to legislature on regular intervals; 3 if both; 4 if neither; 90 if left explicitly to non-constitutional law; 97 if unable to determine; 99 if not applicable}
#' \item{invexec}{Does the legislature have the power to investigate the activities of the executive branch? 1 if yes; 2 if no; 96 if other; 97 if unable to determine; 98 if not specified; 99 if not applicable}
#' \item{leg_in_1}{Constitution specifies that the head of state can initiate general legislation}
#' \item{leg_in_2}{Constitution specifies that the head of government can initiate general legislation}
#' \item{leg_in_3}{Constitution specifies that the head of government/cabinet can initiate general legislation}
#' \item{legapp}{Who has the power to approve/reject legislation once it has been passed by the legislature (not including reviews for constitutionality)? 1 if head of state; 2 if head of government; 3 if both head of state and head of governemnt; 4 if the government/cabinet; 5 if legislation does not require approval; 0 if left explicitly to non-constitutional law; 96 if other; 97 if unable to determine; 98 if not specified; 99 if not applicable}
#' \item{hinst}{Classification of democracies as presidential, parliamentary and Semi-presidential (from Cheibub 2007, see \link{DD})}
#' \item{dpi_system}{(from Beck et al. 2001)}
#' \item{gol_inst}{}
#' \item{gtm_parl}{}
#' \item{no_ce}{}
#' \item{regime}{Classification of presidential, parliamentary and semi-presidential.
#' 
#'\strong{Presidential}: Constitutions	in which the head of state is popularly elected (directly or indirectly) and the government does not need assembly confidence in order to exist.
#' 
#'\strong{Parliamentary}: Constitutions in which the head of state is a monarch or a president elected by the existing legislature,
#'and the government must obtain the confidence of the legislature in order to remain in power.
#'
#'\strong{Semi-presidential}: Constitutions in which the head of state is popularly elected (directly or indirectly) and the government needs to obtain the confidence
#'of the legislative assembly in order to exist.}
#'
#'}
#' @name BPP401
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references  José Antonio Cheibub, Zachary Elkins and Tom Ginsburg. "Beyond Presidentialism and Parliamentarism". British Journal of Political Science, available on CJO2013. doi:10.1017/S000712341300032X. 
#' @source \url{http://journals.cambridge.org/action/displayAbstract?fromPage=online&aid=9072592} 
#' @seealso \link{BPPSimilarity} \link{BPPTSCS}
#' @keywords dataset constitutions
#' @examples
#' library(uacd)
#' data(BPPSimilarity)
NULL