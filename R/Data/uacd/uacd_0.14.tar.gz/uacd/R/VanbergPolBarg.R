#' VanbergPolBarg - Replication data for "Policing the Bargain: Coalition Government and Parliamentary Scrutiny."
#' 
#' @description Lanny W. Martin and Gerog Vanbergs replication data for "Policing the Bargain: Coalition Government and Parliamentary Scrutiny."
#' @format A dataframe with 284 rows and 16 variables.
#' Each row is a unique government bill in Germany (1983 - 1994) or Netherlands (1982 - 1994).
#' \describe{
#' \item{country}{Name of country (Germany og Netherlands)}
#' \item{ministry}{Name of the ministry}
#' \item{lengthlow}{Length of legislative process. Number of days between bill introduction and the final vote on the bill.}
#' \item{wcoalimp}{Government issue saliency. The issue saliency of the bill for coalition members}
#' \item{wdivsal}{Government issue divisiveness. Ideological divergence within a coalition}
#' \item{woppimp}{Opposition issue saliency. Saliency of the issue from the point of the opposition}
#' \item{oppdivsal}{Opposition issue divisiveness. Ideological differences between the parties in the opposition and the minister responsible for initiating the bill}
#' \item{censorlow}{The "end" of a bill. However, it is uncertain whether value 1 implies passed or defeated (or expired).}
#' \item{dimension1}{Tax policy type of bill dummy. Income taxes, the value-added tax, tax allowances,
#' welfare or health services benefits, disabled workers benefits, family allowances.}
#' \item{dimension2}{Foreign policy type of bill dummy. Relations with the Soviet Union or Warsaw Pact,
#' cooperation with NATO initiatives relevant to East-West relations (Note: No bills after 1989 were collected on this dimension)}
#' \item{dimension3}{Industrial policy type of bill dummy. Industrial production levels,
#' industrial relations, state-owned corporations, market (de) regulation, unions and employer associations,
#' wage policy, job training, conomic competitiveness}
#' \item{dimension4}{Social policy type of bill dummy. Abortion, homosexuality, alternative lifestyles,
#' domestic cohabitation, pornography, moral issues}
#' \item{dimension5}{Clerical policy type of bill dummy. State intervention into religious affairs
#' (Note: in the current sample, no legislation falls into this category. All entries are zero)}
#' \item{dimension6}{Agricultural policy type of bill dummy. Price regulation of agricultural goods, agricultural subsidies,
#' quotas on agricultural products}
#' \item{dimension7}{Regional policy type of bill dummy. Centralization or decentralization, alterations to municipal or regional laws,
#' redistricting of communal boundaries, regional institutional reforms}
#' \item{dimension8}{Environmental policy type of bill dummy. Air, soil, or water pollution,
#' regulation of emissions standards, chlorofluorocarbons, ecological preservation}
#' }
#' @details This is a data set over minsitries in Germany and Netherlands.
#' 
#' Note that government and opposition divisiveness measures are interacted with their respective government and opposition saliency weight.
#' @name VanbergPolBarg
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Martin, W. Lanny and Georg Vanberg (2004). "Policing the Bargain: Coalition Government and Parliamentary Scrutiny" in \emph{American Journal of Political Science} Vol. 48 No. 1, p. 13 - 27
#' @keywords dataset parliament position cabinet
#' @source Georg Vanbergs home'page: \url{http://people.duke.edu/~gsv5/styled-2/index.html}
#' @seealso VanbergCoPol
#' @examples
#' data(VanbergPolBarg)
#' library(survival)
#' 
#' # On page 21 and 22 they claim to be running a parametric model with a Weibull distribution.
#' #In their .do file, it says stset lengthlow, failure(censorlow)
#' # However, following their .do file and the article descriptions,
#' #this replication Weibull returns very different results.
#' #It is unclear what they are saying in their footnote on page 22 about interactions
#' #(see details). Thus it might be a misspecified interaction in this model.
#' 
#' summary(survreg(Surv(lengthlow,censorlow) ~ wdivsal + wcoalimp
#'                 + oppdivsal + woppimp + factor(dimension2)
#'                 + factor(dimension3) + factor(dimension4) + factor(dimension6)
#'                 + factor(dimension7) + factor(dimension8),
#'                 data=VanbergPolBarg, dist="weibull"))
#' 
NULL