#' DD  -  Democracy and Dictatorship Revisited from Cheibub, Gandhi and Vreeland (2010).
#' 
#' @description This dataset contains classification of political regimes as democracy and dictatorship, classification
#' of democracies as parliamentary, semi-presidential (mixed) and presidential and classification of dictatorships as 
#' military, civilian and royal.
#' For full documentation, see the orginal 
#' \href{https://uofi.box.com/shared/static/e6e312753fbc609fc379.pdf}{codebook}. 
#' 
#' @format A dataframe with 9159 rows and 78 variables. 
#' It covers 202 countries, from 1946 or year of independence to 2008.
#' \describe{
#' 
#' \item{order}{Sequential numbering of rows.}
#' \item{ctryname}{Country name.}
#' \item{year}{Calender year.}
#' \item{aclpcode}{Country code used in previous versions of this dataset (The so called ACLP, PPP, etc., databases). }
#' \item{cowcode}{Correlates of war country code.}
#' \item{cowcode2}{Modified correlates of war country code. See explantion under "Organizaing the world" in the full codebook.}
#' \item{ccdcodelet}{Three letter country code used by the Cline Center for Democracy, University of Illinois at Urbana-Campaign. }
#' \item{ccdcodenum}{Numberic country code used by the Cline Center for Democracy, University of Illinois at Urbana-Campaign.}
#' \item{aclpyear}{Concatenation of aclpcode and year. }
#' \item{cowcode2year}{Concatenation of cowcode2 and year. }
#' \item{cowcodeyear}{Concatenation of cowcode and year. }
#' \item{chgterr}{Dummy variable coded 1 for all the years of a country that experienced significant 
#'  gains or losses of territory, 0 otherwise.}
#' \item{ychgterr}{Dummy variable coded 1 for the year in which a country gained or lost significant parts of its territory, 
#' and 0 otherwise. }
#' \item{flagc_cowcode2}{Dummy variable coded 1 for the first year a country (defined by cowcode2) is observed in the dataset, 
#' and 0 otherwise. }
#' \item{flage_cowcode2}{Dummy variable coded 1 for the last year a country (defined by cowcode2) is observed in the dataset,
#' and 0 otherwise. }
#' \item{entryy}{Year the country is first observed in the dataset (repeated for all years a country is in the dataset). }
#' \item{exity}{Year the country is last observed in the dataset (repeated for all years a country is in the dataset).}
#' \item{cid}{}
#' \item{wdicode}{World Development Indicators (string) country identifier. }
#' \item{imf_code}{International Monetary Fund (numeric) country identifier.}
#' \item{politycode}{Polity IV (numeric) country identifier. }
#' \item{bankscode}{Banks (numeric) country identifier. }
#' \item{dpicode}{DPI (string) country identifier. }
#' \item{uncode}{United Nations (numeric) country identifier. }
#' \item{un_region}{United Nations (numeric) geographic region identifier. }
#' \item{un_region_name}{United Nations (string) geographic region identifier.}
#' \item{un_continent}{United Nations (numeric) continent identifier. }
#' \item{un_continent_name}{United Nations (string) continent identifier.}
#' \item{aclp_region}{Alvarez, Cheibub, Limongi and Przeworski (1996, 2000) (numeric) region identifier.}
#' \item{bornyear}{Year the country is first identified as such. }
#' \item{endyear}{Year the country stops being identified as such.}
#' \item{dupcow}{?}
#' \item{dupwdi}{?}
#' \item{dupun}{?}
#' \item{dupdpi}{?}
#' \item{dupimf}{?}
#' \item{dupbanks}{?}
#' \item{exselec}{Mode of effective executive selection: 1) Direct election; 2) Indirect election; 3) Nonelective. }
#' \item{legselec}{Mode of legislative selection: 0) No legislature exists; 1) Non-elective legislature; 2) Elective. }
#' \item{closed}{Status of legislature: 0) Legislature is closed; 1) Legislature is appointed; 2) Legislature is elected. }
#' \item{dejure}{Legal status of parties: 0) All parties legally banned; 1) Legally single party state; 
#' 2) Multiple parties legally allowed. }
#' \item{defacto}{Existence of parties: 0) No parties; 1) One party; 2) Multiple parties. }
#' \item{defacto2}{Existence of parties outside of regime front: 0) No parties; 1) One party; 2) Multiple parties. }
#' \item{lparty}{Parties within the legislature: 0) Either no legislature or all members of the legislature are nonpartisan; 
#' 1) Legislature with only members from the regime party; 2) Legislature with multiple parties. }
#' \item{incumb}{Consolidation of incument advantage. Dummy variable coded 1 if: 
#' (1) the regime year qualifies as a democratic regime and (2) sometime during its current tenure in 
#' office the incumbents (person, party, military hierarchy) unconstitutionally closed the lower house 
#' of the national legislature and rewrote the rules in their favor. See Przeworski et al. (2002:20-22) 
#' for a discussion of the rationale behind this variable. }
#' \item{type2}{Dummy variable coded 1 for the cases excluded from the set of democracies 
#' uniquely because they violate the “alternation” rule, and 0 otherwise. See Przeworski et al. (2000: 23 - 29)
#' and Cheibub, Vreeland and Gandhi (2009) for a discussion of this criteria. }
#' \item{collect}{Dummy variable coded 1 when the effective head is characterized by collective leadership, 0 otherwise. }
#' \item{nheads}{Number of changes in the nominal head of government in each year.}
#' \item{nmil}{Dummy variable coded 1 if the nominal head is or ever was a member of the military by profession, 0 if civilian.}
#' \item{nhead}{Name of the nominal head of government. }
#' \item{npost}{Political title of the nominal head of government. }
#' \item{ndate}{Date of entrance into power of the nominal head of government. }
#' \item{eheads}{Number of changes in the effective head of government each year. }
#' \item{ageeh}{Age of the effective head's spell in office. There is no left-censoring. }
#' \item{emil}{Dummy variable coded 1 if the effective head is or ever was a member of the military by profession, 0 if civilian.}
#' \item{royal}{To qualify as royal, the effective head must meet two qualifications: 
#'  1) rule under a title such as kings, emirs, sultans, and 2) have been preceded or succeeded by a relative.}
#' \item{headdiff}{Dummy variable coded 1 if the effective and nominal heads are different people, 0 otherwise.}
#' \item{ehead}{Name of the effective head of government. }
#' \item{epost}{Title of the effective head of government. }
#' \item{edate}{Date of entrance into power of the effective head of government. }
#' \item{tenure08}{Total number of years (up to and including the year 2002) the effective head of government is in power. 
#' tenure is invariant during the spell of each head}
#' \item{comm}{Dummy variable coded 1 if the ruler is the Communist Pary leader, 0 otherwise.}
#' \item{ecens08}{Dummy variable coded 0 for the last year of an effective head’s tenure due to death or for the 
#' last year of effective heads that lasted beyond the time of the last observation, usually 1996, and 1 otherwise. 
#' {\emph{ecens08}} = 0 for rulers who entered as dictators and then legitimately won an election and became democrats.}
#' \item{edeath}{Dummy variable coded 0 for the last year of the effective head´s spell due to the head´s death and 1 otherwise. 
#' Does not distinguish between natural death, assassination, suicide or accidents. }
#' \item{flageh}{Dummy variable coded 1 for the first year an effective head of government is first observed, 0 otherwise.}
#' \item{democracy}{Dummy variable coded 1 if the regime qualifies as democratic. The conditions for this variable are the following:
#'  {\emph{democracy}}=1 if {\emph{exselec}} < 2, {\emph{legselec}}=2, {\emph{closed}}=2,
#'  {\emph{dejure}}=2, {\emph{defacto}}=2, {\emph{defacto2}}=2, {\emph{lparty=2}},
#'  {\emph{type2=0}} and {\emph{incumb}}=0. }
#' \item{assconfid}{Dummy variable coded 1 if the regime is a democracy and the government is subject to 
#' assembly confidence, 0 otherwise.}
#' \item{poppreselec}{Dummy variable coded 1 if the regime is a democracy and the head of state is chosen via popular election. }
#' \item{regime}{Six fold regime classification: 0) Parliamentary democracy; 1) Mixed (semi-presidential) democracy; 
#' 2) Presidential democracy; 3) Civilian dictatorships; 4) Military dictatorship; 5) Royal dicatorship. }
#' \item{tt}{Dummy variable coded 1 when there is a transition to or democracy to or from democracy, 0 otherwise. }
#' \item{ttd}{Dummy variable coded 1 when there is a transition democracy, 0 otherwise. }
#' \item{tta}{Dummy variable coded 1 when there is a transition to dictatorship, 0 otherwise.  }
#' \item{flagc}{Unkown}
#' \item{flagdem}{Dummy variable coded 1 for the first year a country is observed or a new regime 
#' (as defined by democracy) emerges, 0 otherwise.  }
#' \item{flagreg}{Dummy variable coded 1 for the first year a country is observed or a new regime (as defined by regime) emerges, 
#' 0 otherwise.}
#' \item{agedem}{Age in years of the current regime as classified by democracy. 
#' The year in which the regime comes into existence is coded as 1. When applicable, ages were extended back as far as 1870. }
#' \item{agereg}{Age in years of the current regime as classified by regime. 
#' The year in which the regime comes into existence is coded as 1. When applicable, ages were extended back as far as 1870. }
#' \item{stra}{Sum of the past transitions to authoritarianism in a country. 
#' If a country experienced more than one transitions to authoritarianism before 1946, {\emph{stra}} is coded 1 in 1946. }
#' 
#' }
#' 
#' 
#' @name DD
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Cheibub, Gandhi and Vreeland (2010). “Democracy and Dictatorship Revisited.” Public Choice, vol. 143, no. 2-1, pp. 67-101.
#' @source Cheibub, Gandhi and Vreeland (2010). 
#' \url{https://sites.google.com/site/joseantoniocheibub/datasets/democracy-and-dictatorship-revisited}.
#' @seealso PolityIV PolityIVcoups ACImpev
#' @keywords dataset regime parliament
#' @examples
#' #This example replicates models 3, 5 and 6 in Table 2 in the article.
#' 
#' #Loading datasets. Fearon & Laitins´ dataset is available here:
#' #\link{http://www.stanford.edu/group/ethnic/publicdata/publicdata.html}
#' library(foreign);library(car)
#' fearonLaitin <- read.dta("../uacd_extra/rawdata/FearonLaitin/repdata.dta")
#' data(DD)
#'
#' ###Fixing dataset error.
#' fearonLaitin$onset <- recode(fearonLaitin$onset, "4 =1")
#'
#' #Creating new variables 
#' fearonLaitin$PolityLow <- ifelse(fearonLaitin$polity2l>1, 1, 0)
#' fearonLaitin$PolityHigh <- ifelse(fearonLaitin$polity2l>8, 1, 0)
#' DD$dicLeg <- ifelse(DD$legselec==1 | DD$legselec==2 & DD$democracy==0, 1, 0)
#'
#' #Merging datasets
#' NewData <- merge(DD, fearonLaitin, by.x=c("cowcode", "year"),
#' by.y=c("ccode", "year"), all=TRUE)
#'
#' #Estimating models 
#' ddModel3  <- glm(onset ~ dicLeg + warl + gdpenl + lpopl1 + lmtnest + ncontig + Oil + 
#'                  nwstate + ethfrac + relfrac, data=NewData,  family=binomial(logit)) 
#' summary(ddModel3)
#' 
#' ddModel5  <- glm(onset ~ PolityHigh  + warl + gdpenl + lpopl1 + lmtnest + ncontig + Oil + 
#'                  nwstate + ethfrac + relfrac, data=NewData,  family=binomial(logit)) 
#' summary(ddModel5)
#'
#' ddModel6  <- glm(onset ~ PolityLow  + warl + gdpenl + lpopl1 + lmtnest + ncontig + Oil + 
#'                   nwstate + ethfrac + relfrac, data=NewData,  family=binomial(logit)) 
#' summary(ddModel6)
NULL 