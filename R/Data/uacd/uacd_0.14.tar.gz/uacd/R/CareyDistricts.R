#' CareyDistricts - District Magnitude Project
#' 
#' @description John Careys District Magnitude Project.
#' @format A dataframe with 616 rows and 74 variables. Elections-years between 1946 and 2003 in 82 countries.
#' \describe{
#' 
#' \item{case_no}{Case number. Cases are parliamentary/legislative elections in all democratic countries since 1945}
#' \item{country}{Country. Country cases are all countries with populations of over 1 million and in periods when they had a Polity IV political freedom score of >= +6}
#' \item{country2}{As "Country" but numeric}
#' \item{iso3_abbr}{International Organization for Standardization country code}
#' \item{tag}{Combines ISO3_code with last two digits of election year.}
#' \item{election_yr}{Year of election. Most are from \href{https://files.nyu.edu/mrg217/public/es.pdf}{Golder (2005)}. Others from various web-based sources}
#' \item{election_no}{No information in codebook.}
#' \item{election_no_vgdist}{No information in codebook.}
#' \item{election_no_pig}{No information in codebook.}
#' \item{election_no_exp}{No information in codebook.}
#' \item{election_no_surp}{No information in codebook.}
#' \item{election_no_hdi}{No information in codebook.}
#' \item{enpv}{Effective number of (electoral) parties in the election, according to vote shares. Mostly from \href{https://files.nyu.edu/mrg217/public/es.pdf}{Golder (2005)}, a few cases from Gallagher}
#' \item{enps}{Effective number of (legislative) parties in the election, according to lower chamber seat shares. Mostly from \href{https://files.nyu.edu/mrg217/public/es.pdf}{Golder (2005)}, a few cases from Gallagher}
#' \item{disprop}{Disproportionality index (Gallagher formula)}
#' \item{dist_magn}{Mean district magnitude in the election.
#' 
#' Coding rules:
#' 
#' PR: Size of chamber / # of PR districts
#' 
#' Non-compensatory mixed system: Size of chamber / Sum of # of districts (of any sort)
#' 
#' Compensatory mixed system: Size of chamber / # of PR districts
#'      In PR systems, compensatory upper tiers (e.g. Norway and Denmark) were
#'      counted as an additional PR district. Upper tiers that merely redistribute
#'      remainders were not counted.}
#' \item{dist_mag_medians}{Median district magnitude in the election. This means the magnitude (M) of the district for which there are an equal number of districts with greater, and lesser, values on M.
#' 
#' N.B: Our measure of median M is different from the median M (MedMag) variable from
#' \href{https://files.nyu.edu/mrg217/public/es.pdf}{Golder's (2005)} widely cited dataset. Golders codebook describes MedMag as 'the district
#' magnitude associated with the median legislator in the lowest tier. As we understand it, this
#' mean identifying the median by legislator rather than by district – that is, as the legislator for
#' whom there are an equal number of other legislators from districts of greater and or lesser M – then assigning the value of MedMag as the M of that legislators district.
#' 
#' Coding rules:
#' 
#' PR: Median of all PR districts (including compensatory upper tier[s])
#' 
#' Non-compensatory mixed system: Median of all districts (of any sort)
#' 
#' Compensatory mixed system: Median of PR districts}
#' \item{regime}{Regime type / form of government. 0 = parliamentary, 1 = hybrid, 2 = presidential. Source: mainly Cheibub, 2006. Nb. Switzerland coded as "hybrid"}
#' \item{parl}{Parliamentary system. 1 = parliamentary, 0 = other}
#' \item{pres}{Presidential system. 1 = presidential, 0 = other}
#' \item{hybrid}{Hybrid (parliamentary-presidential, semi-presidential) system. 1 = hybrid, 0 = other}
#' \item{es}{Electoral system. 2 = Proportional, 1 = Modified, 0 = Majoritarian. For explanations see the next three variables}
#' \item{legal_thresh}{Legal threshold is coded as the percentage of votes a party must win at the national level to be eligible to win seats, and 0 when no legal threshold applies.}
#' \item{eff_thresh}{Lijphart formula: 75/(Dist_magn + 1)}
#' \item{maxeffleg}{Effective Threshold - the maximum of the legal threshold and Lijphart formula}
#' \item{compensatory}{Dummy to designate mixed SMD-PR systems in which seats in PR tier are allocated to compensate for disproportionalities in SMD tier.
#'
#' =1 if compensatory;
#' =0 if SMD/PR non-compensatory (parallel);
#' =MD if system is not SMD/PR}
#' \item{prop_pr}{The proportion of seats elected by PR for mixed-member systems}
#' \item{pres_gov_crisis_la}{Dummy to denote governments in Latin American presidential systems that faced government crises during the term corresponding to the period of office of each legislature in the dataset.
#' 
#' PGC=1 if a Latin American presidential regime experienced a government crisis during
#' the legislative period identified by a given observation. Government crisis is 'any episode
#' in which the chief executive threatens to dissolve Congress or supports a constitutional
#' reform having that purpose, attempts a military coup against Congress, or "suspends" the
#' term of the legislature ... until the next election. It also includes any situation in which
#' congressional leaders announce a decision to ipeach [sic] the president, to declare him or her
#' incapacitated, or to force his or her resignation; in which at least one hof [sic] the houses of
#' Congress debates any of these alternatives; or in which Congress legitimizes a military or
#' civilian uprising against the executive by accepting his "resignation" or by appointing a
#' successor' (Perez-Linan 2007:44-45).
#' 
#' PGC=0 if a Latin American presidential regime did not experience government crisis
#' during the legislative period identified by a given observation.
#' 
#' PGC = Missing Data for observations other than Latin American presidential regimes.}
#' \item{lat_am_pres}{Dummy denotes Latin American Presidential regimes}
#' \item{sng_pty_gvt}{Single party Government - dummy variable - 1 if a single party government is formed after the election}
#' \item{pig}{Parties in Government. Variable denotes the total number of parties holding cabinet portfolios in first government formed after election.}
#' \item{minority_gvt}{Minority government - dummy variable - 1 if minority government is formed after the election}
#' \item{gvt_survival_days}{Length of survival of government in days.}
#' \item{legeff}{'Batting average' variable for executive legislative proposals. This variable denotes the proportion of legislative initiatives introduced to the legislature were approved.}
#' \item{hs_clarity3}{Clarity of responsibility measure. Scored 1 for high clarity elections, 0 otherwise.}
#' \item{hs_govchng}{Number of government changes (cabinet reshuffles) since last election.}
#' \item{hs_pmchng}{Number of changes of prime minister since last election.}
#' \item{age_dem}{Age of democracy. Measured as election year minus the year in which the country first scored +6 or above on the Polity IV index, plus 1 (i.e. first year a country is democratic = 1).}
#' \item{pol_freedom}{Political freedom score (Polity IV). Most values from Norris, 2005.}
#' \item{econ_freedom}{Economic freedom score (Freedom House) Most values from Norris, 2005. Data for early elections entered at value of earliest datapoint.}
#' \item{federal}{1 = country has a federal political structure, 0 = other. Source: Adsera, Boix and Paine. 2003.}
#' \item{population}{Population of a country in the year of the election, divided by 1 million. Source: UN Population Division annual estimates. Where data is missing, the estimated population for the nearest year is entered.}
#' \item{gdp_head}{GDP per capita, 1990 International Geary-Khamis dollars, divided by 1000. Source: Maddison, 2007, except for Cyprus, from Groningen Growth and Development Centre data, http://www.ggdc.net, and Guyana and Papua New Guinea, from Norris, 2005.}
#' \item{growth}{Mean three-year GDP growth (two years prior to election year + election year). Source: Calculated from data in Maddison, 2007, except for Cyprus, from Groningen Growth and Development Centre data, http://www.ggdc.net, and Guyana and Papua New Guinea, from Cheibub, 2006. One missing value (Israel 1949) entered as the mean value of the variable.}
#' \item{gini}{Gini index of economic inequality. Gini values with corresponding quality values that are either accept, nn, cs, ps, est, or wg are from Deininger, No Date. Data imputed for missing values from nearest year where data are available.}
#' \item{giniquality}{Quality of the Gini value recorded. For Deininger values, the qualities mean:
#' accept included in the WB high quality data set
#' 
#' nn based on a survey of less than natl coverage
#' 
#' cs not included in wb set due to availability of estimate from a consistent source
#' 
#' ps not included cuz no clear reference to primary source
#' 
#' est based on natl accounts or surveys of less than full natl
#' 
#' wg excluded cuz based on income earning population only or derived from non representative tax records
#' 
#' For United Nations University - World Institute for Development Economics Research. 2005, values, the qualities mean:
#' 
#' 1 a) where the underlying concepts are known b) where the quality of the income concept and the survey can be judged as sufficient according to the criteria described above
#' 
#' 2 for observations where the quality of either the income concept or the survey is problematic or unknown or we have not been able to verify the estimates (the sources were not available to us); the country information sheets will often give an indication of the specific problems 
#' 
#' 3 for observations where both the income concept and the survey are problematic or unknown
#' 
#' 4 for observations classified as memorandum items; some of the observations origin from the older compilations of inequality data have been given this rating since the data lying behind the observations often are unreliable
#' 
#' Note - qualities of 3 or 4 are likely not based on the entire country (only accounts for urban areas, for example)}
#' \item{pt_cgexp}{Central government expenditures as a percentage of GDP, constructed using the item Government Finance - Expenditures in the IFS, divided by GDP at current prices and multiplied by 100. Source: Persson and Tabellini. 2003.}
#' \item{pt_cgbgt_spl}{Central government budget surplus (if positive) or deficit (if negative), as a percentage of GDP, constructed using the item Government Finance - Deficit and Surplus in the IFS, divided by the GDP at current prices and multiplied by 100. Source: Persson and Tabellini. 2003.}
#' \item{pt_ssw}{Consolidated central government expenditures on social services and welfare as percentage of GDP, as reported in GFS Yearbook, divided by GDP and multiplied by 100. Source: Persson and Tabellini. 2003.}
#' \item{pt_trade}{Sum of exports and imports of goods and services measured as a share of GDP. Source: Persson and Tabellini. 2003.}
#' \item{pt_prop1564}{Percentage of population between 15 and 64 years old in the total population. Source: Persson and Tabellini. 2003.}
#' \item{pt_prop65}{Percentage of population over the age of 65 in the total population. Source: Persson and Tabellini. 2003.}
#' \item{etnic_fract_fearon}{Ethnic fractionalization index according to Fearon, 2003. The index includes ethnic, linguistic and religious groups, using data from CIA World Factbook, the Encyclopedia Britannica, relevant Library of Congress Country Studies, the Minorities at Risk dataset, national censuses, and various other sources. Fearon's data is from 1990 to 1995, but his numbers are constant values for this period. We have entered the same value for all elections in each country, which means that our coding of this variable only varies across countries and does not vary within countries. Two missing values (for Serbia and Montenegro and Taiwan) were entered as the mean value of this variable.}
#' \item{ethnic_frag}{Ethno-linguistic fragmentation index (ELF) 1960 values from (Easterly and Levine, 1997). 1961, 1985 values are from (Roeder, 2001). Values from 1960-1982 averages are from (Annett, 2001)}
#' \item{ethnic_frag_average_annett}{Dummy variable, coded 1 If the ethnic_frag value is an average from 1960 to 1982, derived from Annett, 2001}
#' \item{dist_equator}{Distance of the capital city of a country from the equator, scaled between 0 (0 degrees) and 1 (either 90 degrees South or 90 degrees North). Source: \url{http://www.mapsofworld.com/utilities/world-latitude-longitude.htm} (accessed on 21 January 2008).}
#' \item{latitude}{Latitude of the capital city of a country (ranging from 90 degrees South to 90 degrees North), rescaled between 0 (90 degrees South) and 1 (90 degrees North). I.e. a measure of how far north a country is. Source: \url{http://www.mapsofworld.com/utilities/world-latitude-longitude.htm} (accessed on 21 January 2008).}
#' \item{hdi_score}{United Nations Human Development Index. Source: \url{http://hdr.undp.org/en/statistics/.}}
#' \item{w_europe}{1 = state in Western Europe, 0 = other. Cases: Austria, Belgium, Cyprus, Denmark, Estonia, Finland, France, Germany, Greece, Ireland, Italy, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, United Kingdom.}
#' \item{americas}{1 = state in North or South America, 0 = other. Cases: Argentina, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Dominican Republic, Ecuador, El Salvador, Guatemala, Guyana, Honduras, Jamaica, Nicaragua, Panama, Paraguay, Peru, Trinidad & Tobago, USA, Uruguay, Venezuela.}
#' \item{former_com}{1 = former Communist state, 0 = other. Cases: Albania, Armenia, Bulgaria, Croatia, Czech Republic, Czechoslovakia, Hungary, Latvia, Lithuania, Macedonia, Moldova, Poland, Romania, Russia, Serbia and Montenegro, Slovakia, Ukraine.}
#' \item{pacific}{1 = state in the Pacific region, 0 = other. Cases: Australia, Fiji, Japan, New Zealand, Papua New Guinea, Philippines, South Korea, Taiwan.}
#' \item{s_asia}{1 = state in South, South East or Central Asia, 0 = other. Cases: Bangladesh, India, Indonesia, Mauritius, Mongolia, Nepal, Sri Lanka, Thailand.}
#' \item{africa_me}{1 = state in Africa or Middle East, 0 = other. Cases: Benin, Botswana, Ghana, Israel, Lesotho, Madagascar, Malawi, Mali, Mozambique, Namibia, South Africa, Turkey.}
#' \item{col_uk}{1 = former colony of United Kingdom, 0 = other. Source: Persson and Tabellini, 2003.}
#' \item{col_sp_po}{1 = former colony of Spain or Portugal, 0 = other. Source: Persson and Tabellini, 2003.}
#' \item{col_oth}{1 = former colony of a country other than UK, Spain or Portugal, 0 = other. Source: Persson and Tabellini, 2003.}
#' \item{es_maj}{Dummy denotes majoritarian electoral system (including SMP, MRO, AV electoral systems).
#' If district magnitude (M) =1 for all districts, ES_maj = 1 ; otherwise = 0
#' 
#' Unless otherwise noted, values are from \href{https://files.nyu.edu/mrg217/public/es.pdf}{Golder (2005)}. Values for Bostwana, Ghana, Mauritius and New Zealand are from the Center on Democratic Performance (No Date)
#' 
#' Values for all countries (unless otherwise noted) that are after 2000 are from the Center on Democratic Performance (No Date)}
#' \item{es_prop}{Dummy denotes pure proportional system (including list PR with large districts, compensatory MMP systems, or STV (if M high enough).
#' 
#' Values for Austria, Belgium, Bolivia, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Ecuador, El Salvador, Estonia, Hungary, Italy, Latvia, Mozambique, Nicaragua, Norway, Paraguay, Peru, Poland, Romania are from Center on Democratic Performance (No Date).
#' 
#' Values from France for 1951 and 1956 from Sinopoli and Iannantuoni (2001)
#' 
#' Values for all countries (unless otherwise noted) that are after 2000 are from the Center on Democratic Performance (No Date)}
#' \item{es_modified}{Dummy denotes modified PR systems (including PR with small districts, PR with high formal threshold, mixed-member parallel systems, or winner-bonus electoral systems)
#' 
#' ES_modified = 1 if:
#' 
#' Median Magnitude (MedM) <= 8, OR
#' 
#' Non-compensatory mixed member, OR
#' 
#' Legal Threshold >= .05, OR
#' 
#' Compensatory mixed member AND Prop_PR <= .333
#' 
#' Values for Albania, Armenia, Bolivia Fiji, Japan, Lesotho, Lithuania, Macedonia, Madagascar, Russia are from Center on Democratic Performance (No Date).
#' 
#' Values for Guatamala from International IDEA, Handbook of Electoral System Design (1997)
#' 
#' Values for all countries (unless otherwise noted) that are after 2000 are from the Center on Democratic Performance (No Date)}
#' \item{cus_vgdist}{Voter-government distance, based on 'center of gravity' in electorate and government, as calculated by Thomas Cusack. The data for the US are dropped, so that only data for parliamentary systems are entered. Source: \url{http://www.wzb.eu/alt/ism/people/misc/cusack/d_sets.en.htm}}
#' \item{cus_vpdist}{Voter-parliament distance, based on 'center of gravity' in electorate and parliament, as calculated by Thomas Cusack. The data for the US are dropped, so that only data for parliamentary systems are entered. Source: \url{http://www.wzb.eu/alt/ism/people/misc/cusack/d_sets.en.htm}}
#' \item{kf_vgdist}{Voter-government distance, based on location of median voter and median member of parliament, as calculated by HeeMin Kim and Richard Fording. The data for the US are dropped, so that only data for parliamentary systems are entered. Source: Kim, Powell and Fording, 2008.}
#' \item{kf_vpdist}{Voter-government distance, based on location of median voter and median member of government, as calculated by HeeMin Kim and Richard Fording. The data for the US are dropped, so that only data for parliamentary systems are entered. Source: Kim, Powell and Fording, 2008.}
#'  } 
#' @name CareyDistricts
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Carey, John M. [2011] Carey data archive. \url{http://sites.dartmouth.edu/jcarey/}
#' 
#' Matt Golder (2005). \href{https://files.nyu.edu/mrg217/public/es.pdf}{Democratic electoral Systems Around the World, 1946-2000.} Electoral Studies 24: 103-121.
#' @keywords dataset election economy cabinet parliament
#' @source Homepage: \url{http://sites.dartmouth.edu/jcarey/data-archive/}
#' @seealso desaw
#' @examples
#' # Failed when attempting to replicate Model 2 in table 1 in the article 
#' # "Electoral Sweet Spot" (2011). It seems that this is due to some coding 
#' # errors in the compensatory variable
#' 
#' # Recode the compensatory variable. There is also 2 instances of the 
#' # odd value 0.0399999991059303 which are coded as missing here
#' library(car)
#' data(CareyDistricts)
#' CareyDistricts$compensatory_ed <- recode(CareyDistricts$compensatory, 
#'    "'0'='parallel';'1'='compensatory'")
#' CareyDistricts$compensatory_ed[which(is.na(
#'    CareyDistricts$compensatory_ed)==TRUE)] <- "Not SMD/PR"
#' CareyDistricts$compensatory_ed[which(
#'    CareyDistricts$compensatory_ed=="0.0399999991059303")] <- NA
#' CareyDistricts$compensatory_ed <- factor(CareyDistricts$compensatory_ed, 
#'    levels=c("Not SMD/PR","compensatory","parallel"))
#' CareyDistricts$magmedians_ed <-  1/CareyDistricts$dist_mag_medians 
#' 
#' # R will not run the model with factor(former_com) included due to few instances of
#' #former communist countries, even though that variable was in the original model. 
#' Model2 <- lm(disprop ~ dist_mag_medians + magmedians_ed + legal_thresh + compensatory_ed
#'              + factor(regime) + factor(election_yr) + pol_freedom + population + gdp_head 
#'              + growth + gini + age_dem + factor(federal) + ethnic_frag + latitude + 
#'              factor(col_uk) + factor(col_sp_po) + factor(col_oth)
#'              + factor(americas) + factor(w_europe) + factor(pacific) + 
#'              factor(s_asia) + factor(africa_me), data=CareyDistricts)
#' summary(Model2)
NULL