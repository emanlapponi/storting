#' Election and Voting - ParlGov's election which includes information on voting.
#' 
#' @description This datasets has information on elections in 35 countries, including voting information.
#' Most countries are covered for the period 1945 - october 2012.
#' Australia, Switzerland and Finland have data before 1940s.
#' It includes 675 elections.
#' This dataset is a copy of election.csv from ParlGov.
#' @format A dataframe with 675 rows and 19 variables. 
#' \describe{
#' 
#' \item{id}{Election id}
#' \item{type_id}{'info_id' of election type}
#' \item{country_id}{Country id code}
#' \item{date}{Election date}
#' \item{first_round_election_id}{election_id of first round election}
#' \item{early}{Early election before constitutionally mandated term end}
#' \item{wikipedia}{link to wikipedia entry or other url if no wikipedia entry exists}
#' \item{seats_total}{Total number of seats in parliament}
#' \item{electorate}{number citizens eligible to vote}
#' \item{votes_cast}{number of votes cast in an election, including invalid and blank votes}
#' \item{votes_valid}{number of votes cast in an election, not including invalid and blank votes}
#' \item{data_source}{short list of data sources used to code this variable}
#' \item{description}{Information about this observation.}
#' \item{comment}{additional information about the coding of this observation}
#' \item{previous_parliament_election_id}{election id of previous national parliament election in the country}
#' \item{previous_ep_election_id}{election id of previous national EP election for this country}
#' \item{previous_cabinet_id}{ParlGov's cabinet id of previous cabinet}
#' \item{old_countryID}{Old ParlGov country id code}
#' \item{old_parlID}{Old ParlGov party id code}
#' #'  } 
#' @name ElectionandVoting
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @details Notice that in Slovakia in 2009, the number of valid votes recorded are almost twice of the recorded electorate size.
#' @references Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' @source election online: \url{http://www.parlgov.org/stable/documentation/table/election.html}
#' @keywords dataset election EU
#' @examples
#' data(ElectionandVoting)
#' data(Cabinet)
#' 
#' Cabinet <- Cabinet[,c("election_id","country_id","country_name")]
#' ElectionandVoting <- merge(ElectionandVoting,Cabinet, by.x="id",
#' by.y="election_id",all.x==TRUE)
#' ElectionandVoting <- ElectionandVoting[!duplicated(ElectionandVoting),]
#' 
#' #Create variable of percentage of valid votes from total electorate
#' ElectionandVoting$turnout <- ElectionandVoting$votes_valid/ElectionandVoting$electorate
#' ElectionandVoting$year <- sapply(strsplit(ElectionandVoting$date, "-"), "[[", 1)
#' ElectionandVoting$year <- as.numeric(ElectionandVoting$year)
#' 
#' ElectionandVoting <- ElectionandVoting[!is.na(ElectionandVoting$turnout),]
#' 
#' #Full time series only, since some countries have short time series
#' ElectionandVoting$fulltime <- NA
#' for(i in 1:nrow(ElectionandVoting)){
#'   ElectionandVoting$fulltime[i] <- ifelse(ElectionandVoting$year[i] <= 1950,1,0)
#' }
#' ElectionandVoting <- ElectionandVoting[order(ElectionandVoting$country_name,
#' ElectionandVoting$year),]
#' for(i in 2:nrow(ElectionandVoting)){
#'   ElectionandVoting$fulltime[i] <- ifelse(ElectionandVoting$country_name[i]==
#'   ElectionandVoting$country_name[i-1],
#'   ElectionandVoting$fulltime[i-1],ElectionandVoting$fulltime[i])
#' }
#' 
#' ElectionandVoting <- ElectionandVoting[which(ElectionandVoting$fulltime==1),]
#' ElectionandVoting <- ElectionandVoting[!ElectionandVoting$year<1945,]
#' 
#' #Plot voter turnout
#' par(mfrow=c(length(levels(factor(ElectionandVoting$country_name))) + 1,1))
#' par(mar=c(0.2,4.1,0.2,2.8))
#' par(oma=c(0.5,0.5,2,0.5))
#' for(i in 1:length(levels(factor(ElectionandVoting$country_name)))){
#'   plot(ElectionandVoting$year[which(ElectionandVoting$country_name==
#'                                       levels(factor(ElectionandVoting$country_name))[i])],
#'        ElectionandVoting$turnout[which(ElectionandVoting$country_name==
#'                                          levels(factor(ElectionandVoting$country_name))[i])],
#'        xlim=c(1945,2012), ylim=c(0,1),bty="n",
#'        col="black",ylab="",yaxt="n",xaxt="n",xlab="",type="l",pch=1)
#'   mtext(as.character(levels(factor(ElectionandVoting$country_name))[i]),side=2,
#'         las=1,cex=0.5,line=0.50)
#'   abline(h=c(0.5,0.75),lty="dashed",col=c("red","orange"))
#' }
#' plot(0,0,xlim=c(1945,2012), ylim=c(0,1),type="n",bty="n",ylab="",
#'      yaxt="n",xaxt="n",xlab="",)
#' legend("right",col=c("red","orange"),horiz=TRUE,bty="n",
#'        lty="dashed",legend=c("50 percent","75 percent"))  
#' axis(3,at=c(seq(1945,2012,10),2012),outer=TRUE)
#' 
NULL