#' PolicyReform -  Replication data for 
#' When Does Policy Reform Work - The Case of Central Bank Independence
#' 
#' @description This dataset contains a smaller version of the replication data for the article 
#' "When Does Policy Reform Work - The Case of Central Bank Independence" by Acemoglu, Johnson, Querubin, Robinson (2008). 
#' It mainly provides information on inflation and centralbank independence for 52 countries 
#' in the time period 1972 to 2005. For full documentation and replication data, 
#' see \url{http://economics.mit.edu/faculty/acemoglu/data/ajqr2008}.
#'
#' @format A balanced dataframe with 1768 rows and 37 variables. 
#' It includes 52 countries in the period 1972 - 2005.
#' \describe{
#'\item{year}{Year.}
#'\item{inflation_unnorm}{Information about this variable has not been found.}
#'\item{country}{Country name. }
#'\item{xconst_mean}{Country's mean value for the period on \link{PolityIV}'s political constraints score. This score is a qualitative measure of constitutional limits on the exercise of arbitrary power by the executive.
#'This mean value is used to categorize the countries in low, medium and high political constraints}
#'\item{year_cbi}{Information about this variable has not been found.}
#'\item{oecd_cbi}{Regional dummy. This is coded 1 for countries in the OECD area}
#'\item{latinamerica_cbi}{Regional dummy. This is coded 1 for countries in Latin-America}
#'\item{europe_cbi}{Regional dummy. This is coded 1 for countries in Europe}
#'\item{xconst_high}{This variable is coded 1 if there are high political constraints in the country. Coding of this variable is based on {\code{xconst_mean}}. Every country with a {\code{xconst_mean}} value higher than one standard deviation from sample mean is coded 1 on this variable.}
#'\item{xconst_med}{This variable is coded 1 if there are medium political constraints in the country. Coding of this variable is based on {\code{xconst_mean}}. Every country with a {\code{xconst_mean}} value within one standard deviation from sample mean is coded 1 on this variable.}
#'\item{concor_high}{This variable is coded 1 if there are high political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s control-of-corruption index}
#'\item{concor_med}{This variable is coded 1 if there are medium political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s control-of-corruption index}
#'\item{concor_low}{This variable is coded 1 if there are low political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s control-of-corruption index}
#'\item{rulaw_high}{This variable is coded 1 if there are high political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s rule-of-law index}
#'\item{rulaw_med}{This variable is coded 1 if there are medium political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s rule-of-law index}
#'\item{rulaw_low}{This variable is coded 1 if there are low political constraints in the country. It differs from the {\code{xconst}}-varibales in that this is based on \link{PolityIV}'s rule-of-law index}
#'\item{exflex_g}{Exchange rate flexibility index from Reinhart and Rogoff (2004)}
#'\item{cbi_cukierman}{CBI index constructed by Cukierman (1992)}
#'\item{expenditure_weo}{Government expenditure as percentage of GDP}
#'\item{cbi_dummy}{This variable is coded as 1 every country year after a major reform to the constitution of central bank law towards increased central bank independence. It is coded as 0 elsewhere. }
#'\item{ecb_dummy}{Dummy for the introduction of Central European Bank, or for the country in question joining the European monetary union after the Central European Bank was established.}
#'\item{log_gdp}{Logarithm of GDP per capita}
#'\item{cbixcon_mean}{This is an interaction variable: {\code{cbi_dummy}} * {\code{xconst_mean}}}
#'\item{cbixcon_mean2}{The 2nd exponent of the interaction term in {\code{cbixcon_mean}}: ({\code{cbi_dummy}} * {\code{xconst_mean}})^2}
#'\item{cbixconlow}{Interaction between {\code{cbi_dummy}} and weak political constraints, which is the entries with a 0 on both {\code{xconst_high}} and {\code{xconst_med}}.}
#'\item{cbixconmed}{Interaction between {\code{cbi_dummy}} and medium political constraints, {\code{xconst_med}}}
#'\item{cbixconhigh}{Interaction between {\code{cbi_dummy}} and high political constraints, {\code{xconst_high}}}
#'\item{cbirlawlow}{Interaction between {\code{cbi_dummy}} and weak political constraints according to rule-of-law index, {\code{rulaw_low}}}
#'\item{cbirlawmed}{Interaction between {\code{cbi_dummy}} and medium political constraints according to rule-of-law index, {\code{rulaw_med}}}
#'\item{cbirlawhigh}{Interaction between {\code{cbi_dummy}} and high political constraints according to rule-of-law index, {\code{rulaw_high}}}
#'\item{cbiccorlow}{Interaction between {\code{cbi_dummy}} and weak political constraints according to control-of-corruption index, {\code{concor_low}}}
#'\item{cbiccormed}{Interaction between {\code{cbi_dummy}} and medium political constraints according to control-of-corruption index, {\code{concor_med}}}
#'\item{cbiccorhigh}{Interaction between {\code{cbi_dummy}} and high political constraints according to control-of-corruption index, {\code{concor_high}}}
#'\item{cbi_mxconlow}{Interaction between {\code{cbi_cukierman}} and weak political constraints, which is the entries with a 0 on both {\code{xconst_high}} and {\code{xconst_med}}.}
#'\item{cbi_mxconmed}{Interaction between {\code{cbi_cukierman}} and medium political constraints, {\code{xconst_med}}}
#'\item{cbi_mxconhigh}{Interaction between {\code{cbi_cukierman}} and high political constraints, {\code{xconst_high}}}
#'\item{year2}{2nd exponent {\code{year}}}
#'\item{year2oecd}{Interaction between time trend and OECD region: {\code{year2}} * {\code{oecd_cbi}}}
#'\item{year2latam}{Interaction between time trend and Latin-America region: {\code{year2}} * {\code{latinamerica_cbi}}}
#'\item{inflation}{Inflation:
#'
#'\eqn{y_{c,t} = \frac{inflation_{c,t}}{1 + inflation_{c,t}}}{%
#' inflation_{c,t}/1 + inflation_{c,t}}
#' 
#' Where inflation c t denotes inflation rate (for example, 0.1 for 10 percent inflation) for country c in year t.
#'
#' This is sometimes referred to as normalized inflation}
#' \item{lag-varibles}{There are 103 variables which end with _lagX, where X is a number between 1 - 5. These variables are coded identically as the variable name they start with, but are lagged with X number of years}
#' \item{cbichange}{This variable is coded 1 for every country that underwent a change in central bank independence during the time period. All other countries are coded 0.}
#' \item{cbi_mchange}{Information about this variable has not been found.}
#
#'}
#'
#' @name PolicyReform
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Acemoglu, Johnson, Querubin, Robinson (2008). "When Does Policy Reform Work - The Case of Central Bank Independence", 
#' Brookings Papers on Economic Activity, 2008(1), pp. 351-418.
#' @source Daron Acemoglus´ homepage \url{http://economics.mit.edu/faculty/acemoglu/data}.
#' @keywords dataset regime economy
#' @examples
#' #This example replicates model 1 in table 1 in the article.
#' 
#' data(PolicyReform)
#' 
#' cl   <- function(dat,fm, cluster){
#'   require(sandwich, quietly = TRUE)
#'   require(lmtest, quietly = TRUE)
#'   M <- length(unique(cluster))
#'   N <- length(cluster)
#'   K <- fm$rank
#'   dfc <- (M/(M-1))*((N-1)/(N-K))
#'   uj  <- apply(estfun(fm),2, function(x) tapply(x, cluster, sum));
#'   vcovCL <- dfc*sandwich(fm, meat=crossprod(uj)/N)
#'   coeftest(fm, vcovCL) }
#' 
#' Data11 <- na.omit(PolicyReform[,c("inflation","cbi_dummy","country","year")])
#' Model11 <- lm(inflation ~ factor(cbi_dummy) + factor(country) + factor(year),data=Data11)
#' Res11 <- round(cl(Data11,Model11,Data11$country),3)
#' 
#' 
#' Data14 <- na.omit(PolicyReform[which(PolicyReform$cbichange==1),c("inflation","cbi_dummy",
#' "country","year")])
#' Model14 <- lm(inflation ~ factor(cbi_dummy) + factor(country) + factor(year),data=Data14)
#' Res14 <- round(cl(Data14,Model14,Data14$country),3)
#' 
NULL