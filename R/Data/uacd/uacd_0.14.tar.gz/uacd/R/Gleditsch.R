#' Gleditsch - Expanded Trade and GDP data
#' 
#' @description Expanded trade, GDP and population data from Kristian Gleditsch
#' @format An unbalanced dataframe with 7633 rows and 11 variables.
#' It includes 196 countries over the period 1948 - 2000.
#' The mean number of years for a country is 38.
#' \describe{
#' 
#' \item{stateid}{Country abbreviation}
#' \item{statenum}{Country code following Gleditsch and Ward}
#' \item{year}{year}
#' \item{pop}{Population in thousands}
#' \item{rdgp96pc}{Real GDP per capita figures in constant US dollars (base 1996)}
#' \item{gdppc}{GDP per capita}
#' \item{origin}{Origin	of population and GDP measures:
#' 
#' 0 Observed data from the Penn World Tables data 6.1	
#' 
#' -1 Observed data point from Penn World Tables data 5.6, with no corresponding point in PWT 6.1 (a)
#' 
#' 1 Lags and leads based on first non-missing observations, deflated to current prices
#' 
#' 2 Interpolated estimates (a)
#' 
#' 3 Estimate based on figures from the CIA World Factbook
#' 
#' Notes:  (b) Some observations have missing data on one but not all of the 
#' the three figures from the Penn World Tables. PWT 6.1 figures are 
#' used whenever available, but the -1 code is used whenever any of 
#' the figures are taken from the PWT 5.6 data 
#' 
#' (a) The previous version had no missing observations within 
#' time series in the GDP data. This is not the case for these data.
#' All of these gaps are between observations from PWT 5.6 (i.e., -1s) and PWT 6.1 (i.e., 0s)}
#' \item{totimp}{Total imports given in millions of current year US dollars}
#' \item{totexp}{Total exports given in millions of current year US dollars}
#' \item{tottrade}{Total trade (import+export) given in millions of current year US dollars}
#' 
#'  } 
#' @name Gleditsch
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @details Data set verison 4.1 (21. july 2004)
#' @references Gleditsch, Kristian S. 2002. "Expanded Trade and GDP data." Journal of Conflict Resolution 46(5):712-24. 
#' Web page: \url{http://privatewww.essex.ac.uk/~ksg/exptradegdp.html}
#' @keywords dataset economy
#' @seealso PWT Maddison MaddisonNew
#' @source Web page: \url{http://privatewww.essex.ac.uk/~ksg/exptradegdp.html}
#' @examples
#' #This example shows how differnet types of cabinets perform
#' #in creating economic growth
#' data(ParlGov);data(Gleditsch)
#' library(plm);library(countrycode);library(effects)
#' 
#' ParlGov <- ParlGov[which(ParlGov$year >=1948 & ParlGov$year <=2000
#'                          & ParlGov$DecemberandCensored > 0 & ParlGov$NewCab==1),]
#' ParlGov$ccode <- countrycode(ParlGov$country_name_short,"iso3c","cown",warn=TRUE)
#' 
#' Growth <- merge(Gleditsch,ParlGov,by.x=c("statenum","year"),
#'                by.y=c("ccode","year"))
#' 
#' 
#' Growth$statenum<- as.factor(as.character(Growth$statenum))
#' pGrowth <- pdata.frame(Growth,c("statenum","year"),drop=TRUE)
#' pGrowth$tottrade_lag <- lag(pGrowth$tottrade,1)
#' pGrowth$pop_lag <- lag(pGrowth$pop,1)
#' pGrowth$gdppc_lag <- lag(pGrowth$gdppc,1)
#' pGrowth$minority_seats_lag <- lag(pGrowth$minority_seats,1)
#' pGrowth$caretaker_lag <- lag(pGrowth$caretaker,1)
#' pGrowth$total_cabinet_parties_lag <- lag(pGrowth$total_cabinet_parties,1)
#' 
#' 
#' Growth <- data.frame(pGrowth)
#' Growth$gdppcchange <- Growth$gdppc - Growth$gdppc_lag
#' 
#' Growthlm <- lm(gdppcchange ~ poly(total_cabinet_parties_lag,3) +
#'                  factor(caretaker_lag) +
#'                  factor(minority_seats_lag) +
#'                  poly(pop_lag,3),
#'                data=Growth[(which(is.na(Growth$pop_lag)==FALSE)),])
#' summary(Growthlm)
#' 
#' termplot(Growthlm,term=1,se=TRUE,rug=TRUE)
#' abline(h=0)
#' 
NULL