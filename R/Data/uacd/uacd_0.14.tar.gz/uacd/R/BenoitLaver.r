#' BenoitLaver - Party Policy in Modern Democracies
#' 
#' @description This is the Benoit -  Laver expert survey of party positions in 47 modern democracies
#' @format A cross-section dataframe with 8106 rows and 10 variables.
#' It covers is 325 parties in 47 countries.
#' \describe{
#' 
#' \item{Country}{Name of country}
#' \item{Party}{Party abbrevation}
#' \item{PartyName}{Name of party}
#' \item{Dimension}{Policy dimension.
#' 
#' Spending v. Taxes: Increase taxes (1) - (20) Cut taxes.
#' 
#' Social: Favours liberal lifestyle (1) - (20) Oppose liberal lifestyle.
#' 
#' Privatization: Promote state ownership (1) - (20) Oppose state ownership.
#' 
#' EU joining: Oppose joining EU (1) - (20) Favors joining EU.
#' 
#' Environment: Support protection of environment even at the expense of economic growth (1) - (20) Supports economic growth even at the expense of the protection of environment.
#' 
#' Former Communist: Former communist party officials should have the same rights and opportunities as other citizens to participate in public life (1) - (20) Former communist party officials should be kept out of public life.
#' 
#' Foreign Land Ownership: Suppor unrestricted rights of foreigners to purchase and own land (1) - (20) Oppose any right of foreigners to purchase and own land.
#' 
#' Media Freedom: Free media (1) - (20) Regulate media.
#' 
#' Nationalism: Promotes cosmopolitan rather than national consciousness, history and culture (1) - (20) Promotes national rather than cosmopolitan consciousness, history and culture.
#' 
#' Religion: Support religious principles in politics (1) - (20) Oppose religious principles in politics.
#' 
#' Urban-Rural: Promote interest of urban voters (1) - (20) Promotes interest of rural voters.
#' 
#' Decentralization: Promote decentralization (1) - (20) Oppose decentralization.
#' 
#' Left-Right: Left (1) - (20) Right.
#' 
#' Civil Liberties: Promote civil liberties even when it hampers efforts to fight crime and promote law and order (1) - (20) Support tough measures to fight crime and promote law and order, even when this means curtailing civil liberties.
#' 
#' Neighbour Relations: Suppoert closer relations with Eastern neighbours rather than with NATO and Western Europe (1) - (20) Supports closer relations with NATO and Western Europe rather than with Eastern Europe.
#' 
#' EU: Enlargement: Favor extension of EU (1) - (20) Oppose extension of EU.
#' 
#' EU: Peacekeeping: Favor involvement in EU security and peacekeeping missions (1) - (20) Oppose involvement in EU military affairs.
#' 
#' EU: Strengthening: Favour more powerful and centralized EU (1) - (20) Oppose more powerful and centralized EU.
#' 
#' Immigration: Favour policies designed to help integrate asylum seekers and immigrants into society (1) - (20) Favour policies designed to help asylum seekers and immigrants return to their country of origin.
#' 
#' Northern Ireland: Oppose permanent British presence in Northern Ireland (1) - (20) Favors permanent British presence in Northern Ireland.
#' 
#' NATO/Peacekeeping: Favor involvement in European security and peacekeeping missions (1) - (20) Oppose involvement in European military affairs.
#' 
#' Deregulation: Favor state regulation of market (1) - (20) Favours deregulation.
#' 
#' EU: Accountability: Promote direct accountability of the EU to citizens via institutions such as the European Parliament (1) - (20) Favours indirect accountability of EU to citizens via their own national governments.
#' 
#' EU: Authority: Favours increase in EU policy space (1) - (20) Favors reducing EU policy space.
#' 
#' EU: Larger/Stronger: Opposes an expanded and stronger EU (1) - (20) Favours an expanded and stronger EU.
#' 
#' Globalization: Opposed to all consequences of globalisation (1) - (20) Favorable toward the consequences of globalisation.
#' 
#' Health Care: The government should provide universal health care (1) - (20) Medical expenses should be paid by individuals and private insurance plans.
#' 
#' US Affairs: Support an expanded US military and political role in world affairs (1) - (20) Oppose an expanded US military and political role in world affairs.
#' 
#' Palestinian State: Favours establishement of 100 percent sovreign Palestinian state in the West Bank and Gaza strip (1) - (20) Oppose any form of independent sovreign Palestinian state.
#' 
#' Security: Favours pursuit of peace initiatives with the intention to return to the 1967 green line border in return for durable peace (1) - (20) Favours expansion of the territory controlled by Israel in any future agreement to include most of the territory currently occupied by Jewish settlements.
#' 
#' Quebec: Support Quebec sovreignty (1) - (20) Oppose Quebec sovreignty.
#' 
#' Privacy: Support policies protecting the interests of a private person (1) - (20) Oppose policies protecting the interest of a private person (homosexuality, abortion, euthanasia).
#' 
#' Relations with West: Support closer ralations with NATO and the West (1) - (20) Oppose closer relations with NATO and the West.
#' 
#' EU Collective Security: Not in codebook
#' 
#' EU Federalism: Not in codebook
#' 
#' Citizens right: Promotes increasing public access to information (1) - (20) Oppose policies increasing public access to information.
#' 
#' Deficit bonds: Supports the issuing of deficit bonds instead of increasing taxes (1) - (20) Support the increasing of taxes rather than issuing of deficit bonds.
#' 
#' Defence policy: Promotes reduced spending on defence (1) - (20) Promotes increased spending on defence.
#' 
#' National identity: Do not encourage increased respect for emperor (1) - (20) Encourage increased respect for emperor.
#' 
#' Sympathy: How close is expert coder to party, Same as party (1) - (20) Farthest away from respondent}
#' \item{Scale}{Importance or Position}
#' \item{Mean}{Mean position of party}
#' \item{SD}{Standard deviation of party position}
#' \item{N}{number of experts}
#' \item{Vote_Share}{Vote share in election}
#' \item{Election_Date}{Date of election}
#' 
#' } 
#' @name BenoitLaver 
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Benoit, Kenneth and Michael Laver (2006) Party Policy in Modern Democracies, Routledge
#' @source \url{http://www.tcd.ie/Political_Science/ppmd/PPMD_11apr2006.pdf}
#' @keywords dataset party position
#' @examples
#' # This example is inspired by Table 6.A1: "OLS Regressions predicting experts 
#' # left-placements of partiesfrom placements of thesame parties on the tax/spend 
#' # and social policy dimensions" in Benoit and Laver (2006). Since there are 
#' # few observations for each country when using the data set with mean values, 
#' # this example instead employs multi-level model to control for different countries.
#' data(BenoitLaver)
#' LR <- BenoitLaver[which(BenoitLaver$Dimension=="Left-Right"
#'                         & BenoitLaver$Scale=="Position"),]
#' TS <- BenoitLaver[which(BenoitLaver$Dimension=="Taxes v. Spending"
#'                         & BenoitLaver$Scale=="Position"),]
#' Social <- BenoitLaver[which(BenoitLaver$Dimension=="Social"
#'                            & BenoitLaver$Scale=="Position"),]
#' 
#' LR <- merge(LR,TS, by=c("Country","Party","PartyName","Election_Date"),all=TRUE)
#' LR <- merge(LR,Social, by=c("Country","Party","PartyName","Election_Date"),
#' all=TRUE)
#' 
#' # Pooled data OLS:
#' summary(lm(Mean.x ~ Mean.y + Mean,data=LR))
#' 
#' # Run fixed effects to control for country:
#' summary(lm(Mean.x ~ Mean.y + Mean + factor(Country),data=LR))
#' 
#' # Try multilevel to control for country:
#' library(nlme)
#' summary(lme(Mean.x ~ Mean.y + Mean,data=na.omit(LR), random = ~1|Country, method="ML"))
#' 
#' # Mean.x=Left-Right, Mean.y=Taxes v. Spending, Mean=Social
#' 
#' # Another example using coder sympathies. It illustrates that the more 
#' # sympathy the expert coder has for a party, the more likely it is that 
#' # the party was given a score further to the left on Left-Right:
#' data(BenoitLaver)
#' LeftR <- BenoitLaver[which(BenoitLaver$Dimension=="Left-Right"
#'                         & BenoitLaver$Scale=="Position"),]
#' Symp <- BenoitLaver[which(BenoitLaver$Dimension=="Sympathy"
#'                           & BenoitLaver$Scale=="Position"),]
#' 
#' Symp <- merge(LeftR,Symp, by=c("Country","Party",
#' "PartyName","Election_Date"),all=TRUE)
#' 
#' plot(Symp$Mean.x,Symp$Mean.y,
#' xlab="Party Position: Left - Right", ylab="Coder closeness to party")
#' abline(lm(Symp$Mean.x ~ Symp$Mean.y))
#' lines(lowess(Symp$Mean.x, Symp$Mean.y))
NULL
