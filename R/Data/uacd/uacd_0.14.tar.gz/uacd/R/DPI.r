#' DPI - Database on Database of Political Institutions 2012
#' 
#' @description This dataset contains the Database of Political Institutions 2012 (updated Jan. 2013) by Philip E. Keefer. 
#' For additional information see the orignal
#' \href{http://siteresources.worldbank.org/INTRES/Resources/469232-1107449512766/DPI2012_Codebook2.pdf}{codebook}.
#' @format A dataframe with 6764 rows and 125 variables.
#' It covers the period 1975-2012 for all independent countries with populations above 100.000 - 181 countries.
#' 
#' 
#' \describe{
#' \item{countryname}{Country Name.}
#' \item{ifs}{Country Code. }
#' \item{year}{Year.}
#' \item{system}{Political System. {\strong{2)}} Parliamentary, {\strong{1)}} Assembly-elected President, {\strong{0)}} Presidential}
#' \item{yrsoffc}{Chief Executive Years in Office. Dataset use the following: years are counted in which the executive was in power as of January 1 or was elected but hadn’t taken office as of January 1. The executive must actually be in the country to be counted. If an executive is deposed by a coup and returns to power within the same calendar year, the coup is counted as “failed” and the executive’s rule is considered unbroken. On the other hand, if a parliamentary government resigns and then is re-appointed, this is counted as a new government.}
#' \item{finittrm}{Is there a finite Term in Office, {\strong{1)}} Yes {\strong{0)}} No. This gets a 0 in the cases where the constitution with year limits is suspended or unenforced. }
#' \item{yrcurnt}{Years Left in Current Term.}
#' \item{multpl}{ Can Chief Executive Serve Multiple Terms? 1 is recorded if a term limit is not explicitly stated (If {\emph{finitrm}}=0, then {\emph{multipl}}=NA)}
#' \item{military}{Is Chief Executive a Military Officer? {\strong{1}} if the source (Europa or Banks) includes a rank in their title, {\strong{0}} otherwise. If chief executives were formally retired military officers upon taking office, then this variable gets a 0. }
#' \item{defmin}{Is Defense Minister a Military Officer? Same as in {\emph{military}}. If no one in the cabinet with such responsibility, or if there are no armed forces,  then {\strong{NA}}. If there is no defense minister but the chief executive controls military directly, then same answer as in {\emph{military}}}
#' \item{percent1}{President Percentage of Votes, first round. {\strong{NA}} if {\emph{system}} gets a 1 or 2, and in the case of those with a 2 in Executive Index of Electoral Competition (see below for {\emph{eiec}} definition). If there is a prime minister who is considered the chief executive, but there is a president with some powers (e.g., France) then we still record the president’s vote  percent}
#' \item{percentl}{President Percentage of Votes, last round. {\strong{NA}} for reasons above, or if no runoff. If not an election year, records most recent election.}
#' \item{prtyin}{Party of Chief Executive Length of Time in Office. Same rules as {\emph{yrsoffc}}. {\strong{NA}} if there are no parties, if the chief executive is an independent, or if the “party” is the army. In general, the counting restarts from 1 for a party if its name changes. However, in a few cases the sources indicated that party leadership, membership, and platform remained the same following the name change. In these cases, the name change was recorded but the year count did not restart. All of these cases are noted in the database.}
#' \item{execme}{Name of Executive Party. “Independent” if the chief executive is independent, a monarch, in the military, or if there are no parties}
#' \item{execrlc}{Chief Executive Party Orientation. {\strong{1)}} Right; {\strong{2)}} Left; {\strong{3)}} Center; {\strong{0)}} No information; {\strong{NA)}} No executive}
#' \item{execnat}{Chief Executive Party: Nationalist. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{execrurl}{Chief Executive Party: Rural. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{execreg}{Chief Executive Party: Regional. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{execrel}{Chief Executive Party: Religious.{\strong{1)}} Yes {\strong{0)}} No}
#' \item{execage}{Age of Chief Executive Party. We record party age from the first year that the party was founded under its current name (which can be before a country achieves independence). {\strong{NA}} if executive is not affiliated with a party.}
#' \item{allhouse}{Does Party of Executive Control All Houses? {\strong{1)}} Yes {\strong{0)}} No}
#' \item{nonchief}{Party affiliation of Non-Chief Executive in Systems with both President and PM. {\strong{NA}} if the president is ceremonial or non-existent, or if {\emph{system}} has a score of 1 or 0. }
#' \item{totalseats}{Total Seats in Legislature.}
#' \item{gov1me}{Name of Largest Government Party.}
#' \item{gov1seat}{Number of Seats of Largest Government Party.}
#' \item{gov1vote}{Vote Share of Largest Government Party. }
#' \item{gov1rlc}{Largest Government Party Orientation. {\strong{1)}} Right; {\strong{2)}} Left; {\strong{3)}} Center; {\strong{0)}} No information; {\strong{NA)}} No executive}
#' \item{gov1nat}{Largest Government Party: Nationalist. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov1rurl}{Largest Government Party: Rural. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov1reg}{ Largest Government Party: Regional. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov1rel}{Largest Government Party: Religious. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov1age}{Age of Largest Government Party. }
#' \item{gov2me}{Age of Largest Government Party. }
#' \item{gov2seat}{Number of Seats of 2nd Largest Government Party.}
#' \item{gov2vote}{Vote Share of 2nd Largest Government Party. }
#' \item{gov2rlc}{2nd Largest Government Party Orientation. {\strong{1)}} Right; {\strong{2)}} Left; {\strong{3)}} Center; {\strong{0)}} No information; {\strong{NA)}} No executive}
#' \item{gov2nat}{2nd Largest Government Party: Nationalist. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov2reg}{2nd Largest Government Party: Regional. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov2rel}{2nd Largest Government Party: Religious. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov2age}{Age of 2nd Largest Government Party. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3me}{Name of 3rd Largest Government Party. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3seat}{Number of Seats of 3rd Largest Government Party. }
#' \item{gov3vote}{Vote Share of 3rd Largest Government Party.}
#' \item{gov3rlc}{ 3rd Largest Government Party Orientation. {\strong{1)}} Right; {\strong{2)}} Left; {\strong{3)}} Center; {\strong{0)}} No information; {\strong{NA)}} No executive}
#' \item{gov3nat}{3rd Largest Government Party: Nationalist. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3rurl}{3rd Largest Government Party: Rural. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3reg}{3rd Largest Government Party: Regional. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3rel}{3rd Largest Government Party: Religious. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{gov3age}{Age of 3rd Largest Government Party. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{govoth}{Number of Other Government Parties.}
#' \item{govothst}{Number of Seats of Other Government Parties.}
#' \item{govothvt}{Vote Share of Other Government Parties. }
#' \item{opp1me}{Name of Largest Opposition Party.}
#' \item{opp1seat}{Number of Seats of Largest Opposition Party. }
#' \item{opp1vote}{Vote Share of Largest Opposition Party.}
#' \item{opp1rlc}{Largest Opposition Party Orientation. {\strong{1)}} Right; {\strong{2)}} Left; {\strong{3)}} Center; {\strong{0)}} No information; {\strong{NA)}} No executive}
#' \item{opp1nat}{Largest Opposition Party: Nationalist. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp1rurl}{Largest Opposition Party: Rural. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp1reg}{Largest Opposition Party: Rural. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp1rel}{Largest Opposition Party: Religious. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp1age}{Age of Largest Opposition Party. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp2me}{Name of 2nd Largest Opposition Party. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{opp2seat}{Number of Seats of 2nd Largest Opposition Party. }
#' \item{opp2vote}{Vote Share of 2nd Largest Opposition Party. }
#' \item{opp3me}{Name of 3rd Largest Opposition Party.}
#' \item{opp3seat}{Number of Seats of 3rd Largest Opposition Party.}
#' \item{opp3vote}{Vote Share of 3rd Largest Opposition Party.}
#' \item{oppoth}{Number of Other Opposition Parties. }
#' \item{oppothst}{Number of Seats of Other Opposition Parties.}
#' \item{oppothvt}{Number of Votes of Other Opposition Parties}
#' \item{ulprty}{Number of Non-Aligned Parties}
#' \item{numul}{Number of Seats of Non-Aligned Parties.}
#' \item{ulvote}{Vote Share of Non-Aligned Parties. }
#' \item{oppmajh}{Does One Opposition Party have a Majority in the House? {\strong{1)}} Yes {\strong{0)}} No. {\strong{NA}} if no House.}
#' \item{oppmajs}{Does One Opposition Party have a Majority in the Senate? {\strong{1)}} Yes {\strong{0)}} No}
#' \item{dateleg}{Month Legislative Elections Held.}
#' \item{dateexec}{Month Presidential Elections Held.}
#' \item{legelec}{Legislative Election Held. }
#' \item{exelec}{Presidential Election Held.}
#' \item{liec}{Legislative Electoral Competitiveness. {\strong{1)}} No legislature {\strong{2)}} Unelected legislature {\strong{3)}} Elected, 1 candidate {\strong{4)}} 1 party, multiple candidates {\strong{5)}} multiple parties are legal but only one party won seats {\strong{6)}} multiple parties DID win seats but the largest party received more than 75 percent of the seats {\strong{7)}} largest party got less than 75 percent}
#' \item{eiec}{Executive Electoral Competitiveness. {\strong{1)}} No legislature {\strong{2)}} Unelected legislature {\strong{3)}} Elected, 1 candidate {\strong{4)}} 1 party, multiple candidates {\strong{5)}} multiple parties are legal but only one party won seats {\strong{6)}} multiple parties DID win seats but the largest party received more than 75 percent of the seats {\strong{7)}} largest party got less than 75 percent}
#' \item{mdmh}{Mean District Magnitude House. }
#' \item{mdms}{Mean District Magnitude Senate. }
#' \item{ssh}{Number of Seats in Senate/Total Seats in Both Houses. }
#' \item{pluralty}{Plurality. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{pr}{Proportional Representation. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{housesys}{Electoral Rule House. This is coded 1 if most seats are Plurality, zero if most seats are Proportional}
#' \item{sensys}{Electoral Rule Senate. This is coded 1 if most seats are Plurality, zero if most seats are Proportional.}
#' \item{thresh}{Vote Threshold. Records the minimum vote share that a party must obtain in order to take at least one seat in PR systems. If there are more than one threshold, record the one that governs the most seats. No information from sources results in a 0.}
#' \item{dhondt}{D'Hondt System. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{cl}{Closed List. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{select}{Candidate Selection. {\strong{1)}} National (by national executive, party leader, interest groups or party factions) {\strong{2)}} Sub-national (by subset of constituency party members e.g. on conventions) {\strong{3)}} Primary (including party primary and primaries using all the votes of a constituency). Blank if no information.}
#' \item{fraud}{Vote Fraud. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{auton}{Autonomous Regions. Autonomous regions are not the same as states, provinces, etc. An autonomous region is recorded if a source explicitly mentions a region, area, or district that is autonomous or self-governing. {\strong{1)}} Yes {\strong{0)}} No}
#' \item{muni}{Municipal Government. {\strong{0)}} if neither local executive nor local legislature are locally elected. {\strong{1)}} if the executive is appointed, but the legislature elected. {\strong{2)}} if they are both locally elected. No information, or no evidence of municipal governments, is recorded as blank.}
#' \item{state}{State Government. Recorded in the same manner as {\emph{muni}}. If there are multiple levels of sub-national government, we consider the highest level as the “state/province” level}
#' \item{author}{State Government Authority over Taxing, Spending, or Legislating. If 1 for any of these, category gets a 1. }
#' \item{stconst}{Are the Constituencies of the Senators the States/Provinces? No information recorded as blank. If no senate or no states/provinces, NA. If the senate is only partially elected through the constituencies, we score according to how the majority is elected. If the senate is appointed or elected on a national basis, this gets a 0.}
#' \item{gwno}{Gledtisch and Ward country code. }
#' \item{numgov}{Records the total number of seats held by all government parties}
#' \item{numvote}{Records the total vote share of all government parties.}
#' \item{numopp}{Records the total number of seats held by all opposition parties.}
#' \item{oppvote}{Records the total vote share of all opposition parties. }
#' \item{maj}{Margin of Majority. This is the fraction of seats held by the government. It is calculated by dividing the number of government seats ({\emph{numgov}}) by total (government plus opposition plus non-aligned) seats.}
#' \item{partyage}{Average Age of Parties. }
#' \item{herfgov}{Herfindahl Index of Government Parties. The sum of the squared seat shares of all parties in the government. Equals {\strong{NA}} if there is no parliament. If there are any government parties where seats are unknown (cell is blank), the Herfindahl is also blank.}
#' \item{herfopp}{Herfindahl Index of Opposition Parties. Calculated in the same manner as the Herfindahl Government. Equals {\strong{NA}} if there is no parliament. If  there are any opposition parties where seats are unknown (cell is blank), the Herfindahl is also blank. No  parties in the legislature (0 in {\emph{1OPPSEAT}}) results in a {\strong{NA}} in the Herfindahl}
#' \item{herftot}{Herfindahl Index Total. Calculated in the same manner as the Herfindahl Government and Herfindahl Opposition: it is {\strong{NA}} if there is no parliament or if there are no parties in the legislature and blank if any government or opposition party seats are blank.}
#' \item{frac}{Fractionalization Index. The probability that two deputies picked at random from the legislature will be of different parties. It is {\strong{NA}} or blank under the same circumstances as {\emph{herftot}}}
#' \item{oppfrac}{Opposition Fractionalization Index. The probability that two deputies picked at random from among the opposition parties will be of different parties}
#' \item{govfrac}{Government Fractionalization Index. The probability that two deputies picked at random from among the government parties will be of different parties.}
#' \item{tensys_strict}{Unknown.}
#' \item{tensys}{System Tenure.}
#' \item{checks_lax}{Unknown.}
#' \item{checks}{Checks and Balances}
#' \item{stabs_strict}{Stability. This variable count the percent of veto players who drop from the government in any given year. Veto players are defined as in {\emph{checks}}
#' 
#' If {\emph{liec}} is less than 5 (6 for {\emph{stabs_strict}}) in year t-1, then it is assumed that the only veto player in year t-1 is the executive.
#' {\emph{stabs}} in year t is 1 if chief executive changes in year t, 0 otherwise.
#' 
#' If {\emph{liec}} is 5 or greater (6 or greater for {\emph{stabs_strict}}): In presidential systems,
#' if the president does not control the legislature (via closed list and a majority), then veto players are the president, and each chamber.
#' If presidents gain control of the legislature in time t, then the chambers are counted as no longer being veto players. Similarly, if the president changes. If the largest opposition party has a majority in the legislature in time t-1 but not in time t, a change in veto players is again recorded.
#' If the largest government party has a majority in the legislature (and there is noclosed list) in time t-1 but not in time t, a change in veto player is again recorded.
#' 
#' In parliamentary systems, if members of the government coalition in t-1 are no longer in government in t, 
#' that number of veto players changes. Similarly if the prime minister changes. If an opposition party has a 
#' majority in t-1 but that same party does not have a majority in t, then one veto player is said to have 
#' dropped. If parliamentary systems go from no government majority or no closed list to government 
#' majority and closed list in time t, then the chambers are counted as no longer being veto players.}
#' \item{stabs}{Stability. This variable count the percent of veto players who drop from the government in any given year. Veto players are defined as in {\emph{checks}}
#' 
#' If {\emph{liec}} is less than 5 (6 for {\emph{stabs_strict}}) in year t-1, then it is assumed that the only veto player in year t-1 is the executive.
#' {\emph{stabs}} in year t is 1 if chief executive changes in year t, 0 otherwise.
#' 
#' If {\emph{liec}} is 5 or greater (6 or greater for {\emph{stabs_strict}}): In presidential systems,
#' if the president does not control the legislature (via closed list and a majority), then veto players are the president, and each chamber.
#' If presidents gain control of the legislature in time t, then the chambers are counted as no longer being veto players. Similarly, if the president changes. If the largest opposition party has a majority in the legislature in time t-1 but not in time t, a change in veto players is again recorded.
#' If the largest government party has a majority in the legislature (and there is noclosed list) in time t-1 but not in time t, a change in veto player is again recorded.
#' 
#' In parliamentary systems, if members of the government coalition in t-1 are no longer in government in t, 
#' that number of veto players changes. Similarly if the prime minister changes. If an opposition party has a 
#' majority in t-1 but that same party does not have a majority in t, then one veto player is said to have 
#' dropped. If parliamentary systems go from no government majority or no closed list to government 
#' majority and closed list in time t, then the chambers are counted as no longer being veto players.}
#' \item{stabns_strict}{Stability, single chamber (Threshold: {\emph{liec}} = 6). }
#' \item{stabns}{Stability, single chamber. }
#' \item{tenlong_strict}{Longest Tenure of a Veto Player (Threshold: {\emph{liec}} = 6).}
#' \item{tenlong}{Longest Tenure of a Veto Player. }
#' \item{tenshort_strict}{Shortest Tenure of a Veto Player (Threshold: {\emph{liec}} = 6). }
#' \item{tenshort}{Shortest Tenure of a Veto Player. }
#' \item{polariz}{Polarization. {\emph{polariz}} is zero if {\emph{liec}} or {\emph{eiec}} are less than 5 (elections are not competitive). {\emph{polariz_strict}} is zero if {\emph{liec}} or {\emph{eiec}} is less than 6. {\emph{polariz}} is zero if the chief executive’s party has an absolute majority in the legislature. Otherwise: {\emph{polariz}} is the maximum difference between the chief executive’s party’s value ({\emph{execrlc}}) and the values of the three largest government parties and the largest opposition party}
#' \item{polariz_strict}{Polarization. {\emph{polariz}} is zero if {\emph{liec}} or {\emph{eiec}} are less than 5 (elections are not competitive). {\emph{polariz_strict}} is zero if {\emph{liec}} or {\emph{eiec}} is less than 6. {\emph{polariz}} is zero if the chief executive’s party has an absolute majority in the legislature. Otherwise: {\emph{polariz}} is the maximum difference between the chief executive’s party’s value ({\emph{execrlc}}) and the values of the three largest government parties and the largest opposition party}
#' }
#' @name DPI
#' @author Bjørn Høyland Haakon Gjerløw Aleksander Eilertsen 
#' @references Thorsten Beck, George Clarke, Alberto Groff, Philip Keefer, and Patrick Walsh, 2001. 
#' "New tools in comparative political economy: The Database of Political Institutions." 15:1, 165-176 (September), 
#' World Bank Economic Review.
#' @keywords dataset party cabinet leaders election parliament
#' @source Project homepage: 
#' \url{http://econ.worldbank.org/WBSITE/EXTERNAL/EXTDEC/EXTRESEARCH/0,,contentMDK:20649465~pagePK:64214825~piPK:64214943~theSitePK:469382,00.html}
#' @seealso  ParlGov desaw StromMuller CareyDistricts
#' @examples 
#' #This example uses an OLS to show that older parties as executives gives economic growth
#' 
#' #Get three data sets
#' data(DPI);data(PWT);data(ParlGov)
#' 
#' #Remove party-varying rows so that there is one row per cabinet.
#' #For years with several cabinets (for instance England in 1974),
#' 
#' #we choose the cabinet that sat 31st of december in the given year.
#' ParlGov <- ParlGov[which(ParlGov$DecemberandCensored==1 & ParlGov$NewCab==1
#'                          & ParlGov$year >= 1975),]
#' 
#' #Recode unequal country abbreviations so they match between the data sets.
#' library(car);library(pcse)
#' DPI$ifs <- recode(DPI$ifs, "'ROM'='ROU'")
#' PWT$isocode <- recode(PWT$isocode, "'ROM'='ROU'")
#' 
#' #Merge the data sets together.
#' Parl <- merge(ParlGov,DPI,by.y=c("year","ifs"),
#' by.x=c("year","country_name_short"),all.x=TRUE)
#' 
#' Parl <- merge(Parl,PWT,by.x=c("year","country_name_short"),
#' by.y=c("year","isocode"),all.x=TRUE)
#' 
#' #Create lagged variables to improve model specification of causation.
#' Parl <- Parl[order(Parl$country_name_short,Parl$year),]
#' library(plm)
#' pParl <- pdata.frame(Parl)
#' pParl$ppppc_lag <- lag(pParl$ppppc_cgi_derived_constant,1)
#' pParl$prtyin_lag <- lag(pParl$prtyin,1)
#' pParl$cumulative_lag <- lag(pParl$cumulative_election_cabinets,1)
#' 
#' #Create a economic growth variable, and lag it
#' pParl$growth <- pParl$ppppc_cgi_derived_constant - pParl$ppppc_lag
#' pParl$growth_lag <- lag(pParl$growth,1)
#' 
#' Parl <- data.frame(pParl)
#' 
#' #Remove missing variable with listwise deletion. 
#' Agedata <- na.omit(Parl[,c("growth","execage","prtyin_lag","cumulative_lag",
#'                            "minority_seats","coalition_cabinet","growth_lag",
#'                            "country_name_short","year")])
#' 
#' #Run OLS autoregressive model to try to control for time-dependency.
#' growth <- lm(growth~ poly(execage,3) + prtyin_lag + cumulative_lag
#'              + factor(minority_seats) + factor(coalition_cabinet)
#'              + growth_lag,data=Agedata)
#' termplot(growth, term=1,se=TRUE,rug=TRUE,
#'          xlab="Age of executive party",ylab="PPP per capita growth")
#' abline(h=0)
NULL