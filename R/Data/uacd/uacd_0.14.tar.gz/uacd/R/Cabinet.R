#' Cabinet - ParlGov's cabinets-data
#' 
#' @description This dataset has information on Cabinets from 35 countries.
#' This dataset is a copy of view_cabinet.csv from ParlGov.
#' @format An unbalanced dataframe with 6994 rows and 19 variables. Australia, Switzerland and Finland have data before 1940s.
#' Most countries are covered for the period 1945 - october 2012.
#' It includes party-varying variables.
#' \describe{
#' 
#' \item{country_name_short}{Country name abbreviation}
#' \item{country_name}{Country name}
#' \item{election_date}{Election date}
#' \item{start_date}{Cabinet inauguration date}
#' \item{cabinet_name}{Cabinet name (Could have some encoding errors for certain symbols)}
#' \item{caretaker}{Caretaker government, 1=Yes}
#' \item{cabinet_party}{Party in cabinet, 1=Yes}
#' \item{prime_minister}{Prime minister's party, 1=Yes}
#' \item{seats}{Party's number of seats in parliament}
#' \item{election_seats_total}{Total number of seats in parliament}
#' \item{party_name_short}{Party name abbreviation}
#' \item{party_name}{Party name (Could have some encoding errors for certain symbols)}
#' \item{party_name_english}{Party name in english}
#' \item{left_right}{Party placement on left-right dimension, data form Castles/Mair 1983, Huber/Inglehart 1995, Benoit/Laver 2006 and CHESS 2010}
#' \item{country_id}{ParlGov's country id code}
#' \item{election_id}{ParlGov's election id code}
#' \item{cabinet_id}{ParlGov's cabinet id code}
#' \item{previous_cabinet_id}{ParlGov's id code for the previous cabinet}
#' \item{party_id}{ParlGov's party id code}
#'  } 
#' @name Cabinet
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' View_cabinet online: \url{http://www.parlgov.org/stable/documentation/table/view_cabinet.html}
#' @keywords dataset election cabinet party position
#' @examples
#' #This shows that the position of the prime minister's party on
#' #the left-right dimension does not, on average, affect cabinet duration.
#' 
#'  data(Cabinet)
#'  Cabinet <- Cabinet[which(Cabinet$prime_minister==1),]
#'  library(survival);library(eha)
#'  #Create end_date variable:
#'  require(data.table)
#'  library(zoo)
#'  Cabinet <- data.table(Cabinet)
#'  setkey(Cabinet,country_name,start_date)
#'  Cabinet[,end_date:=c(start_date[2:length(start_date)],NA),
#'          by=country_name]
#'  Cabinet <- data.frame(Cabinet)
#'  
#'  #Create a variable with cabinet durations
#'  Cabinet$duration <- difftime(as.Date(Cabinet$end_date),as.Date(Cabinet$start_date), units="weeks")
#'  Cabinet$duration <- as.numeric(Cabinet$duration)
#'  
#'  coxph(Surv(duration) ~ cluster(country_id) + cluster(cabinet_id)
#'        + factor(caretaker) + left_right,data=Cabinet)
#' 
NULL