#' BaldwinHuber -  Replication data for 
#' Economic versus Cultural Differences: Forms of Ethnic Diversity and Public Goods Provision (Baldwin and Huber, 2010).
#' 
#' @description This dataset contains replication data for Baldwin and Huber's (2010) article
#' "Economic versus Cultural Differences: Forms of Ethnic Diversity and Public Goods Provision". 
#' For full documentation, see the original 
#' \href{http://plaza.ufl.edu/kabaldwin/economic_versus_cultural_differences.pdf}{article}.
#'
#' @format A dataframe with 71 rows and 43 variables. It includes 46 countries in the time period 1996 - 2006.
#' No country is covered every year in that period.
#' \describe{
#' \item{country}{Country name.}
#' \item{ccode}{Country code.}
#' \item{pg}{Dependent variable: Public Goods. An index consisting of primary school spending, total public spending on education, 
#' measles immunizations, DPT immunizations, sanitation facilities, water source, roads, contract enforcement, tax revenue and 
#' telephone lines from the World Bank’s World Development Indicators (WDIs). }
#' \item{ELF_fearon_std}{Measure on ethnolinguistic fractionalization from Fearon (2003). 
#' The variable is standarized to have a mean of 0 and a standard deviation of 1. }
#' \item{betweenstd}{Between-group inequality. The variable measures the expected difference in the mean 
#' income of the ethnic groups of any two randomly selected individuals.
#' The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{cultfrac_std}{Fearon’s cultural fractionalization measure of diversity. CF will take the value 0 if all groups 
#' speak the same language,  and will take its maximal value of 1 when all individuals are their own group and speak 
#' highly dissimilar languages. The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{GIstd}{Desmet, Ortuno, and Weber measure of cultural fractionalization. 
#' The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{gini_net_std}{The Gini-index a measure of vertical inequality. This measured is gathered from Solt (2009),
#'  who uses the Luxembourg Income Study to enhance the data from the United Nations University’s World 
#' Income Inequality Database. The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{geo_iso_std}{Geographic isolation. Isolation measures “the extent to which minority members are exposed 
#' only to one another”. }
#' \item{lngdpstd}{Log of GDP per capita , measured using purchasing power parity. 
#' The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{popstd}{Population. The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{polity2std}{Polity 2 from the Polity IV project. The variable is standarized to have a mean of 0 and a standard deviation of 1. }
#' \item{afrobarom}{Dummy variable coded 1 if the BGI (between-group inequality) measure was constructed from the Afrobarometer. }
#' \item{wvs}{Dummy variable coded 1 if the BGI measure was constructed from the World Values Survey (WVS). }
#' \item{cses}{Dummy variable coded 1 if the BGI measure was constructed from the Comparative Study of Electoral Systems (CSES). }
#' \item{cses_wvs}{Dummy variable coded 1 if the BGI measure was constructed from the Comparative Study of Electoral Systems (CSES) and
#' the World Values Survey.}
#' \item{ELF_ethnic}{Fearon's (2003) measure on ethnolinguistic fractionalization. The index reflects the 
#' probability that two randomly selected people from a given country will belong to different such groups, 
#' and ranges from from 0 (perfectly homogeneous) to 1 (highly fragmented).}
#' \item{polity2}{Polity 2-index from the Polity IV-project.}
#' \item{between_afrorev}{A revised measure of BGI in Africa that does not incorporate information on 
#' individuals’ access to public services}
#' \item{pg_05pct}{Dependent variable: Public Goods with 5 percent rule. }
#' \item{elf_05pct}{ELF with 5 percent rule.}
#' \item{between_05pct}{Between group inequality with 5 percent rule.}
#' \item{lngdp_05pct}{Log of GDP with 5 percent rule. }
#' \item{polity_05pct}{Polity score with 5 percent rule }
#' \item{pop_05pct}{Population with 5 percent rule.}
#' \item{gini_05pct}{Gini with 5 percent rule. }
#' \item{iso_05pct}{Geographic isolation with 5 percent rule.}
#' \item{fearon5pct}{Fearon's (2003) measure on ethno-lingustic fractionalization with 5 percent rule. }
#' \item{year}{Year. }
#' \item{pg6_year}{An alternative measure of the dependent variable. If the survey is taken at time t, the average value for each
#' component of the public goods measure in times t through t +3 is taken and then these four-year averages are used to create 
#' the public goods measure. This variable  uses only the six variables for which less than 25% of observations are missing 
#' (i.e the two immunization variables, the two education variables, tax revenues, and telephones) to create the index.  
#' The variable is standarized to have a mean of 0 and a standard deviation of 1.}
#' \item{pg10_year}{An alternative measure of the dependent variable. If the survey is taken at time t, the average value for each
#' component of the public goods measure in times t through t +3 is taken and then these four-year averages are used to create 
#' the public goods measure. This variable  uses all ten variables to create the index. }
#' \item{ELF_year}{Unkown.}
#' \item{between_year}{Between group inequality with the year of the survey included. }
#' \item{polity2std_year}{Plolity2 score with the year of the survey included.}
#' \item{lngdpstd_year}{Log of GDP per capita with the year of the survey included.}
#' \item{popstd_year}{Poulation with the year of the survey included.}
#' \item{gininetstd_year}{The Gini-index with the year of the survey included.}
#' \item{isostd_year}{Geographic isolation with the year of the survey included.}
#' \item{afrobarom_year}{A dummy variable which indicates if the Afrobarometer was conducted in the current year.}
#' \item{wvs_year}{A dummy variable which indicates if the World Values Survey was conducted in the current year.}
#' \item{cses_year}{A dummy variable which indicates if the Comparative Study of Electoral Systems was conducted in 
#' the current year.}
#' \item{polity2_year}{Polity 2 from the Polity IV-project}
#' \item{multipleyears}{A dummy variable which indicates if the analysis includes countries which have observations 
#' for multiple years. }
#' }
#' @details To determine whether the Fearon groups are sufficiently well identified by a survey to merit 
#' the inclusion of the survey in the data set, Baldwin and Huber employes a 15 percent rule.  
#' For each survey, BH calculate the percentage of the population (per Fearon’s data) that cannot be assigned to any of 
#' Fearon’s groups, and they retain the survey if this number is lessthan 15 percent. Their analysis also presents results 
#' that follow a 5 percent rule. 
#' @author Bjørn Høyland Haakon Gjerløw Aleksander Eilertsen 
#' @name BaldwinHuber
#' @references Baldwin and Huber (2010). "Economic versus Cultural Differences: Forms of Ethnic Diversity and 
#' Public Goods Provision", 
#' American Political Science Review, Volume 104, Issue 04, pp 644-662. 
#' @source John Huber's \href{http://www.columbia.edu/~jdh39/Site/Data.html}{homepage}.
#' @keywords dataset economy policy ethnic culture
#' @examples
#' # This example will replicate Model 13 and 17 in Table 7 in the article. 
#' data(BaldwinHuber)
#' library(lmtest);library(sandwich)
#' model13 <- lm(pg ~ ELF_fearon_std +  between_afrorev + gini_net_std + geo_iso_std + 
#' lngdpstd + popstd + polity2std + afrobarom + wvs + cses, data=BaldwinHuber)
#' coeftest(model13, vcov=vcovHC(model13, type="HC1"))
#' 
#' model17 <- lm(pg6_year~ ELF_year + between_year + gininetstd_year + isostd_year + 
#' lngdpstd_year + popstd_year + polity2std_year + year + afrobarom_year + wvs_year,
#' data=BaldwinHuber, subset= polity2_year<10)
#' coeftest(model17, vcov=vcovHC(model17, type="HC1"))
NULL