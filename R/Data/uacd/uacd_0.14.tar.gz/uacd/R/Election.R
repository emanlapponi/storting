#' Election - ParlGov's election-overview
#' 
#' @description This datasets has information on elections in 35 countries.
#' It includes 35 countries. Most countries are covered for the period 1945 - october 2012.
#' Australia, Switzerland and Finland have data before 1940s.
#' It includes 1151 parties from 675 elections.
#' This dataset is a copy of view_election.csv from ParlGov.
#' @format A dataframe with 5480 rows and 16 variables. 
#' \describe{
#' 
#' \item{Country_name_short}{Country name abbreviation}
#' \item{country_name}{Country name}
#' \item{election_type}{Type of election}
#' \item{election_date}{Election date}
#' \item{seats}{Party's number of seats in parliament}
#' \item{election_seats_total}{Total number of seats in parliament}
#' \item{party_name_short}{Party name abbreviation}
#' \item{party_name}{Party name (Could have some encoding errors for certain symbols)}
#' \item{party_name_english}{Party name in english}
#' \item{left_right}{Party placement on left-right dimension, data form Castles/Mair 1983, Huber/Inglehart 1995, Benoit/Laver 2006 and CHESS 2010}
#' \item{country_id}{ParlGov's country id code}
#' \item{election_id}{ParlGov's election id code}
#' \item{previous_parliament_election_id}{ParlGov's election id for the previous election}
#' \item{previous_cabinet_id}{ParlGov's cabinet id code for the previous cabinet}
#' \item{party_id}{ParlGov's party id code}
#' \item{enp_votes}{Effective number of parties votes -- elected parties (Laakso/Taagepera 1979)}
#' \item{enp_seats}{Effective number of parties seats -- elected parties (Laakso/Taagepera 1979)}
#' \item{disproportionality}{Disproportionality index (Gallagher 1991)}
#' \item{advantage_ratio}{Advantage ratio (Taagepera/Shugart 1989)}
#' \item{polarization}{polarization index (Dalton 2008) with left/right-values from \link{Cabinet} and seats share}
#'  } 
#' @name Election
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Döring, Holger and Philip Manow. 2012. Parliament and government composition database (ParlGov): An infrastructure for empirical information on parties, elections and governments in modern democracies. Version 12/10 – 15 October 2012.
#' @source view_party online: \url{http://www.parlgov.org/stable/documentation/table/view_election.html}
#' @keywords dataset election party position parliament EU
#' @examples
#' #This example shows how to illustrate the distribution of seats between parties,
#' #with Sweden as the example.
#' data(Election)
#' 
#' Election$year <- sapply(strsplit(Election$election_date, "-"), "[[", 1)
#' Election$year <- as.numeric(Election$year)
#' Country <- Election[which(Election$country_name=="Sweden" & Election$seats > 0
#'                           & Election$election_type!="ep" & is.na(Election$vote_share)==FALSE
#'                           & is.na(Election$party_name_short)==FALSE),]
#' 
#' Country <- Country[order(Country$election_date,Country$party_name_short),]
#' Country$cumulative_vote <- Country$vote_share
#' for(i in 2:nrow(Country)){
#'   Country$cumulative_vote[i] <- ifelse(Country$election_date[i]==Country$election_date[i-1],
#'                                        Country$vote_share[i] + Country$cumulative_vote[i-1],
#'                                        Country$vote_share[i])
#' }
#' 
#' Country$time <- difftime(Country$election_date,"1970-01-01",unit="days")
#' 
#' #Plot distribution of seats
#' par(oma=c(0,0,0,0.5))
#' plot(0,0,ylim=c(0,100),xlim=c(min(Country$time),max(Country$time)),type="n",
#'           xaxt="n",ylab="Proportion of votes",xlab="Year")
#' for(i in 1:length(levels(factor(Country$party_name_short)))){   
#'   lines(Country$time[which(Country$party_name_short==
#'   levels(factor(Country$party_name_short))[i])],
#'               Country$cumulative_vote[which(Country$party_name_short==
#'         levels(factor(Country$party_name_short))[i])],
#'         type="l",col=rainbow(length(levels(factor(Country$party_name_short))))[i])
#' }
#' axis(1,at=c(round(as.numeric(min(Country$time)),0),
#' round(as.numeric(max(Country$time)),0)),
#'      labels=c(min(Country$year),max(Country$year)))
#' par(xpd=TRUE)
#' legend(max(Country$time)+50,100,legend=levels(factor(Country$party_name_short)),
#'        fil=rainbow(length(levels(factor(Country$party_name_short)))),cex=0.6,bty="n")
#' 
NULL