#' Chapel Hill expert survey 2002
#' 
#' @description This is the 2002 edition of the Chapel Hill expert opinion survey of party positions. The dataset contains the following variables
#' @format A cross-sectional dataframe with 171 rows and 78 variables.
#' It includes 161 parties from 23 countries.
#' For full documentation, see \url{http://www.unc.edu/~hooghe/data_pp.php}
#' \describe{
#' 
#' \item{eastwest}{1 indicates a party from EU-15. 0 indicates a party from Central/Eastern Europe.}
#' \item{eumember}{Was the party a member of the EU in 2002, yes (1) or no (0).}
#' \item{country}{country id}
#' \item{expert}{expert id}
#' \item{year}{Year experts were asked to evaluate All 2002 in this dataset, but could be useful after merging}
#' \item{party_id}{party id}
#' \item{party}{Abbreviation of party name}
#' \item{partyname1}{Party name}
#' \item{partyname2}{English party name}
#' \item{vote}{Vote percentage recieved by the party in the national election most prior to 2003.}
#' \item{vote1}{Vote percentage recieved by the party or the coalition in the national election most prior to 2003.}
#' \item{family}{Classification of party family. 1 = radical right, 2 = conservatives, 3 = liberal, 4 = Christian-democratic, 5 = socialist, 6 = radical left, 7 = green, 8 = regionalists, 9 = no family, 10 = confessional}
#' \item{govt}{Party in government in 2002. 0 = not in government, 0.5 = party in government for a part of 2002, 1 = party in government in 2002}
#' \item{position}{Party position to european integration, categorized from 1 - 7. The higher value the more in favor of integration. Original name: Q1}
#' \item{std_position}{standard deviation among expert in placing the party on "position".}
#' \item{pro_anti}{Variable "position" recoded into a trichotomous variable.0 = anti, 1 = netural, 2 = pro}
#' \item{salience2}{The relative importance of the european integration issue for this party this year. Categorized from 1 - 4 and 4 is most salient, 1 the least. Original name: Q2}
#' \item{ep}{Position of the party leadership on strengthening the European Parliament. Higher value indicate pro-strengthening. NB: Missing values indicate parties that have not taken a stance. Original name: Q3}
#' \item{intmark}{Position of party leadership on expanding EU powers on internal market. Higher value indicates more in favor. NB: Missing values indicate parties that have not taken a stance. Original name: Q4}
#' \item{employ}{Position of party leadership on common employment policy in EU. Higher value indicate more in favor of employment policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q5}
#' \item{agri}{Position of party leadership on EU agricultural spending. Higher value indicates more in favor of agricultural spending. NB: Missing values indicate parties that have not taken a stance. Original name: Q6}
#' \item{cohesion}{Position of party leadership on EU cohesion policy. Higher value indicate more in favor of cohesion policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q7}
#' \item{environ}{Position of party leadership on common EU environmental policy. Higher value indicate more in favor of common EU environmental policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q8}
#' \item{asylum}{Position of party leadership on common policy on political asylum. Higher value indicate more in favor of common policy on political asylum. NB: Missing values indicate parties that have not taken a stance. Original name: Q9}
#' \item{foreign}{Position of party leadership on common foreign and security policy. Higher value indicate more in favor of common foreign and security policy. NB: Missing values indicate parties that have not taken a stance. Original name: Q10}
#' \item{enlargw}{Position of the party leadership on EU enlargement. Higher value indicates more in favor of accession of large wave. This variable is only for EU-15 countries. NB: Missing values indicate parties that have not taken a stance. Original name: Q11}
#' \item{enlarge}{Position of the party leadership on major domestic reforms to qualify for EU memebership. Higher value indicates more in favor of reforms. This variable is only for CEE-applicants. NB: Missing values indicate parties that have not taken a stance. Original name: Q12}
#' \item{dissent2}{The degree of party dissent on the issue of european integration. From 1 (extremely united) to 10 (extremely divided).}
#' \item{dissep}{Has the issue of strengthening European Parliament caused divisions in party leadership? Original name: Q13a}
#' \item{dissintm}{Has the issue of expanding EU powers over internal market caused divisions in party leadership? Original name: Q13b}
#' \item{dissempl}{Has the issue of common employment policy caused divisions in party leadership? Original name: Q13c}
#' \item{dissagri}{Has the issue of agricultural spending in the EU caused divisions in party leadership? Original name: Q13d}
#' \item{disscohe}{Has the issue of EU cohesion policy caused divisions in party leadership? Original name: Q13e}
#' \item{dissenv}{Has the issue of EU environmental policy caused divisions in party leadership? Original name: Q13f}
#' \item{dissasyl}{Has the issue of common political asylum policy caused divisions in party leadership? Original name: Q13g}
#' \item{dissenlw}{Has the issue of EU enlargement caused divisions in party leadership? EU-15 only. Original name: Q13h}
#' \item{dissenle}{Has the issue of EU qualification caused divisions in party leadership? CEE-applicants only. Original name: Q13i}
#' \item{lrgen}{Position of party in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q14}
#' \item{lrecon}{Position of party on economic issues in the broad ideological spectrum. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q15}
#' \item{galtan}{Position of party on democratic freedom and rights in the broad ideological spectrum. Democratic freedom and rights is understood as the role of government in life choices. 0 is extreme left, 10 is extreme right and 5 is center. Original name: Q16}
#' \item{lr_gen}{Position of party in the broad ideological spectrum on a scale between 0 and 1. 0 is extreme left, 1 is extreme right.}
#' \item{std_lrgen}{Standard deviation among experts coding "lrgen"}
#' \item{std_lrecon}{Standard deviation among experts coding "lrecon"}
#' \item{std_galtan}{Standard deviation among experts coding "galtan"}
#' \item{radrt}{radical right party , yes(1) or no(0)}
#' \item{con}{conservative party , yes(1) or no(0)}
#' \item{lib}{liberal party , yes(1) or no(0)}
#' \item{cd}{christiand democratic party , yes(1) or no(0)}
#' \item{soc}{socialist party , yes(1) or no(0)}
#' \item{radleft}{radical left party , yes(1) or no(0)}
#' \item{green}{green party , yes(1) or no(0)}
#' \item{reg}{regionalist party , yes(1) or no(0)}
#' \item{confess}{confessional party , yes(1) or no(0)}
#' \item{agrarian}{agrarian party , yes(1) or no(0). Notice that this party family is not included in spliced variable "family".}
#' \item{noparty}{no party family, yes(1) or no(0)}
#' \item{aus}{Austria, yes(1) or no(0)}
#' \item{be}{Belgium, yes(1) or no(0)}
#' \item{dk}{Denmark, yes(1) or no(0)}
#' \item{esp}{Spain, yes(1) or no(0)}
#' \item{fin}{Finland, yes(1) or no(0)}
#' \item{fr}{France, yes(1) or no(0)}
#' \item{ger}{Germany, yes(1) or no(0)}
#' \item{gr}{Greece, yes(1) or no(0)}
#' \item{irl}{Ireland, yes(1) or no(0)}
#' \item{it}{Italy, yes(1) or no(0)}
#' \item{nl}{Netherlands, yes(1) or no(0)}
#' \item{por}{Portugal, yes(1) or no(0)}
#' \item{sw}{Sweden, yes(1) or no(0)}
#' \item{uk}{United Kingdom, yes(1) or no(0)}
#' \item{bul}{Bulgaria, yes(1) or no(0)}
#' \item{czech}{Czech republic, yes(1) or no(0)}
#' \item{hung}{Hungary, yes(1) or no(0)}
#' \item{lat}{Latvia, yes(1) or no(0)}
#' \item{lith}{Lithuania, yes(1) or no(0)}
#' \item{pol}{Poland, yes(1) or no(0)}
#' \item{rom}{Romania, yes(1) or no(0)}
#' \item{slovak}{Slovakia, yes(1) or no(0)}
#' \item{sloven}{Slovenia, yes(1) or no(0)}
#' 
#'  } 
#' @details The coding of variable "dissep" thorugh "dissenle" is unclear. Codebook says that "# = number of experts checking this issue" but it is unclear what "#" is referring to. Most likely, these variables are coded so that higher value indicates more dissent, as the other dissent variables. 
#' @name ChapelHill2002
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Liesbet Hooghe, Ryan Bakker, Anna Brigevich, Catherine de Vries, Erica Edwards, Gary Marks, Jan Rovny, Marco Steenbergen (2010), "Reliability and Validity of Measuring Party Positions: The Chapel Hill Expert Surveys of 2002 and 2006", European Journal of Political Research, (4): 684-703.
#' @source \url{http://www.unc.edu/~hooghe/data_pp.php}
#' @seealso ChapelHill2010 ChapelHill2006 ChapelHill1999  
#' @keywords dataset party position
#' @examples
#' # This example shows how parties' position on some typical
#' #dimensions affect their likelihood for being a government party in Europe in 2006.
#' data(ChapelHill2002)
#' 
#' InPower2002 <- glm(govt ~ poly(position,3) + poly(lrgen,3)
#'                    + poly(lrecon,3) + poly(galtan,3) + factor(country),
#'                    family="binomial",data=ChapelHill2002)
#' summary(InPower2002)
#' par(mfrow=c(2,2))
#' for(i in 1:4){
#'   termplot(InPower2002,term=i,se=TRUE,rug=TRUE)
#'   abline(h=0)  
#' }
NULL