#' ParliamentaryProcedures - Parliamentary Procedures
#' 
#' @description This dataset contains Parliamentary Procedures from 175 chambers in 131 countries.
#' @format A  cross-sectional dataframe with 119 rows and 9 variables. 46 parties from 17 countries.
#' \describe{
#' 
#' \item{country}{Name of country}
#' \item{chamber}{Name of chamber}
#' \item{year}{Year of establishment of the chamber}
#' \item{experts.no}{Number of experts for the chamber}
#' \item{expert.1.name}{Name of first expert for the chamber}
#' \item{expert.2.name}{Name of second expert for the chamber}
#' \item{expert.3.name}{Name of third expert for the chamber}
#' \item{expert.4.name}{Name of fourth expert for the chamber}
#' \item{expert.5.name}{Name of fifth expert for the chamber}
#' \item{expert.6.name}{Name of sixth expert for the chamber}
#' \item{expert.7.name}{Name of seventh expert for the chamber}
#' \item{expert.8.name}{Name of eigth expert for the chamber}
#' \item{expert.9.name}{Name of ninth expert for the chamber}
#' \item{s.24565.sopfin1}{Parliamentary rules define a method of voting as the
#' standard operating procedure (S.O.P.), which is the voting method that
#' will be used unless another method is explicitly selected. In some
#' parliaments, the S.O.P. varies depending on whether voting is on final
#' passage of bills, adoption of individual articles, amendments to bills,
#' budgets, or no-confidence motions. Regarding votes on final passage of
#' bills, what is the S.O.P. in the chamber?}
#' \item{s.24565.sopfin2}{Provided that secret voting is currently the standard
#' operating procedure for votes on final passage in the
#' chamber, what is the exact form of secret voting?}
#' \item{s.24565.sopfin3}{Provided that signal voting is currently the standard
#' operating procedure for votes on final passage in the chamber,
#' what is the exact form of signal voting?}
#' \item{s.24565.sopfin4}{Provided that open voting is currently the standard
#' operating procedure for votes on final passage in the chamber,
#' what is the exact form of open voting?}
#' \item{s.24565.sopfin4_other}{This is an alternative to previous column, with more in-depth answers. 
#' Provided that open voting is currently
#' the standard operating procedure for votes on final passage in the chamber,
#' what is the exact form of open voting?}
#' \item{s.24565.sopfin5}{Secret voting is currently the standard operating
#' procedure (S.O.P.) for votes on final passage in the chamber.
#' However, the S.O.P. may have changed over time.
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify the first year of the period for
#' which secret voting is the S.O.P}
#' \item{s.24565.sopfin9}{Signal voting is currently the standard operating
#' procedure (S.O.P.) for votes on final passage in the chamber.
#' However, the S.O.P. may have changed over time. Considering the time period
#' since 1980 or the establishment of the chamber (whichever was the later),
#' please specify the first year of the period for which signal voting is the S.O.P.}
#' \item{s.24565.sopfin13}{Open voting is currently the standard operating
#' procedure (S.O.P.) for votes on final passage in the chamber.
#' However, the S.O.P. may have changed over time. Considering the time period since
#' 1980 or the establishment of the chamber (whichever was the later), 
#' please specify the first year of the period for which open voting is the S.O.P.}
#' \item{s.24565.sopfin14}{Considering the time period since 1980 or the
#' establishment of the chamber (whichever was the later),
#' which voting method(s) was/were used as standard operating procedure
#' (S.O.P.) for votes on final passage before open voting became the
#' current S.O.P. in the chamber?}
#' \item{s.24565.sopfin15_SQ001}{This is the first year from the question: Considering the time
#' period since 1980 or the establishment of the chamber (whichever was the later),
#' please specify both the first and the last year of the period for which secret
#' voting was the S.O.P. for votes on final passage in the chamber.}
#' \item{s.24565.sopfin16_SQ002}{This is the last year from the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which signal voting was the S.O.P. for votes on
#' final passage in the chamber.}
#' \item{s.24565.sopfin2_other}{Alternative answer to the question:
#' Provided that secret voting is currently the standard operating procedure for votes
#' on final passage in the chamber, what is the exact form of secret voting?}
#' \item{s.24565.sopfin3_other}{Alternative answer to the question:
#' Provided that signal voting is currently the standard operating procedure
#' for votes on final passage in the chamber,
#' what is the exact form of signal voting?}
#' \item{s.24565.sopfin7_SQ001}{First year answer to the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which signal voting was the S.O.P.
#' for votes on final passage in the chamber}
#' \item{s.24565.sopfin7_SQ002}{Last year answer to the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which signal voting was the S.O.P.
#' for votes on final passage in the chamber.}
#' \item{s.24565.sopfin8_SQ001}{First year answer to the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which open voting was the S.O.P.
#' for votes on final passage in the chamber.}
#' \item{s.24565.sopfin10}{Considering the time period since 1980 or
#' the establishment of the chamber (whichever was the later),
#' which voting method(s) was/were used as standard operating procedure
#' (S.O.P.) for votes on final passage before signal voting became the
#' current S.O.P. in the chamber?}
#' \item{s.24565.sopfin11_SQ001}{First year answer to the question: 
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which secret voting was the S.O.P.
#' for votes on final passage in the chamber}
#' \item{s.24565.sopfin11_SQ002}{Last year answer to the question: 
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which secret voting was the S.O.P.
#' for votes on final passage in the chamber}
#' \item{s.24565.sopfin12_SQ001}{First year answer to the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which open voting was the S.O.P.
#' for votes on final passage in the chamber.}
#' \item{s.24565.sopfin12_SQ002}{Last year answer to the question:
#' Considering the time period since 1980 or the establishment of the chamber
#' (whichever was the later), please specify both the first and the last
#' year of the period for which open voting was the S.O.P.
#' for votes on final passage in the chamber.}
#' \item{s.62552.altfin1}{In most parliaments, parliamentary rules allow more
#' than one means of taking a vote. In general, in addition to secret voting,
#' which other method(s) of voting may currently be used in the chamber?}
#' \item{s.62552.altfin5}{Regarding votes on final passage of bills in the chamber, can
#' secret voting, which is the current standard operating procedure,
#' be set aside in favor of open voting?}
#' \item{s.62552.altfin16_SQ001}{Regarding votes on final
#' passage in the chamber, which in individual MPs
#' are currently entitled to request a signal vote?}
#' \item{s.62552.altfin16_SQ002}{Regarding votes on final
#' passage in the chamber, which parliamentary parties
#' are currently entitled to request a signal vote?}
#' \item{s.62552.altfin16_SQ003}{Regarding votes on final
#' passage in the chamber, which chairmen of the chamber
#' are currently entitled to request a signal vote?}
#' \item{s.62552.altfin16_SQ004}{Regarding votes on final
#' passage in the chamber, which government / government ministers
#' are currently entitled to request a signal vote?}
#' \item{s.62552.altfin16_SQ005}{Regarding votes on final passage in the chamber,
#' which parliamentary comittess are currently entitled to request a signal vote?}
#' \item{s.62552.altfin20_SQ002}{ Regarding votes on final passage in the chamber,
#' what is currently the required quorum of MPs that is necessary for
#' requesting an open vote as a percentage of total MPs in the chamber?}
#' \item{s.62552.altfin25}{After a request for an alternative method of voting
#' has been lodged, some parliaments take a floor vote to decide whether
#' or not the alternative voting method shall be used. If there is such a
#' floor vote in the chamber, which voting method is currently used to decide
#' whether secret voting is set aside in favor of an open vote on final passage?}
#' \item{s.62552.altfin038a_SQ001}{Voting on final passage of bills in the
#' chamber may have changed over time. Considering the time period since 1980 or the
#' establishment of the (whichever was the later), please specify whether
#' or not there have been any changes referring to the method(s)
#' of voting that can be invoked to set aside the S.O.P.?}
#' \item{s.62552.altfin042_SQ001}{Voting on final passage of bills in the
#' chamber may have changed over time. Considering the time period since 1980 or the
#' establishment of the (whichever was the later),
#' please specify whether or not there have been any changes referring to
#' actors that are entitled to request an open vote to set aside the S.O.P.}
#' \item{s.62552.altfin042_SQ002}{Voting on final passage of bills in the
#' chamber may have changed over time. Considering the time period since 1980 or the
#' establishment of the (whichever was the later),
#' please specify whether or not there have been any changes referring to
#' not the actors but the required quorum of MPs that is necessary for
#' requesting an open vote}
#' \item{s.62552.altfin042_SQ003}{Voting on final passage of bills in the
#' chamber may have changed over time. Considering the time period since 1980 or the
#' establishment of the (whichever was the later),
#' please specify whether or not there have been any changes referring to
#' not the actors but the required number of parliamentary parties that is
#' necessary for requesting an open vote}
#' \item{s.62552.altfin042_SQ004}{Voting on final passage of bills in the
#' chamber may have changed over time. Considering the time period since 1980 or the
#' establishment of the (whichever was the later),
#' please specify whether or not there have been any changes referring to
#' method of voting that is used to decide on
#' the floor whether or not the S.O.P. is set aside in favor of an open vote}
#' \item{s.62552.altfin043_SQ001}{Voting on final passage of bills in the chamber
#' may have changed over time. Considering the time period since 1980 or
#' the establishment of the (whichever was the later), please specify
#' below whether or not there have been any changes in actors that are entitled to request an open
#' vote to set aside the S.O.P.
#' \strong{It is unclear how this variable is different from s.62552.altfin042_SQ001}}
#' 
#'  } 
#' @name ParliamentaryProcedures
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Hug, Simon, Simone Wegmann, and Reto Wuest 2012.
#' Parliamentary voting procedures in comparison. Paper prepared for presentation at the EPSA Conference (Berlin, June, 2012).
#' @keywords dataset parliament
#' @examples
#' library(uacd)
#' 
NULL