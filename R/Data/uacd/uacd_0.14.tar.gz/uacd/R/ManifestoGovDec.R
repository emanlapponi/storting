#' ManifestoGovDec - Comparative Manifesto Project - Government Declerations
#' 
#' @description Comparative Manifesto Project - Government Declerations
#' @format A dataframe with 174 rows and 62 variables.
#' It includes 47 governments in 11 countries between 1945 - 2000.
#' \describe{
#' 
#' \item{COUNTRY}{Country code}
#' \item{COUNTRY_NAME}{Country name}
#' \item{GOVID}{Government ID after Woldendorp, Keman and Budge 2000.}
#' \item{INAUGDAT}{Day-month-year of government's inauguration.}
#' \item{PER101}{Foreign special relationships: Positive}
#' \item{PER102}{Foreign special relationships: Negative}
#' \item{PER103}{Anti-imperialism}
#' \item{PER104}{Military: Positive}
#' \item{PER105}{Military: Negative}
#' \item{PER106}{Peace}
#' \item{PER107}{Internationalism: Positive}
#' \item{PER108}{European community: Positive}
#' \item{PER109}{Internationalism: Negative}
#' \item{PER110}{European community: Negative}
#' \item{PER201}{Freedom and Human Rights}
#' \item{PER202}{Democracy}
#' \item{PER203}{Constitutionalism: Positive}
#' \item{PER204}{Constitutionalism: Negative}
#' \item{PER301}{Decentralisation}
#' \item{PER302}{Centralisation}
#' \item{PER303}{Government and Efficiency}
#' \item{PER304}{Political Corruption}
#' \item{PER305}{Political authority}
#' \item{PER401}{Free enterprise}
#' \item{PER402}{Incentives}
#' \item{PER403}{Market regulation}
#' \item{PER404}{Economic planning}
#' \item{PER405}{Corporatism}
#' \item{PER406}{Protectionism: Positive}
#' \item{PER407}{Protectionism: Negative}
#' \item{PER408}{Economic goals}
#' \item{PER409}{Keynesian demand management}
#' \item{PER410}{Productivity}
#' \item{PER411}{Technology and infrastructure}
#' \item{PER412}{Controlled economy}
#' \item{PER413}{Nationalization}
#' \item{PER414}{Economic orthodoxy}
#' \item{PER415}{Marxist analysis}
#' \item{PER416}{Anti-growth economy}
#' \item{PER501}{Environmental protection}
#' \item{PER502}{Culture}
#' \item{PER503}{Social Justice}
#' \item{PER504}{Welfare state expansion}
#' \item{PER505}{Welfare state limitation}
#' \item{PER506}{Education expansion}
#' \item{PER507}{Education limitation}
#' \item{PER601}{National way of life: Positive}
#' \item{PER602}{National way of life: Negative}
#' \item{PER603}{Traditional morality: Positive}
#' \item{PER604}{Traditional morality: Negative}
#' \item{PER605}{Law and order}
#' \item{PER606}{Social harmony}
#' \item{PER607}{Multiculturalism: Positive}
#' \item{PER608}{Multiculturalism: Negative}
#' \item{PER701}{Labour groups: Positive}
#' \item{PER702}{Labour groups: Negative}
#' \item{PER703}{Agriculture and farmers}
#' \item{PER704}{Middle class and professional groups}
#' \item{PER705}{Underprivileged minority groups}
#' \item{PER706}{Non-economic demographic groups}
#' \item{PERUNCOD}{Uncoded quasi-sentences}
#' \item{TOTAL}{Absolute number of quasi-sentences}
#' 
#'  } 
#' @name ManifestoGovDec
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references (2001) Budge, Ian Klingemann, Hans-Dieter Volkens, Andrea Bara, Judith with Tanenbaum, Eric Fording, Richard C. Hearl, Derek J. Kim, Hee Min McDonald, Michael Mendez, Silvia. "Mapping Policy Preferenc(es.) Estimates for Parties, Electors, and Governments 1945-1998." Oxford: Oxford University Press
#' Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @keywords dataset positions cabinet election
#' @source Project homepage: \url{https://manifestoproject.wzb.eu/}
#' @details The per-variables are different topics and their
#' space (measured as percentage) in the party platform.
#' @seealso \link{ManifestoVoter},\link{ManifestoFull},
#' \link{ManifestoElectionLevel}, \link{ManifestoGovNotes}
#' @examples
#' #This example illustrates governments' left-right position over time and compares 
#' #ManifestoGovDec and ManifestoGovNotes.
#' library(ggplot2)
#' 
#' data(ManifestoGovDec)
#' ManifestoGovDec$rile <- ManifestoGovDec$PER104 +
#' ManifestoGovDec$PER201 + ManifestoGovDec$PER203 +
#'   ManifestoGovDec$PER305 + ManifestoGovDec$PER401 +
#'   ManifestoGovDec$PER402 + ManifestoGovDec$PER407 +
#'   ManifestoGovDec$PER414 + ManifestoGovDec$PER505 +
#'   ManifestoGovDec$PER601 + ManifestoGovDec$PER603 +
#'   ManifestoGovDec$PER605 + ManifestoGovDec$PER606 -
#'   ManifestoGovDec$PER103 + ManifestoGovDec$PER105 +
#'   ManifestoGovDec$PER106 + ManifestoGovDec$PER107 +
#'   ManifestoGovDec$PER403 + ManifestoGovDec$PER404 +
#'   ManifestoGovDec$PER406 + ManifestoGovDec$PER412 +
#'   ManifestoGovDec$PER413 + ManifestoGovDec$PER504 +
#'   ManifestoGovDec$PER506 + ManifestoGovDec$PER701 + ManifestoGovDec$PER202
#' ManifestoGovDec$year <- gsub("^.*-.*-","19",ManifestoGovDec$INAUGDAT)
#' ManifestoGovDec$year <- as.numeric(as.character(ManifestoGovDec$year))
#' 
#' GovDec <- ggplot(ManifestoGovDec, aes(year, rile, group = COUNTRY_NAME)) +
#'   geom_rect(aes(ymax=100,ymin=50,xmax=2000,xmin=1945),
#'             alpha=0.009,fill="blue",inherit.aes=FALSE) +
#'   geom_rect(aes(ymax=50,ymin=0,xmax=2000,xmin=1945),
#'             alpha=0.009,fill="red",inherit.aes=FALSE) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Right-Left dimension") +
#'   scale_x_continuous("Year") +
#'   ggtitle("ManifestoGovDec")
#' 
#' 
#' data(ManifestoGovNotes)
#' ManifestoGovPostWar <- ManifestoGovNotes[which(ManifestoGovNotes$govyear>=1945),]
#' 
#' GovNotes <- ggplot(ManifestoGovPostWar, aes(govyear, rile, group = natname)) +
#'   geom_rect(aes(ymax=50,ymin=0,xmax=2005,xmin=1945),
#'             alpha=0.009,fill="blue",inherit.aes=FALSE) +
#'   geom_rect(aes(ymax=-62,ymin=0,xmax=2005,xmin=1945),
#'             alpha=0.009,fill="red",inherit.aes=FALSE) +
#'   geom_line() + geom_smooth(aes(group = 1)) +
#'   scale_y_continuous("Right-Left dimension") +
#'   scale_x_continuous("Year") +
#'   ggtitle("ManifestoGovNotes")
#' 
#' multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
#'   require(grid)
#'   
#'   # Make a list from the ... arguments and plotlist
#'   plots <- c(list(...), plotlist)
#'   
#'   numPlots = length(plots)
#'   
#'   # If layout is NULL, then use 'cols' to determine layout
#'   if (is.null(layout)) {
#'     # Make the panel
#'     # ncol: Number of columns of plots
#'     # nrow: Number of rows needed, calculated from # of cols
#'     layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
#'                      ncol = cols, nrow = ceiling(numPlots/cols))
#'   }
#'   
#'   if (numPlots==1) {
#'     print(plots[[1]])
#'     
#'   } else {
#'     # Set up the page
#'     grid.newpage()
#'     pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
#'     
#'     # Make each plot, in the correct location
#'     for (i in 1:numPlots) {
#'       # Get the i,j matrix positions of the regions that contain this subplot
#'       matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
#'       
#'       print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
#'                                       layout.pos.col = matchidx$col))
#'     }
#'   }
#' }
#' 
#' multiplot(GovDec,GovNotes)
NULL