#' FH -  Freedom House - Freedom in the World (2013)
#' 
#' @description This dataset contains information on political rights and civil liberties. This dataset is a subset from Quality of Government. 
#' @format A balanced dataframe with 8651 rows and 5 variables.
#' It includes 195 countries for the time period 1972 - 2012.
#' \describe{
#' \item{cname}{Country name}
#' \item{year}{Year}
#' \item{fh_cl}{Civil Liberties. Civil liberties allow for the freedoms of expression and belief, associational and organizational rights, rule of law, and personal autonomy without interference from the state. The more specific list of rights considered vary over the years. Countries are graded between {\strong{1}} (most free) and {\strong{7}} (least free).}
#' \item{fh_pr}{Political Rights. Political rights enable people to participate freely in the political process, including the right to vote freely for distinct alternatives in legitimate elections, compete for public office, join political parties and organizations, and elect representatives who have a decisive impact on public policies and are accountable to the electorate. The specific list of rights considered varies over the years. Countries are graded between {\strong{1}} (most free) and {\strong{7}} (least free).}
#' \item{fh_status}{Status: {\strong{1)}} Free; {\strong{2)}} Partly Free; and {\strong{3)}} Not free.}
#' }
#' 
#' @details Freedom House scores are coded by people hired as experts by Freedom House.
#' @name FH
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Freedom House (2013). “Freedom in the World”. 
#' @source Freedom House webpage \url{http://www.freedomhouse.org/}. 
#' @seealso PolityIV PolityIVcoups ACImpev DD 
#' @keywords dataset regime 
#' @examples
#' #This example shows the distribution of Free, Partly Free and Not Free regimes
#' #between 1972 - 2012
#' data(FH)
#' 
#' length <- aggregate(FH$fh_status,
#'                     by=list(FH$year),
#'                     length)
#' 
#' 
#' sum1 <- aggregate(FH$fh_status[which(FH$fh_status==1)],
#'                   by=list(FH$year[which(FH$fh_status==1)]),
#'                   length)
#' colnames(sum1) <- c("Group.1","sum1")
#' 
#' sum2 <- aggregate(FH$fh_status[which(FH$fh_status==2)],
#'                   by=list(FH$year[which(FH$fh_status==2)]),
#'                   length)
#' colnames(sum2) <- c("Group.1","sum2")
#' 
#' sum3 <- aggregate(FH$fh_status[which(FH$fh_status==3)],
#'                   by=list(FH$year[which(FH$fh_status==3)]),
#'                   length)
#' colnames(sum3) <- c("Group.1","sum3")
#' 
#' FreeWorld <- merge(length,sum1,by="Group.1")
#' FreeWorld <- merge(FreeWorld,sum2,by="Group.1")
#' FreeWorld <- merge(FreeWorld,sum3,by="Group.1")
#' 
#' FreeWorld$share1 <- FreeWorld$sum1/FreeWorld$x
#' FreeWorld$share2 <- FreeWorld$sum2/FreeWorld$x
#' FreeWorld$zero <- 0
#' FreeWorld$one <- 1
#' 
#' plot(FreeWorld$Group.1,FreeWorld$x,ylim=c(0,1),type="l",
#'      xlab="Year",ylab="Share of total")
#' lines(FreeWorld$Group.1,FreeWorld$share1)
#' polygon(c(min(FreeWorld$Group.1),FreeWorld$Group.1,max(FreeWorld$Group.1)),
#'         c(min(FreeWorld$zero),FreeWorld$share1,min(FreeWorld$zero)),
#'         col="green",border=FALSE)
#' lines(FreeWorld$Group.1,FreeWorld$share1+FreeWorld$share2)
#' polygon(c(FreeWorld$Group.1,rev(FreeWorld$Group.1)),
#'         c(FreeWorld$share1+FreeWorld$share2,
#'           rev(FreeWorld$share1)),
#'         col="red")
#' polygon(c(min(FreeWorld$Group.1),FreeWorld$Group.1,
#'           max(FreeWorld$Group.1)),
#'         c(min(FreeWorld$one),
#'           FreeWorld$share1+FreeWorld$share2,min(FreeWorld$one)),
#'         col="black",border=FALSE)
#' text(1981,0.8,"The Not Free World",col="white",lwd=10,cex=1.2)
#' text(1982,0.35,"The Partly Free World",col="white",srt=10,lwd=10,cex=1.2)
#' text(1981,0.1,"The Free World",col="white",lwd=10,cex=1.2)
#' 
NULL