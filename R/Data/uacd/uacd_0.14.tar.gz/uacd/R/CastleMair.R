#' CastlesMair - party position data from Castles/Mair (1983)
#' 
#' @description This dataset contains party position data from Castles/Mair (1983),
#' with information of 46 parties from 17 countries.
#' This dataset is a copy of external_party_castles_mair.csv from ParlGov.
#' @format A  cross-sectional dataframe with 119 rows and 9 variables. 46 parties from 17 countries.
#' \describe{
#' 
#' \item{id}{Party id from Castles/Mair}
#' \item{country}{Country name abbreviation}
#' \item{name}{Party name (Could contain some encoding issues with special characters)}
#' \item{name_english}{Party name in english}
#' \item{name_short}{Party name abbreviation}
#' \item{range_left}{Lower bound of left-right position}
#' \item{range_right}{Upper bound of left-right position}
#' \item{left_right}{Mean left-right position}
#' \item{respondents}{Number of respondents}
#' 
#'  } 
#' @name CastlesMair
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Castles, Francis G. and Peter Mair. 1984. “Left-right political scales: Some ‘expert’ judgements.” European Journal of Political Research 12(1):73–88.
#' Castles/Mair at ParlGov online: \url{http://www.parlgov.org/stable/documentation/table/external_party_castles_mair.html}
#' @keywords dataset party position
#' @examples
#' data(HuberInglehart)
#' data(CastlesMair)
#' data(Party)
#' 
#' ####Give colname .CM and .HI endings, so where they come from can be identified
#' names(CastlesMair) <- sub("$",".CM",names(CastlesMair))
#' names(HuberInglehart) <- sub("$",".HI",names(HuberInglehart))
#' 
#' #Merge
#' HICM <- merge(Party,CastlesMair,
#'               by.x='castles_mair', by.y='id.CM', all=TRUE)
#' HICM <- merge(HICM,HuberInglehart,
#'               by.x='huber_inglehart', by.y='id.HI', all=TRUE)
#' 
#' #Get an idea of correlation between left_right in the
#' #different datasets.
#' library(corrgram)
#' corrgram(HICM[,c("left_right.CM","left_right.HI")],
#'          upper.panel=panel.pie,lower.panel=panel.pts)
#' 
#' #Center variables, so they can be used in OLS.
#' HICM$lr.HI <- scale(HICM$left_right.HI, center=TRUE, scale=FALSE)
#' HICM$lr.CM <- scale(HICM$left_right.CM, center=TRUE, scale=FALSE)
NULL