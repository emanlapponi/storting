#' WDIeduc - The World Bank's World Development Indicators - Education
#' 
#' @description This dataset contains the World Bank's World Development Indicators (WDIs) on education (including 
#' literacy rates, school enrollment, goverment expenditure, labor force and unemployment variables). 
#' It covers 213 countries for the time period 1960 - 2012. In addition aggregate measures for the world, 
#' all world regions and high income and low income countries are available. 
#' For additional information see \url{http://data.worldbank.org/topic/education}.
#' @format A dataframe with 13038 rows and 109 variables.
#' It covers 246 areas (countries and regions) between 1960 - 2012.
#' \describe{
#' 
#' \item{country}{Country name}
#' \item{country.code}{Three letter country code.}
#' \item{year}{Year. }
#' \item{female_literacy_youth}{Literacy rate, youth female (\% of females ages 15-24). Indicator code: SE.ADT.1524.LT.FE.ZS}
#' \item{male_literacy_youth}{Literacy rate, youth male (\% of people ages 15-24). Indicator code: SE.ADT.1524.LT.MA.ZS}
#' \item{literacy_youth}{Literacy rate, youth total (\% of people ages 15-24) . Indicator code: SE.ADT.1524.LT.ZS}
#' \item{female_literacy_adult}{Literacy rate, adult female (\% of females ages 15 and above). Indicator code: SE.ADT.LITR.FE.ZS }
#' \item{male_literacy_adult}{Literacy rate, adult male (\% of males ages 15 and above). Indicator code: SE.ADT.LITR.MA.ZS}
#' \item{literacy_adult}{Literacy rate, adult total (\% of people ages 15 and above). Indicator code: SE.ADT.LITR.ZS }
#' \item{primary_enrollment_female_ratio}{Ratio of female to male primary enrollment (\%). Indicator code SE.ENR.PRIM.FM.ZS}
#' \item{secondary_enrollment_girls_ratio}{Ratio of girls to boys in primary and secondary education (\%). Indicator code: SE.ENR.PRSC.FM.ZS }
#' \item{secondary_enrollment_female_ratio}{Ratio of female to male secondary enrollment (\%). Indicator code: SE.ENR.SECO.FM.ZS }
#' \item{tertiary_enrollment_female_ratio}{Ratio of female to male tertiary enrollment (\%). Indicator code: SE.ENR.TERT.FM.ZS }
#' \item{preprimary_enrollment}{School enrollment, preprimary (\% gross). Indicator code: SE.PRE.ENRR}
#' \item{female_preprimary_enrollment}{School enrollment, preprimary, female (\% gross). Indicator code: SE.PRE.ENRR.FE }
#' \item{male_preprimary_enrollment}{School enrollment, preprimary, male (\% gross). Indicator code: SE.PRE.ENRR.MA }
#' \item{primary_starting_age}{Primary school starting age (years). Indicator code: SE.PRM.AGES}
#' \item{primary_completion_female}{Primary completion rate, female (\% of relevant age group). Indicator code: SE.PRM.CMPT.FE.ZS}
#' \item{primary_completion_male}{Primary completion rate, male (\% of relevant age group). Indicator code: SE.PRM.CMPT.MA.ZS }
#' \item{primary_completion}{Primary completion rate, total (\% of relevant age group). Indicator code: SE.PRM.CMPT.ZS}
#' \item{primary_duration}{Primary education, duration (years). Indicator code: SE.PRM.DURS}
#' \item{primary_pupils}{Primary education, pupils. Indicator code: SE.PRM.ENRL}
#' \item{primary_female_pupils}{Primary education, pupils (\% female). Indicator code: SE.PRM.ENRL.FE.ZS }
#' \item{primary_teacher_ratio}{Pupil-teacher ratio, primary. Indicator code: SE.PRM.ENRL.TC.ZS}
#' \item{primary_gross_enrollment}{School enrollment, primary (\% gross).
#' Total is the total enrollment in primary education, regardless of age, expressed as a percentage of the population of official primary education age. GER can exceed 100% due to the inclusion of over-aged and under-aged students because of early or late school entrance and grade repetition.
#' Indicator code: SE.PRM.ENRR}
#' \item{primary_gross_female_enrollment}{School enrollment, primary, female (\% gross).
#' Female is the total female enrollment in primary education, regardless of age, expressed as a percentage of the female population of official primary education age. GER can exceed 100% due to the inclusion of over-aged and under-aged students because of early or late school entrance and grade repetition.
#' Indicator code: SE.PRM.ENRR.FE }
#' \item{primary_gross_male_enrollment}{School enrollment, primary, male (\% gross).
#' Male is the total male enrollment in primary education, regardless of age, expressed as a percentage of the male population of official primary education age. GER can exceed 100% due to the inclusion of over-aged and under-aged students because of early or late school entrance and grade repetition.
#' Indicator code: SE.PRM.ENRR.MA }
#' \item{primary_female_entrants}{Gross intake ratio in first grade of primary education, female (\% of relevant age group).
#' Gross intake ratio in first grade of primary education is the number of new entrants in the first grade of primary education regardless of age, expressed as a percentage of the population of the official primary entrance age.
#' Indicator code: SE.PRM.GINT.FE.ZS}
#' \item{primary_male_entrants}{Gross intake ratio in first grade of primary education, male (\% of relevant age group).
#' Gross intake ratio in first grade of primary education is the number of new entrants in the first grade of primary education regardless of age, expressed as a percentage of the population of the official primary entrance age. 
#' Indicator code: SE.PRM.GINT.MA.ZS}
#' \item{primary_entrants}{Gross intake ratio in first grade of primary education, total (\% of relevant age group).
#' Gross intake ratio in first grade of primary education is the number of new entrants in the first grade of primary education regardless of age, expressed as a percentage of the population of the official primary entrance age.
#' Indicator code: SE.PRM.GINT.ZS}
#' \item{primary_net_enrollment}{School enrollment, primary (\% net).
#'  Total is the ratio of children of the official primary school age who are enrolled in primary school to the total population of the official primary school age.
#'  Indicator code: SE.PRM.NENR}
#' \item{primary_net_female_enrollment}{School enrollment, primary, female (\% net).
#' Female is the ratio of female children of the official primary school age who are enrolled in primary school to the female population of the official primary school age.
#' Indicator code: SE.PRM.NENR.FE}
#' \item{primary_net_male_enrollment}{School enrollment, primary, male (\% net).
#' Male is the ratio of male children of the official primary school age who are enrolled in primary school to the male population of the official primary school age.
#' Indicator code: SE.PRM.NENR.MA}
#' \item{firstgrade_female_entrant}{Net intake rate in grade 1, female (\% of official school-age population).
#'  Female is the number of new female entrants in the first grade of primary education who are of the official primary school-entrance age, expressed as a percentage of the female population of the same age.
#'  Indicator code: SE.PRM.NINT.FE.ZS}
#' \item{firstgrade_male_entrant}{Net intake rate in grade 1, male (\% of official school-age population).
#' Male is the number of new male entrants in the first grade of primary education who are of the official primary school-entrance age, expressed as a percentage of the male population of the same age.
#' Indicator code: SE.PRM.NINT.MA.ZS}
#' \item{firstgrade_entrant}{Net intake rate in grade 1 (\% of official school-age population).
#' Total is the number of new entrants in the first grade of primary education who are of the official primary school-entrance age, expressed as a percentage of the population of the same age.
#' Indicator code: SE.PRM.NINT.ZS}
#' \item{primary_enrollment_private}{School enrollment, primary, private (\% of total primary). Indicator code: SE.PRM.PRIV.ZS}
#' \item{fifthgrade_persistence_female}{Persistence to grade 5, female (\% of cohort). Indicator code: SE.PRM.PRS5.FE.ZS}
#' \item{fifthgrade_persistence_male}{Persistence to grade 5, male (\% of cohort). Indicator code: SE.PRM.PRS5.MA.ZS }
#' \item{fifthgrade_persistence}{Persistence to grade 5, total (\% of cohort). Indicator code: SE.PRM.PRS5.ZS}
#' \item{lastgrade_persistence_female}{Persistence to last grade of primary, female (\% of cohort). Indicator code: SE.PRM.PRSL.FE.ZS}
#' \item{lastgrade_persistence_male}{Persistence to last grade of primary, male (\% of cohort). Indicator code: SE.PRM.PRSL.MA.ZS}
#' \item{lastgrade_persistence}{Persistence to last grade of primary, total (\% of cohort). Indicator code: SE.PRM.PRSL.ZS}
#' \item{primary_repeaters_female}{Repeaters, primary, female (\% of female enrollment). Indicator code: SE.PRM.REPT.FE.ZS}
#' \item{primary_repeaters_male}{Repeaters, primary, male (\% of male enrollment). Indicator code: SE.PRM.REPT.MA.ZS}
#' \item{primary_repeaters}{Repeaters, primary, total (\% of total enrollment). Indicator code: SE.PRM.REPT.ZS}
#' \item{primary_trained_female_teachers}{Trained teachers in primary education, female (\% of female teachers). Indicator code: SE.PRM.TCAQ.FE.ZS }
#' \item{primary_trained_male_teachers}{Trained teachers in primary education, male (\% of male teachers). Indicator code: SE.PRM.TCAQ.MA.ZS}
#' \item{primary_trained_teachers}{Trained teachers in primary education (\% of total teachers). Indicator code: SE.PRM.TCAQ.ZS}
#' \item{primary_teachers}{Primary education, teachers. Indicator code: SE.PRM.TCHR}
#' \item{primary_female_teachers}{Primary education, teachers (\% female). Indicator code: SE.PRM.TCHR.FE.ZS}
#' \item{primary_adjusted_enrollment}{Adjusted net enrollment rate, primary (\% of primary school age children).
#' Total is the number of new entrants in the first grade of primary education who are of the official primary school-entrance age, expressed as a percentage of the population of the same age.
#' Indicator code: SE.PRM.TENR}
#' \item{primary_adjusted_female_enrollment}{Adjusted net enrollment rate, primary, female (\% of primary school age children).
#' Adjusted net enrollment is the number of pupils of the school-age group for primary education, enrolled either in primary or secondary education, expressed as a percentage of the total population in that age group.
#' Indicator code: SE.PRM.TENR.FE}
#' \item{primary_adjusted_male_enrollment}{Adjusted net enrollment rate, primary, male (\% of primary school age children).
#' Adjusted net enrollment is the number of pupils of the school-age group for primary education, enrolled either in primary or secondary education, expressed as a percentage of the total population in that age group.
#' Indicator code: SE.PRM.TENR.MA }
#' \item{out_of_school}{Children out of school, primary.
#' Out-of-school children of primary school age. Total is the total number of primary-school-age children who are not enrolled in either primary or secondary schools.
#' Indicator code:SE.PRM.UNER}
#' \item{out_of_school_female}{Children out of school, primary, female.
#'  Female is the total number of female primary-school-age children who are not enrolled in either primary or secondary schools.
#'  Indicator code: SE.PRM.UNER.FE}
#' \item{out_of_school_male}{Children out of school, primary, male.
#' Male is the total number of male primary-school-age children who are not enrolled in either primary or secondary schools.
#' Indicator code: SE.PRM.UNER.MA}
#' \item{secondary_starting_age}{Secondary school starting age (years). Indicator code: SE.SEC.AGES}
#' \item{secondary_duration}{Secondary education, duration (years). Indicator code: SE.SEC.DURS}
#' \item{secondary_pupils}{Secondary education, pupils.
#'  Public and private. All programmes. Total is the total number of students enrolled at public and private secondary education institutions.
#'  Indicator code: SE.SEC.ENRL}
#' \item{secondary_female_pupils}{Secondary education, pupils (\% female). Indicator code: SE.SEC.ENRL.FE.ZS}
#' \item{secondary_general_pupils}{Secondary education, general pupils.
#' Enrollment in total secondary. Public and private. General programmes. Total is the total number of students enrolled in general programmes at public and private secondary education institutions.
#' Indicator code: SE.SEC.ENRL.GC}
#' \item{secondary_general_female_pupils}{Secondary education, general pupils (\% female).
#'  Percentage of female students. Total secondary. General programmes is the number of female students enrolled in general programmes at the secondary education level expressed as a percentage of the total number of students (male and female) enrolled in general programmes at the secondary education level in a given school year.
#'  Indicator code: SE.SEC.ENRL.GC.FE.ZS}
#' \item{secondary_teacher_ratio}{Pupil-teacher ratio, secondary. Indicator code: SE.SEC.ENRL.TC.ZS}
#' \item{secondary_vocational}{Secondary education, vocational pupils.
#' Enrollment in total secondary. Public and private. Technical/vocational programmes. Total is the total number of students enrolled in technical/vocational programmes at public and private secondary education institutions.Indicator code: SE.SEC.ENRL.VO}
#' \item{secondary_female_vocational}{Secondary education, vocational pupils (\% female). Indicator code: SE.SEC.ENRL.VO.FE.ZS}
#' \item{secondary_gross_enrollment}{School enrollment, secondary (\% gross). Indicator code: SE.SEC.ENRR}
#' \item{secondary_gross_female_enrollment}{School enrollment, secondary, female (\% gross). Indicator code: SE.SEC.ENRR.FE }
#' \item{secondary_gross_male_enrollment}{School enrollment, secondary, male (\% gross). Indicator code: SE.SEC.ENRR.MA}
#' \item{secondary_net_enrollment}{School enrollment, secondary (\% net). Indicator code: SE.SEC.NENR}
#' \item{secondary_net_female_enrollment}{School enrollment, secondary, female (\% net). Indicator code: SE.SEC.NENR.FE}
#' \item{secondary_net_male_enrollment}{School enrollment, secondary, male (\% net). Indicator code: SE.SEC.NENR.MA}
#' \item{secondary_private_enrollment}{School enrollment, secondary, private (\% of total secondary). Indicator code: SE.SEC.PRIV.ZS}
#' \item{secondary_progression_female}{Progression to secondary school, female (\%). Indicator code: SE.SEC.PROG.FE.ZS}
#' \item{secondary_progression_male}{Progression to secondary school, male (\%). Indicator code: SE.SEC.PROG.MA.ZS}
#' \item{secondary_progression}{Progression to secondary school (\%). Indicator code: SE.SEC.PROG.ZS}
#' \item{secondary_female_repeaters}{Repeaters, secondary, female (\% of female enrollment). Indicator code: SE.SEC.REPT.FE.ZS }
#' \item{secondary_male_repeaters}{Repeaters, secondary, male (\% of male enrollment). Indicator code: SE.SEC.REPT.MA.ZS}
#' \item{secondary_repeaters}{Repeaters, secondary, total (\% of total enrollment). Indicator code: SE.SEC.REPT.ZS}
#' \item{secondary_teachers}{Secondary education, teachers. Indicator code: SE.SEC.TCHR}
#' \item{secondary_absolute_female_teachers}{Secondary education, teachers, female.
#' Teaching staff in total secondary. Public and private. Full and part-time. All programmes. Female is the total number of female teachers in public and private secondary education institutions (ISCED 2 and 3). Teachers are persons employed full time or part time in an official capacity to guide and direct the learning experience of pupils and students, irrespective of their qualifications or the delivery mechanism, i.e. face-to-face and/or at a distance. This definition excludes educational personnel who have no active teaching duties (e.g. headmasters, headmistresses or principals who do not teach) and persons who work occasionally or in a voluntary capacity in educational institutions.
#' Indicator code: SE.SEC.TCHR.FE }
#' \item{secondary_female_teachers}{Secondary education, teachers (\% female).
#' Percentage female teachers. Secondary is the number of female teachers at the secondary level expressed as a percentage of the total number of teachers (male and female) at the secondary level in a given school year. Teachers are persons employed full time or part time in an official capacity to guide and direct the learning experience of pupils and students, irrespective of their qualifications or the delivery mechanism, i.e. face-to-face and/or at a distance. This definition excludes educational personnel who have no active teaching duties (e.g. headmasters, headmistresses or principals who do not teach) and persons who work occasionally or in a voluntary capacity in educational institutions.
#' Indicator code: SE.SEC.TCHR.FE.ZS}
#' \item{tertiary_gross_enrollment}{School enrollment, tertiary (\% gross). Indiactor code: SE.TER.ENRR }
#' \item{tertiary_gross_female_enrollment}{School enrollment, tertiary, female (\% gross). Indicator code: SE.TER.ENRR.FE}
#' \item{tertiary_gross_male_enrollment}{School enrollment, tertiary, male (\% gross). Indicator code: SE.TER.ENRR.MA}
#' \item{tertiary_female_teachers}{Tertiary education, teachers (\% female). Indicator code: SE.TER.TCHR.FE.ZS }
#' \item{primary_expenditure}{Expenditure per student, primary (\% of GDP per capita). Indicator code: SE.XPD.PRIM.PC.ZS}
#' \item{secondary_expenditure}{Expenditure per student, secondary (\% of GDP per capita). Indicator code: SE.XPD.SECO.PC.ZS}
#' \item{tertiary_expenditure}{Expenditure per student, tertiary (\% of GDP per capita) . Indicator code: SE.XPD.TERT.PC.ZS}
#' \item{public_education_spending_gov}{Public spending on education, total (\% of government expenditure). Indicator code: SE.XPD.TOTL.GB.ZS}
#' \item{public_education_spending_gdp}{Public spending on education, total (\% of GDP). Indicator code: SE.XPD.TOTL.GD.ZS }
#' \item{hiv}{Prevalence of HIV, total (\% of population ages 15-49). Indicator code: SH.DYN.AIDS.ZS}
#' \item{mortality_five}{Mortality rate, under-5 (per 1,000 live births). Indicator code: SH.DYN.MORT}
#' \item{female_primary_educated_labor}{Labor force with primary education, female (\% of female labor force). Indicator code: SL.TLF.PRIM.FE.ZS}
#' \item{male_primary_educated_labor}{Labor force with primary education, male (\% of male labor force). Indicator code: SL.TLF.PRIM.MA.ZS}
#' \item{primary_educated_labor}{Labor force with primary education (\% of total). Indicator code: SL.TLF.PRIM.ZS}
#' \item{female_secondary_educated_labor}{Labor force with secondary education, female (\% of female labor force). Indicator code: SL.TLF.SECO.FE.ZS}
#' \item{male_secondary_educated_labor}{Labor force with secondary education, male (\% of male labor force). Indicator code: SL.TLF.SECO.MA.ZS}
#' \item{secondary_educated_labor}{Labor force with secondary education (\% of total). Indicator code: SL.TLF.SECO.ZS}
#' \item{female_tertiary_educated_labor}{Labor force with tertiary education, female (\% of female labor force). Indicator code: SL.TLF.TERT.FE.ZS}
#' \item{male_tertiary_educated_labor}{Labor force with tertiary education, male (\% of male labor force). Indicator code: SL.TLF.TERT.MA.ZS}
#' \item{tertiary_educated_labor}{Labor force with tertiary education (\% of total). Indicator code: SL.TLF.TERT.ZS}
#' \item{female_labor}{Labor force, female (\% of total labor force). Indicator code: SL.TLF.TOTL.FE.ZS}
#' \item{labor_force}{Labor force, total. Indicator code: SL.TLF.TOTL.IN }
#' \item{female_unemployment}{Unemployment, female (\% of female labor force). Indicator code: SL.UEM.TOTL.FE.ZS}
#' \item{male_unemployment}{Unemployment, male (\% of male labor force). Indicator code: SL.UEM.TOTL.MA.ZS}
#' \item{unemployment}{Unemployment, total (\% of total labor force). Indicator code: SL.UEM.TOTL.ZS}
#' \item{population_youth}{Population ages 0-14 (\% of total). Indicator code: SP.POP.0014.TO.ZS}
#' \item{population_potential_active}{Population ages 15-64 (\% of total). Indicator code: SP.POP.1564.TO.ZS}
#' }
#' @name WDIeduc
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references The World Bank (2013). 
#' @keywords dataset education economy
#' @source Project homepage: \url{http://data.worldbank.org/topic/education}
#' @seealso WDIeduc 
#' @examples
#' #This example shows how to 1) subset only countries from the dataset
#' #(i.e remove world regions and other categories) and 2) 
#' #fetch and rename some interesting variables
#' #(in this case literacy rate for adults, pupil-teacher ratio in secondary
#' #school,
#' #expenditure per student on tertiary education and unemployment
#' #(as percent of the total labor force).
#' 
#' data(WDIeduc)
#' library(reshape)
#' 
#' countries <- as.character(unique(WDIeduc$country)[33:246])
#' WDIeducSub <- WDIeduc[WDIeduc$country %in% c(countries),]
#' WDIeducSub <- WDIeducSub[,c("country", "country.code", "year","literacy_adult",
#'                             "secondary_teacher_ratio", "tertiary_expenditure",
#'                             "unemployment")]
#' #This example uses a OLS differential model with PCSE to show that
#' #minority governments are more likely to reduce the number of people
#' #out of primary school
#' 
#' data(WDIeduc);data(ParlGov)
#' library(pcse)
#' 
#' Cabs <- ParlGov[which(ParlGov$DecemberandCensored>0 & ParlGov$NewCab==1
#'                       & ParlGov$year>=1960 & ParlGov$year <= 2011),]
#' Educ <- merge(Cabs,WDIeduc, by.x=c("country_name_short","year"),
#'               by.y=c("country.code","year"),all.x=TRUE)
#' 
#' #Create lag variables and differentials.
#' library(plm)
#' pEduc <- pdata.frame(Educ,c("country","year"))
#' pEduc$population_youth_lag <- lag(pEduc$population_youth,1)
#' pEduc$population_youth_change <- pEduc$population_youth - pEduc$population_youth_lag
#' 
#' pEduc$out_of_school_lag <- lag(pEduc$out_of_school,1)
#' pEduc$out_of_school_change <- pEduc$out_of_school - pEduc$out_of_school_lag
#' 
#' Educ <- data.frame(pEduc)
#' 
#' 
#' df<- na.omit(Educ[,c("country_name_short","out_of_school","out_of_school_lag",
#'                      "out_of_school_change","population_youth_change",
#'                      "caretaker","minority_seats","year")])
#' #There are too few observations in these countries now. They must be removed to use PCSE
#' df <- df[which(df$country_name_short!="AUT"),]
#' df <- df[which(df$country_name_short!="LVA"),]
#' 
#' 
#' #OLS differential model with PCSE
#' outofschool<-lm(out_of_school_change ~ population_youth_change + out_of_school_lag
#'                 + factor(minority_seats) + factor(caretaker) + factor(country_name_short)
#'                 ,data=df)
#' pcse <- pcse(outofschool,groupN=df$country_name_short,groupT=df$year,pairwise=TRUE)
#' pcse<- round(cbind(pcse$b,pcse$pcse,pcse$b/pcse$pcse),2)
#' colnames(pcse) <- c("Beta","PCSE","T-value")
NULL