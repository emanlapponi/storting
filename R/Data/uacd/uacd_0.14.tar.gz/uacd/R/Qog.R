#' Qog - Quality of Government dataset
#' 
#' @description The Quality of Government data is one of the most extensive datasets.
#' It covers both institutional features of a regime but also how the regime performs across different economic and social sectors.
#' @format A balanced dataframe with 14137 rows and 728 variables.
#' It covers 211 countries between 1946 - 2012.
#' @details This is a very extensive dataset with 728 variables. Their covarge differs in both space and time. An extensive overview of the variables is not yet available in the uacd-package. However, an extensive codebook can be found at the Quality of Government Institute's homepage: \url{http://www.qogdata.pol.gu.se/data/Codebook_QoG_Std15May13.pdf}
#' @name Qog
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Teorell, Jan, Nicholas Charron, Stefan Dahlberg, Sören Holmberg, Bo Rothstein, Petrus Sundin & Richard Svensson. 2013. The Quality of Government Dataset, version 30Apr13. University of Gothenburg: The Quality of Government Institute.
#' Qog online: \url{http://www.qog.pol.gu.se}
#' @keywords dataset election cabinet parliament economy policy regime
#' @examples
#' #This example shows how to merge ParlGov and Qog so that
#' #ParlGov's party-varying variables are noted for the prime ministers party.
#' data(ParlGov)
#' data(Qog)
#' library(countrycode)
#' ParlGov$ccodecow <- countrycode(ParlGov$country_name_short,"iso3c","cown")
#' ParlGov <- ParlGov[which(is.na(ParlGov$ccodecow)==FALSE),] #Remove DDR
#' 
#' PrimeM <- ParlGov[which(ParlGov$year >= 1946 & ParlGov$prime_minister==1 &
#'                           ParlGov$DecemberandCensored > 0),]
#' 
#' PQ <- merge(PrimeM,Qog,by=c("ccodecow","year"),all.x=TRUE)
#' 
NULL