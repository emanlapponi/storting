#' desaw - Democractic Electoral Systems Around the World 1946 - 2011
#' 
#' @description Democratic Electoral Systems Around the World 1946 - 2011.
#' @format A dataframe with 1630 rows and 39 variables.
#' It covers election years in 132 countries in the period 1946 - 2011.
#' \describe{
#' 
#' \item{elec_id}{This is an identification variable.
#' The variable begins with either an L or a P to indicate
#' whether the election is legislative or presidential.
#' The variable then includes a three letter abbreviation of the country’s name,
#' followed by the (first round) date (yyyy-mm-dd) of the election.}
#' \item{country}{Country name}
#' \item{date}{Date of first election round. Format: M/D/YYYY}
#' \item{year}{Year of the election.}
#' \item{aclp_code}{Not specified in the codebook. Probably the country id from the ACLP Political and Economic Database, Alvares et al. 1999.}
#' \item{ccode}{This is the country code classification used by the Correlates of War (COW) project (Singer and Small, 1994)}
#' \item{ccode2}{This is the country code classification used by Gleditsch and Ward (1999).}
#' \item{presidential}{Was it a presidential election, yes(1) or no(0)}
#' \item{legislative_type}{Indicates electoral system. \strong{1)} Majoritarian system, \strong{2)} Proportional system, \strong{3)} Mixed system.
#' 
#' 
#' A majoritarian electoral system is one in which the candidates or parties that receive the most votes win.
#' Majoritarian electoral systems include single-member district plurality, alternative vote, single nontransferable vote, block vote, party block vote, borda count, modified borda count, limited vote, and two-round systems.
#' 
#' 
#' A proportional electoral system is a quota system or divisor system employed in multi-member districts
#' (where the quota is less than 50 percent). Proportional electoral systems include list proportional representation systems and the single transferable vote.
#' 
#' 
#' A mixed electoral system is one in which voters elect representatives through two different systems, one majoritarian and one proportional.
#' An electoral system is classified as mixed in our data set only if more than 5 percent of the total legislature is elected by a different electoral formula (majoritarian or proportional) to that used to elect the other deputies.
#' Mixed electoral systems come in two varieties: independent and dependent.}
#' \item{elecrule}{More detailed categorization of electoral type. \strong{1)} Single-Member-District-Plurality (SMDP), \strong{2)} Two-Round System (TRS), \strong{3)} Alternative Vote (AV), \strong{4)} Borda Count (BC), \strong{5)} Block Vote (BV), \strong{6)} Party Block Vote (PBV), \strong{7)} Limited Vote (LV), \strong{8)} Single Nontransferable Vote (SNTV), \strong{9)} List Proportional Representation (List PR), \strong{10)} Single Transferable Vote (STV), \strong{11)} Mixed Dependent (or Mixed Member Proportional), \strong{12)} Mixed Independent (or Mixed Parallel)}
#' \item{tier1_formula}{Electoral formula in the first tier. \strong{1)} Single-Member-District-Plurality (SMDP), \strong{2)} Two Round Majority-Plurality, \strong{3)} Two Round Qualified Majority, \strong{4)} Two Round Majority Runoff, \strong{5)} Alternative Vote (AV), \strong{6)} Borda Count (BC), \strong{7)} Modified Borda Count (mBC), \strong{8)} Block Vote (BV), \strong{9)} Party Block Vote (PBV), \strong{10)} Limited Vote (LV), \strong{11)} Single Nontransferable Vote (SNTV), \strong{12)} Hare quota, \strong{13)} Hare quota with largest remainders, \strong{14)} Hare quota with highest average remainders, \strong{15)} Hagenbach-Bischoff quota, \strong{16)} Hagenbach-Bischoff quota with largest remainders, \strong{17)} Hagenbach-Bischoff quota with highest average remainders, \strong{18)} Droop quota, \strong{19)} Droop quota with largest remainders, \strong{20)} Droop quota with highest average remainders, \strong{21)} Imperiali quota, \strong{22)} Imperiali quota with largest remainders, \strong{23)} Imperiali quota with highest average remainders, \strong{24)} Reinforced Imperiali quota, \strong{25)} D’Hondt, \strong{26)} Sainte-Laguë, \strong{27)} Modified Sainte-Laguë, \strong{28)} Single Transferable Vote}
#' \item{tier2_formula}{Electoral formula in the second tier. \strong{1)} Single-Member-District-Plurality (SMDP), \strong{2)} Two Round Majority-Plurality, \strong{3)} Two Round Qualified Majority, \strong{4)} Two Round Majority Runoff, \strong{5)} Alternative Vote (AV), \strong{6)} Borda Count (BC), \strong{7)} Modified Borda Count (mBC), \strong{8)} Block Vote (BV), \strong{9)} Party Block Vote (PBV), \strong{10)} Limited Vote (LV), \strong{11)} Single Nontransferable Vote (SNTV), \strong{12)} Hare quota, \strong{13)} Hare quota with largest remainders, \strong{14)} Hare quota with highest average remainders, \strong{15)} Hagenbach-Bischoff quota, \strong{16)} Hagenbach-Bischoff quota with largest remainders, \strong{17)} Hagenbach-Bischoff quota with highest average remainders, \strong{18)} Droop quota, \strong{19)} Droop quota with largest remainders, \strong{20)} Droop quota with highest average remainders, \strong{21)} Imperiali quota, \strong{22)} Imperiali quota with largest remainders, \strong{23)} Imperiali quota with highest average remainders, \strong{24)} Reinforced Imperiali quota, \strong{25)} D’Hondt, \strong{26)} Sainte-Laguë, \strong{27)} Modified Sainte-Laguë, \strong{28)} Single Transferable Vote}
#' \item{tier3_formula}{Electoral formula in the third tier. \strong{1)} Single-Member-District-Plurality (SMDP), \strong{2)} Two Round Majority-Plurality, \strong{3)} Two Round Qualified Majority, \strong{4)} Two Round Majority Runoff, \strong{5)} Alternative Vote (AV), \strong{6)} Borda Count (BC), \strong{7)} Modified Borda Count (mBC), \strong{8)} Block Vote (BV), \strong{9)} Party Block Vote (PBV), \strong{10)} Limited Vote (LV), \strong{11)} Single Nontransferable Vote (SNTV), \strong{12)} Hare quota, \strong{13)}Hare quota with largest remainders, \strong{14)} Hare quota with highest average remainders, \strong{15)} Hagenbach-Bischoff quota, \strong{16)} Hagenbach-Bischoff quota with largest remainders, \strong{17)} Hagenbach-Bischoff quota with highest average remainders, \strong{18)} Droop quota, \strong{19)} Droop quota with largest remainders, \strong{20)} Droop quota with highest average remainders, \strong{21)} Imperiali quota, \strong{22)} Imperiali quota with largest remainders, \strong{23)} Imperiali quota with highest average remainders, \strong{24)} Reinforced Imperiali quota, \strong{25)} D’Hondt, \strong{26)} Sainte-Laguë, \strong{27)} Modified Sainte-Laguë, \strong{28)} Single Transferable Vote}
#' \item{tier4_formula}{Electoral formula in the fourth tier. \strong{1)} Single-Member-District-Plurality (SMDP), \strong{2)} Two Round Majority-Plurality, \strong{3)} Two Round Qualified Majority, \strong{4)} Two Round Majority Runoff, \strong{5)} Alternative Vote (AV), \strong{6)} Borda Count (BC), \strong{7)} Modified Borda Count (mBC), \strong{8)} Block Vote (BV), \strong{9)} Party Block Vote (PBV), \strong{10)} Limited Vote (LV), \strong{11)} Single Nontransferable Vote (SNTV), \strong{12)} Hare quota, \strong{13)} Hare quota with largest remainders, \strong{14)} Hare quota with highest average remainders, \strong{15)} Hagenbach-Bischoff quota, \strong{16)} Hagenbach-Bischoff quota with largest remainders, \strong{17)} Hagenbach-Bischoff quota with highest average remainders, \strong{18)} Droop quota, \strong{19)} Droop quota with largest remainders, \strong{20)} Droop quota with highest average remainders, \strong{21)} Imperiali quota, \strong{22)}Imperiali quota with largest remainders, \strong{23)} Imperiali quota with highest average remainders, \strong{24)} Reinforced Imperiali quota, \strong{25)} D’Hondt,  \strong{26)} Sainte-Laguë, \strong{27)} Modified Sainte-Laguë, \strong{28)} Single Transferable Vote}
#' \item{mixed_type}{This is a categorical variable that indicates the precise type of mixed electoral system that is being used, following Massicotte and Blais, 1999. \strong{1)} Coexistence, \strong{2)} Superposition, \strong{3)} Fusion, \strong{4)} Correction, \strong{5)} Conditional}
#' \item{multi}{This is a dichotomous variable that indicates whether there is more than one electoral tier (1) or not (0).}
#' \item{multi_linked}{This is a dichotomous variable that indicates whether different electoral tiers are linked (1) or not (0). Electoral tiers are linked if the unused votes from one electoral tier are used to allocate seats in another electoral tier, or if the allocation of seats in one electoral tier is conditional on the seats received in a different electoral tier.}
#' \item{seats}{This indicates the total number of seats in the lower house of the national legislature.}
#' \item{tier1_avemag}{This is the average district magnitude in the first electoral tier. This is calculated as the total number of seats allocated in the first electoral tier divided by the total number of districts in that tier.}
#' \item{tier1_districts}{This is the number of electoral districts or constituencies in the first electoral tier.}
#' \item{upperseats}{This indicates the number of legislative seats allocated in electoral districts above the lowest electoral tier.}
#' \item{uppertier}{This indicates the percentage of all legislative seats allocated in electoral districts above the lowest electoral tier.}
#' \item{tier2_districts}{This is the number of electoral districts or constituencies in the second electoral tier.}
#' \item{tier3_districts}{This is the number of electoral districts or constituencies in the third electoral tier.}
#' \item{tier4_districts}{This is the number of electoral districts or constituencies in the fourth electoral tier.}
#' \item{enep}{This is the effective number of electoral parties, following Laakso and Taagepera, 1979.
#' 
#' \eqn{\frac{1}{\Sigma v^{2}_{i}}}{%
#' 1/\Sigma v^2_i}
#' 
#' where v is the percentage of the votes received by the ith party (Laakso and Taagepera, 1979). Independents or ‘others’ are treated as a single party.}
#' \item{enep_others}{This is the percentage of the vote going to parties that are collectively known as ‘others’ in official election results.}
#' \item{enep1}{This is the effective number of electoral parties once the ‘other’ category has been “corrected” by using the least component method of bounds suggested by Taagepera (1997).}
#' \item{enpp}{This is the effective number of parliamentary (legislative) parties, following Laakso and Taagepera, 1979.
#' 
#' \eqn{\frac{1}{\Sigma s^{2}_{i}}}{%
#' 1/\Sigma s^2_i}
#' 
#' where s is the percentage of legislative seats won by the ith party. Independents or ‘others’ are treated as a single party.}
#' \item{enpp_others}{This is the percentage of seats won by parties that are collectively known as ‘others’ in official election results.}
#' \item{enpp1}{This is the effective number of parliamentary (legislative) parties once the ‘other’ category has been “corrected” by using the least component method of bounds suggested by Taagepera (1997).
#' 
#' It is calculated through these steps:
#' 1: Calculate enep by omitting the ‘others’ category (enep_omit)
#' 2: Take the minimum of the product of (i) the smallest party and the ‘other’ category or (ii) the squared ‘other’ category
#' 3: Recalculate enep using the minimum found in Step 2. (enep_min)
#' 4: Finally, take the mean of enep_omit and enep_min}
#' \item{enpres}{This is the effective number of presidential candidates, following Laakso and Taagepera, 1979.
#' 
#' \eqn{\frac{1}{\Sigma v^{2}_{i}}}{%
#' 1/\Sigma v^2_i}
#' 
#' where v is the percentage of the votes received by the ith candidate (in the first round). ‘Others’ are treated as a single candidate.}
#' \item{preselecrule}{This is a categorical variable that indicates the electoral formula used in the presidential election. \strong{1)} Plurality, \strong{2)} Absolute Majority, \strong{3)} Qualified Majority, \strong{4)} Electoral College, \strong{5)} Alternative Vote}
#' \item{region1}{Region, categorization alternative 1 (Przeworski et al., 2000).: \strong{1)} Sub-Saharan Africa, \strong{2)} South Asia, \strong{3)} East Asia, \strong{4)} South East Asia, \strong{5)} Pacific Islands/Oceania, \strong{6)} Middle East/North Africa, \strong{7)} Latin America, \strong{8)} Caribbean and non-Iberic America, \strong{9)} Eastern Europe/post-Soviet states, \strong{10)} Industrialized Countries (OECD), \strong{11)} Oil Countries}
#' \item{region2}{Region, categorization alternative 2: \strong{1)} Sub-Saharan Africa, \strong{2)} South Asia, \strong{3)} East Asia, \strong{4)} South East Asia, \strong{5)} Pacific Islands/Oceania, \strong{6)} Middle East/North Africa, \strong{7)} Latin America, \strong{8)} Caribbean and non-Iberic America, \strong{9)} Eastern Europe/post-Soviet states, \strong{10)} Western Europe}
#' \item{region3}{Region, categorization alternative 3: \strong{1)} Sub-Saharan Africa, \strong{2)} Asia, \strong{3)} West (incl = US, Canada, Australia, New Zealand), \strong{4)} Eastern Europe/post-Soviet states, \strong{5)} Pacific Islands/Oceania, \strong{6)} Middle East/North Africa, \strong{7)} Latin America/Caribbean}
#' \item{regime}{This is a categorical variable indicating a country’s regime type at the end of the given year. The data for this variable come from Cheibub, Gandhi and Vreeland (2010), which DESAW updated through 2011. \strong{0)} Parliamentary democracy, \strong{1)} Semi-presidential democracy, \strong{2)} Presidential democracy, \strong{3)} Civilian dictatorship, \strong{4)} Military dictatorship, \strong{5)} Royal dictatorship.
#' 
#' A democracy is a regime in which (i) the chief executive is elected, (ii) the legislature is elected, (iii) there is more than one party competing in elections, and (iv) an alternation under identical electoral rules has taken place (Przeworski et al., 2000; Cheibub, Gandhi and Vreeland, 2010).
#' 
#' There are three subtypes of democracies: parliamentary, semi-presidential, and presidential. A parliamentary democracy is one in which the government depends on a legislative majority to exist and the head of state is not popularly elected for a fixed term (Cheibub, Gandhi and Vreeland, 2010). A semi-presidential democracy is one in which the government depends on a legislative majority to exist and the head of state is popularly elected for a fixed term (Cheibub, Gandhi and Vreeland, 2010). A presidential democracy is one in which the government does not depend on a legislative majority to exist (Cheibub, Gandhi and Vreeland, 2010).
#' 
#' A dictatorship is a regime in which one or more the following conditions do not hold: (i) the chief executive is elected, (ii) the legislature is elected, (iii) there is more than one party competing in elections, and (iv) an alternation under identical electoral rules has taken place (Przeworski et al., 2000; Cheibub, Gandhi and Vreeland, 2010).
#' 
#' There are three types of dictatorship: civilian, military, and royal. A civilian dictatorship is a residual category in that dictatorships that are not royal or military are considered civilian (Cheibub, Gandhi and Vreeland, 2010). A military dictatorship is one in which the executive relies on the armed forces to come to and stay in power Cheibub, Gandhi and Vreeland (2010). A royal dictatorship is one in which the executive relies on family and kin networks to come to and stay in power (Cheibub, Gandhi and Vreeland, 2010).
#' }
#' \item{secondround}{This is the precise date (mm/dd/yyyy) for the second round of an election. Missing if there were no second round.}
#' \item{thirdround}{This is the precise date (mm/dd/yyyy) for the third round of an election. Missing if there were no third round.}
#' }
#' @name desaw
#' @author Bjørn Høyland, Haakon Gjerløw og Aleksander Eilertsen
#' @references Nils-Christian Bormann & Matt Golder. 2013. "Democratic electoral Systems Around the World, 1946-2011."
#' \href{https://files.nyu.edu/mrg217/public/elections.html}{Project homepage}
#' @keywords dataset election parliament
#' @source \href{https://files.nyu.edu/mrg217/public/elections.html}{Project homepage}
#' @seealso GolderAfrica GolderExtremeRight GolderFiscalPolicyEU
#' @examples
#' # This example will draw the 2011 map on page 364 in Bormann & Golders (2013)
#' 
#' #"Democratic electoral Systems Around the World, 1946-2011."
#' data(desaw)
#' library(uacd)
#' library(rworldmap)
#' library(countrycode)
#' desaw <- desaw[order(desaw$country,desaw$year, decreasing=TRUE),]
#' desaw$iso3c <- countrycode(desaw$ccode, "cown", "iso3c")
#' desaw$iso3c[1:11] <- "DE"
#' desaw$lastyear <- 1
#' for(i in 2:nrow(desaw)){
#'   desaw$lastyear[i] <- ifelse(desaw$country[i]==desaw$country[i-1],0,1)  
#' }
#' map <- desaw[which(desaw$lastyear==1),]
#' 
#' 
#' legMap <- joinCountryData2Map(map, joinCode = "ISO3",
#'                               nameJoinColumn = "iso3c",
#'                               nameCountryColumn="country")
#' 
#' mapCountryData(legMap, nameColumnToPlot="legislative_type",
#'                catMethod = "categorical",
#'                colourPalette= c("gray20","lightgray","gray30"),
#'                missingCountryCol = "white",
#'                borderCol= "black",
#'                mapTitle = "Legislatives of the world",
#'                addLegend = FALSE)
#' legend(-190,-4,legend=c("Majoritarian","Mixed","Proportional","Autocracy"),
#'        col=c("gray20","lightgray","gray30","white"),
#'        fill=c("gray20","lightgray","gray30","white"))
#'   
#'             
#' #Several authors claim that PR systems serve the majority better than other
#' #democracies partly because the have larger electoral districts,
#' #making politicians answer to larger segments of society.
#' #If this is true, then we should observe that larger district magnitude is
#' #positive for GDP per capita growth, under the assumption that GDP per capita
#' #growth is a good valued by the majority.
#' 
#' data(desaw)
#' data(Maddison)
#' 
#' Maddison <- Maddison[which(Maddison$Year >= 1945 & Maddison$Year <= 2008),]
#' desaw <- desaw[which(desaw$year >= 1945 & desaw$year <= 2008),]
#' 
#' library(car)
#' Maddison$Country <- recode(Maddison$Country,"
#' 'Centr. Afr. Rep.'='Central African Republic';
#'                            'Comoro Islands'='Comoros';
#'                            'Czech Rep.'='Czech Republic';
#'                            'Dominican Rep.'='Dominican Republic';
#'                            'Burma'='Myanmar';
#'                            'UK'='United Kingdom';
#'                            'USA'='United States of America';
#'                            'N. Zealand'='New Zealand';
#'                            'S. Korea'='South Korea';
#'                            'T. & Tobago'='Trinidad and Tobago'")
#' 
#' 
#' #remove rows for presidential elections, to avoid duplicate rows.
#' desaw <- desaw[which(desaw$presidential!=1),]
#' desaw$election_year <- 1 #can be used as a elecetion year dummy later
#' desaw <- merge(desaw,Maddison,by.x=c("country","year"),by.y=c("Country","Year"),all=TRUE)
#' 
#' #Identify rows which have information from a preceding election
#' require(data.table)
#' library(zoo)
#' desaw <- data.table(desaw)
#' setkey(desaw,country, year)
#' desaw[,ccode:=na.locf(ccode,na.rm=FALSE),by=country]
#' 
#' #Any rows still NA on ccode are rows without any information from an election.
#' #Remove these to speed up the following functions.
#' desaw <- desaw[which(is.na(desaw$ccode)==FALSE),]
#' 
#' #Fill in missing entries with information from previous
#' #election for the variables used in the analysis
#' desaw[,':='(tier1_avemag=na.locf(tier1_avemag,na.rm=FALSE),
#'             region3=na.locf(region3,na.rm=FALSE),
#'             regime=na.locf(regime,na.rm=FALSE)),
#'       by=country]
#' desaw$election_year[which(is.na(desaw$election_year)==TRUE)] <- 0
#' 
#' #Create lag and difference -variables
#' desaw[,':='(GDPpc_lag=c(NA,GDPpc[-length(GDPpc)]),
#'             population_lag=c(NA,Population[-length(Population)]),
#'             election_lag=c(NA,election_year[-length(election_year)])),
#'       by=country]
#' 
#' desaw$growth <- desaw$GDPpc - desaw$GDPpc_lag
#' 
#' desaw$tier1_avemag[which(desaw$tier1_avemag==-99)] <- NA
#' 
#' 
#' #Control for an outlier
#' desaw$outlier <- ifelse(desaw$tier1_avemag==max(na.omit(desaw$tier1_avemag)),1,0)
#' 
#' #OLS: Large districts are good for economic growth.
#' #There are indications that the year after an election is bad
#' summary(lm(growth ~ log(population_lag) + log(GDPpc_lag)
#'            + log(tier1_avemag) + factor(election_year) + factor(outlier)
#'            + factor(election_lag) + factor(region3),
#'            data=desaw))
NULL