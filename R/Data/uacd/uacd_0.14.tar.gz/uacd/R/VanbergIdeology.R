#' VanbergIdeology - Replication data for "Wasting Time? The Impact of Ideology and Size on Delay in Coalition Formation"
#' 
#' @description Lanny W. Martin and Georg Vanbergs replication data for "Wasting Time? The Impact of Ideology and Size on Delay in Coalition Formation"
#' @format A data frame with 244 rows and 14 variables.
#' Each row is a unique government in one of the 9 countries between 1950 - 1993.
#' \describe{
#' 
#' \item{country}{Country. Austria (1953–90), Belgium (1950–87), Denmark (1950–93), Germany (1953–90), Ireland (1951–89), Italy (1953–92), Luxembourg (1951–89), the Netherlands (1956–89), Norway (1953–90) and Sweden (1952–91).}
#' \item{formopp}{Counter for the bargaining situation. No more information about this variable has been found, making it unclear what it means}
#' \item{bargdate}{Date coalition bargaining began: The day on which national legislative elections took place or (if no elections were held) the day on which the previous government resigned}
#' \item{formatio}{Date coalition bargaining ended: The day on which the government was formally announced}
#' \item{enddate}{Date the government ended}
#' \item{formdur}{Number of days between \code{bargdate} and \code{formatio}}
#' \item{postel}{Dummy indicating if a bargaining process started immediately after an election}
#' \item{prevdef}{Dummy indicating if the previous cabinet was defeated}
#' \item{cont}{Continuation rule: The variable continuation is coded as 1 for the countries Denmark, Norway and Sweden, where the incumbent cabinets may continue in office without having to resign even if elections are held. In the language of bargaining models continuation captures the fact that an incumbent government can always make the first proposal}
#' \item{ident}{The identifiability of viable coalition alternatives indicates the degree to which the voters, prior to the elections, are faced with clearly identified coalition alternatives. The corresponding variable, which was also introduced by Strøm, is constructed on a decade-by-decade basis and uses a three-point scale (0, 0.5, 1) to reflect expert judgements on the degree to which pre-electoral governmental options were present}
#' \item{rgovm}{Absolute left-right distance within the coalition. The distance between most extreme members. This derive from the party ideological positions provided in the manifestos project of the European Consortium for Political Research.}
#' \item{pgovno}{Number of parties in government}
#' \item{tpgovno}{\code{pgovno}*ln(\code{formdur})}
#' \item{minority}{Dummy for minority government}
#'  
#' }
#' @details A data set of bargaining durations in cabinet formation.
#' @name VanbergIdeology
#' @references Lanny Martin; Georg Vanberg, 2007,
#' "Replication data for: Wasting Time?
#' The Impact of Ideology and Size on Delay in Coalition Formation",
#' http://hdl.handle.net/1902.1/10396 UNF:3:yBQCpBpVg8yvvqzwVZ8www== Georg Vanberg [Distributor] V1 [Version]
#' 
#' Daniel Diermeier and Peter van Roozendaal, ‘The Duration of Cabinet Formation Processes in Western Multi-Party Democracies’, British Journal of Political Science, 28 (1998), 609–26.
#' @keywords dataset cabinet
#' @source Vanbergs dataverse: \url{http://dvn.iq.harvard.edu/dvn/dv/gvanberg/faces/study/StudyPage.xhtml?studyId=792&tab=files}
#' @seealso VanbergCoPol, VanbergPolBarg
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @examples
#' # Replicate model 3 in table 2 in the article:
#' data(VanbergIdeology)
#' library(survival);library(eha)
#' coxph(Surv(formdur) ~ cluster(country) + factor(postel) + factor(prevdef)
#'      + factor(cont) + ident + rgovm + pgovno + tpgovno + factor(minority),
#'     data=VanbergIdeology)
NULL