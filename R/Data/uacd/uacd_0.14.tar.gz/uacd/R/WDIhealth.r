#' WDIhealth - The World Bank's World Development Indicators - Health 
#' 
#' @description This dataset contains the World Banks World Development Indicators (WDIs) on health. It covers 213 countries 
#' for the time period 1960 - 2012. In addition aggregate measures for the world, all world regions and high income and low 
#' income countries are available. For additional information see \url{http://data.worldbank.org/topic/health}.
#' @format A dataframe with 13038 rows and 108 variables.
#' It covers 246 areas (countries and regions) between 1960 - 2012.
#' \describe{
#' 
#' \item{country}{Country name}
#' \item{country.code}{Three letter country code, iso format.}
#' \item{year}{Year. }
#' \item{female_condom_use}{Condom use, population ages 15-24, female (\% of females ages 15-24). Indicator code: SH.CON.1524.FE.ZS}
#' \item{male_condom_use}{Condom use, population ages 15-24, male (\% of males ages 15-24). Indicator code: SH.CON.1524.MA.ZS}
#' \item{infant_deaths}{Number of infant deaths. Indicator code: SH.DTH.IMRT}
#' \item{five_deaths}{Number of under-five deaths. Indicator code: SH.DTH.MORT}
#' \item{neonatal_deaths}{Number of neonatal deaths. Indicator code: SH.DTH.NMRT}
#' \item{women_hiv}{Women's share of population ages 15+ living with HIV (\%). Prevalence of HIV is the percentage of 
#' people who are infected with HIV. Female rate is as a percentage of the total population ages 15+ who are living with HIV. Indicator code: SH.DYN.AIDS.FE.ZS}
#' \item{hiv}{Prevalence of HIV, total (\% of population ages 15-49). 
#' Prevalence of HIV refers to the percentage of people ages 15-49 who are infected with HIV. Indicator code: SH.DYN.AIDS.ZS}
#' \item{female_child_mortality}{Mortality rate, female child (per 1,000 female children age one). Indicator code: SH.DYN.CHLD.FE }
#' \item{male_child_mortality}{Mortality rate, male child (per 1,000 male children age one). Indicator code: SH.DYN.CHLD.MA}
#' \item{mortality_five}{Mortality rate, under-5 (per 1,000 live births). Indicator code: SH.DYN.MORT }
#' \item{female_mortality_five}{Mortality rate, under-5, female (per 1,000 live births). Indicator code: SH.DYN.MORT.FE}
#' \item{male_mortality_five}{Mortality rate, under-5, male (per 1,000 live births). Indicator code: SH.DYN.MORT.MA}
#' \item{netonatal_mortality}{Mortality rate, neonatal (per 1,000 live births). Indicator code: SH.DYN.NMRT}
#' \item{child_hiv}{Children (0-14) living with HIV. Children living with HIV refers to the number of children 
#' ages 0-14 who are infected with HIV. Indicator code: SH.HIV.0014}
#' \item{female_youth_hiv}{Prevalence of HIV, female (\% ages 15-24). 
#' Prevalence of HIV is the percentage of people who are infected with HIV. 
#' Youth rates are as a percentage of the relevant age group.Indicator code: SH.HIV.1524.FE.ZS}
#' \item{male_youth_hiv}{Prevalence of HIV, male (\% ages 15-24). 
#' Prevalence of HIV is the percentage of people who are infected with HIV. 
#' Youth rates are as a percentage of the relevant age group. Indicator code: SH.HIV.1524.MA.ZS}
#' \item{antiretroviral_coverage}{Antiretroviral therapy coverage (\% of people with advanced HIV infection). Indicator code: SH.HIV.ARTC.ZS}
#' \item{child_dpt_immunization}{Immunization, DPT (\% of children ages 12-23 months). 
#' Child immunization measures the percentage of children ages 12-23 months who received vaccinations 
#' before 12 months or at any time before the survey. A child is considered adequately immunized against 
#' diphtheria, pertussis (or whooping cough), and tetanus (DPT) after receiving three doses of vaccine. Indicator code: SH.IMM.IDPT}
#' \item{child_measles_immunization}{Immunization, measles (\% of children ages 12-23 months). 
#' Child immunization measures the percentage of children ages 12-23 months who received vaccinations before 
#' 12 months or at any time before the survey. A child is considered adequately immunized against measles after 
#' receiving one dose of vaccine. Indicator code: SH.IMM.MEAS}
#' \item{hospital_beds}{Hospital beds (per 1,000 people). Indicator code: SH.MED.BEDS.ZS}
#' \item{community_health_workers}{Community health workers (per 1,000 people). 
#' Community health workers include various types of community health aides, many with country-specific 
#' occupational titles such as community health officers, community health-education workers, family health workers,
#'  lady health visitors and health extension package workers. Indicator code: SH.MED.CMHW.P3}
#' \item{nurses_midwives}{Nurses and midwives (per 1,000 people). 
#' Nurses and midwives include professional nurses, professional midwives, auxiliary nurses, auxiliary midwives, 
#' enrolled nurses, enrolled midwives and other associated personnel, such as dental nurses and primary care nurses. Indicator code: SH.MED.NUMW.P3}
#' \item{physicians}{Physicians (per 1,000 people). Physicians include generalist and specialist medical practitioners. Indicator code: SH.MED.PHYS.ZS}
#' \item{malaria}{Notified cases of malaria (per 100,000 people). 
#' Malaria incidence is expressed as the number of new cases of malaria per 100,000 people each year. 
#' The number of cases reported is adjusted to take into account incompleteness in reporting systems, 
#' patients seeking treatment in the private sector, self-medicating or not seeking treatment at all, 
#' and potential over-diagnosis through the lack of laboratory confirmation of cases. Indicator code: SH.MLR.INCD}
#' \item{bed_nets}{Use of insecticide-treated bed nets (\% of under-5 population). Indicator code: SH.MLR.NETS.ZS}
#' \item{child_antimalarial}{Children with fever receiving antimalarial drugs (\% of children under age 5 with fever). Indicator code: SH.MLR.TRET.ZS}
#' \item{maternal_deaths}{Number of maternal deaths. Maternal mortality deaths is the number of women who die 
#' during pregnancy and childbirth. Indicator code: SH.MMR.DTHS}
#' \item{maternal_death_risk}{Lifetime risk of maternal death (1 in: rate varies by country). 
#' Life time risk of maternal death is the probability that a 15-year-old female will die eventually from a 
#' maternal cause assuming that current levels of fertility and mortality (including maternal mortality) do not 
#' change in the future, taking into account competing causes of death. Indicator code: SH.MMR.RISK}
#' \item{percent_maternal_death_risk}{Lifetime risk of maternal death (\%).
#' Life time risk of maternal death is the probability that a 15-year-old female will die eventually from a
#'  maternal cause assuming that current levels of fertility and mortality (including maternal mortality) do not 
#'  change in the future, taking into account competing causes of death. Indicator code: SH.MMR.RISK.ZS}
#' \item{anemia}{Prevalence of anemia among pregnant women (\%). Prevalence of anemia, pregnant women, 
#' is the percentage of pregnant women whose hemoglobin level is less than 110 grams per liter at sea level. Indicator code: SH.PRG.ANEM}
#' \item{female_smoking}{Smoking prevalence, females (\% of adults). 
#' Prevalence of smoking, female is the percentage of women ages 15 and over who smoke any form of tobacco, 
#' including cigarettes, cigars, and pipes, and excluding smokeless tobacco. Data include daily and non-daily smoking. Indicator code: SH.PRV.SMOK.FE}
#' \item{male_smoking}{Smoking prevalence, males (\% of adults). 
#' Prevalence of smoking, male is the percentage of men ages 15 and over who smoke any form of tobacco, 
#' including cigarettes, cigars, and pipes, and excluding smokeless tobacco. Data include daily and non-daily smoking. Indicator code: SH.PRV.SMOK.MA}
#' \item{improved_sanitation_facilities}{Improved sanitation facilities (\% of population with access). 
#' Access to improved sanitation facilities refers to the percentage of the population with at least adequate 
#' access to excreta disposal facilities that can effectively prevent human, animal, and insect contact with excreta. 
#' Improved facilities range from simple but protected pit latrines to flush toilets with a sewerage connection. 
#' To be effective, facilities must be correctly constructed and properly maintained. Indicator code: SH.STA.ACSN}
#' \item{rural_improved_sanitation_facilities}{Improved sanitation facilities, rural (\% of rural population with access). Indicator code: SH.STA.ACSN.RU}
#' \item{urban_improved_sanitation_facilities}{Improved sanitation facilities, urban (\% of urban population with access). Indicator code: SH.STA.ACSN.UR}
#' \item{prenatal_care}{Pregnant women receiving prenatal care (\%). Indicator code: SH.STA.ANVC.ZS}
#' \item{ari}{Acute Respiratory Infection (ARI) treatment (\% of children under 5 taken to a health provider). Indicator code: SH.STA.ARIC.ZS}
#' \item{breastfeeding}{Exclusive breastfeeding (\% of children under 6 months). Indicator code: SH.STA.BFED.ZS}
#' \item{skilled_births}{Births attended by skilled health staff (\% of total). Indicator code: SH.STA.BRTC.ZS}
#' \item{birthweight_babies}{Low-birthweight babies (\% of births). Indicator code: SH.STA.BRTW.ZS}
#' \item{female_malnutrition_weight}{Malnutrition prevalence, weight for age, female (\% of children under 5). Indicator code: SH.STA.MALN.FE.ZS}
#' \item{male_malnutrition_weight}{Malnutrition prevalence, weight for age, male (\% of children under 5). Indicator code: SH.STA.MALN.MA.ZS}
#' \item{malnutrition_weight}{Malnutrition prevalence, weight for age (\% of children under 5). Indicator code: SH.STA.MALN.ZS}
#' \item{maternal_mortality_modeled}{Maternal mortality ratio (modeled estimate, per 100,000 live births). Indicator code: SH.STA.MMRT }
#' \item{maternal_mortality_national}{Maternal mortality ratio (national estimate, per 100,000 live births). Indicator code: SH.STA.MMRT.NE}
#' \item{diarrhea}{Diarrhea treatment (\% of children under 5 receiving oral rehydration and continued feeding). Indicator code: SH.STA.ORCF.ZS }
#' \item{female_overweight}{Prevalence of overweight, female (\% of children under 5). Indicator code: SH.STA.OWGH.FE.ZS }
#' \item{male_overweight}{Prevalence of overweight, male (\% of children under 5). Indicator code: SH.STA.OWGH.MA.ZS }
#' \item{overweight}{Prevalence of overweight (\% of children under 5). 
#' Prevalence of overweight children is the percentage of children under age 5 whose weight for height is more 
#' than two standard deviations above the median for the international reference population of the corresponding 
#' age as established by the WHO's new child growth standards released in 2006. Indicator code: SH.STA.OWGH.ZS}
#' \item{female_malnutrition_height}{Malnutrition prevalence, height for age, female (\% of children under 5). Indicator code: SH.STA.STNT.FE.ZS }
#' \item{male_malnutrition_height}{Malnutrition prevalence, height for age, male (\% of children under 5). Indicator code: SH.STA.STNT.MA.ZS}
#' \item{malnutrition_height}{Malnutrition prevalence, height for age (\% of children under 5). 
#' Prevalence of child malnutrition is the percentage of children under age 5 whose height for age (stunting) is
#'  more than two standard deviations below the median for the international reference population ages 0-59 months. 
#'  For children up to two years old height is measured by recumbent length. For older children height is measured by
#'  stature while standing. The data are based on the WHO's new child growth standards released in 2006. Indicator code: SH.STA.STNT.ZS}
#' \item{female_wasting}{Prevalence of wasting, female (\% of children under 5).
#' Wasting prevalence is measured as people whose weight for height is more than two standard deviations below the median for the international reference population.
#' Indicator code: SH.STA.WAST.FE.ZS}
#' \item{male_wasting}{Prevalence of wasting, male (\% of children under 5).
#' Wasting prevalence is measured as people whose weight for height is more than two standard deviations below the median for the international reference population.
#' Indicator code: SH.STA.WAST.MA.ZS}
#' \item{wasting}{Prevalence of wasting (\% of children under 5). 
#'  Wasting prevalence is the proportion of children under five whose weight for height is more than
#' two standard deviations below the median for the international reference population ages 0-59.
#' Indicator code: SH.STA.WAST.ZS}
#' \item{tuberculosis_treatment}{Tuberculosis treatment success rate (\% of registered cases). 
#' Tuberculosis treatment success rate is the percentage of new, registered smear-positive (infectious) 
#' cases that were cured or in which a full course of treatment was completed. Indicator code: SH.TBS.CURE.ZS}
#' \item{tuberculosis_detection}{Tuberculosis case detection rate (\%, all forms). 
#' Tuberculosis case detection rate (all forms) is the percentage of newly notified tuberculosis cases 
#' (including relapses) to estimated incident cases (case detection, all forms). Indicator code: SH.TBS.DTEC.ZS}
#' \item{tuberculosis_incidence}{Incidence of tuberculosis (per 100,000 people). Incidence of tuberculosis is the 
#' estimated number of new pulmonary, smear positive, and extra-pulmonary tuberculosis cases. 
#' Incidence includes patients with HIV. Indicator code: SH.TBS.INCD}
#' \item{newborn_tetanus_immunization}{Newborns protected against tetanus (\%). 
#' Newborns protected against tetanus are the percentage of births by women of child-bearing age who are immunized against tetanus. Indicator code: SH.VAC.TTNS.ZS}
#' \item{outpatient_visits}{Outpatient visits per capita. Outpatient visits per capita are the number of 
#' visits to health care facilities per capita, including repeat visits. Indicator code: SH.VST.OUTP }
#' \item{external_health}{External resources for health (\% of total expenditure on health). Indicator code: SH.XPD.EXTR.ZS }
#' \item{pocket_health_expenditure_total}{Out-of-pocket health expenditure (\% of total expenditure on health). Indicator code: SH.XPD.OOPC.TO.ZS }
#' \item{pocket_health_expenditure_private}{Out-of-pocket health expenditure (\% of private expenditure on health). Indicator code: SH.XPD.OOPC.ZS}
#' \item{health_expenditure_us}{Health expenditure per capita (current US$). Indicator code: SH.XPD.PCAP}
#' \item{health_expenditure_ppp}{Health expenditure per capita, PPP (constant 2005 international $). Indicator code: SH.XPD.PCAP.PP.KD}
#' \item{gdp_private_health_expenditure}{Health expenditure, private (\% of GDP). Indicator code: SH.XPD.PRIV.ZS }
#' \item{public_health_expenditure_total}{Health expenditure, public (\% of total health expenditure). Indicator code: SH.XPD.PUBL}
#' \item{public_health_expenditure_government}{Health expenditure, public (\% of government expenditure). Indicator code: SH.XPD.PUBL.GX.ZS}
#' \item{gdp_public_health_expenditure}{Health expenditure, public (\% of GDP). Indicator code: SH.XPD.PUBL.ZS}
#' \item{gdp_total_health_expenditure}{Health expenditure, total (\% of GDP). Indicator code: SH.XPD.TOTL.ZS }
#' \item{undernourishment}{Prevalence of undernourishment (\% of population). Indicator code: SN.ITK.DEFC.ZS}
#' \item{food_deficit}{Depth of the food deficit (kilocalories per person per day).  
#' The depth of the food deficit indicates how many calories would be needed to lift the undernourished from their status, 
#' everything else being constant. The average intensity of food deprivation of the undernourished, estimated as the 
#' difference between the average dietary energy requirement and the average dietary energy consumption of the undernourished 
#' population (food-deprived), is multiplied by the number of undernourished to provide an estimate of the total food deficit 
#' in the country, which is then normalized by the total population. Indicator code: SN.ITK.DFCT}
#' \item{iodized_salt_consumption}{Consumption of iodized salt (\% of households). Consumption of iodized salt refers to the 
#' percentage of households that use edible salt fortified with iodine. Indicator code: SN.ITK.SALT.ZS}
#' \item{vitamin_a}{Vitamin A supplementation coverage rate (\% of children ages 6-59 months). 
#' Vitamin A supplementation refers to the percentage of children ages 6-59 months old who received at 
#' least two doses of vitamin A in the previous year. Indicator code: SN.ITK.VITA.ZS}
#' \item{adolescent_fertility}{Adolescent fertility rate (births per 1,000 women ages 15-19). 
#' Adolescent fertility rate is the number of births per 1,000 women ages 15-19. Indicator code: SP.ADO.TFRT}
#' \item{infant_death_reporting}{Completeness of infant death reporting (\% of reported infant deaths to estimated infant deaths).
#' Completeness of infant death reporting is the number of infant deaths reported by national statistics authorities to the 
#' United Nations Statistics Division's Demography Yearbook divided by the number of infant deaths estimated by the 
#' United Nations Population Division. Indicator code: SP.DTH.INFR.ZS}
#' \item{death_reporting}{Completeness of total death reporting (\% of reported total deaths to estimated total deaths).
#' Completeness of total death reporting is the number of total deaths reported by national statistics authorities to the 
#' United Nations Statistics Division's Demography Yearbook divided by the number of total deaths estimated by the 
#' United Nations Population Division. Indicator code: SP.DTH.REPT.ZS}
#' \item{female_adult_mortality}{Mortality rate, adult, female (per 1,000 female adults). 
#' Adult mortality rate is the probability of dying between the ages of 15 and 60--that is, 
#' the probability of a 15-year-old dying before reaching age 60, if subject to current age-specific 
#' mortality rates between those ages. Indicator code: SP.DYN.AMRT.FE}
#' \item{male_adult_mortality}{Mortality rate, adult, male (per 1,000 male adults). 
#' Adult mortality rate is the probability of dying between the ages of 15 and 60--that is, 
#' the probability of a 15-year-old dying before reaching age 60, if subject to current age-specific 
#' mortality rates between those ages. Indicator code: SP.DYN.AMRT.MA}
#' \item{birth_rate}{Birth rate, crude (per 1,000 people). 
#' Crude birth rate indicates the number of live births occurring during the year, 
#' per 1,000 population estimated at midyear. Subtracting the crude death rate from the crude birth rate 
#' provides the rate of natural increase, which is equal to the rate of population change in the absence of migration.
#' Indicator code: SP.DYN.CBRT.IN}
#' \item{death_rate}{Death rate, crude (per 1,000 people). 
#' Crude death rate indicates the number of deaths occurring during the year, per 1,000 population estimated at 
#' midyear. Subtracting the crude death rate from the crude birth rate provides the rate of natural increase, 
#' which is equal to the rate of population change in the absence of migration.
#' Indicator code: SP.DYN.CDRT.IN}
#' \item{contraceptive}{Contraceptive prevalence (\% of women ages 15-49). Indicator code: SP.DYN.CONU.ZS}
#' \item{infant_mortality}{Mortality rate, infant (per 1,000 live births). Indicator code: SP.DYN.IMRT.IN}
#' \item{female_life_expectancy}{Life expectancy at birth, female (years). Indicator code: SP.DYN.LE00.FE.IN}
#' \item{total_life_expectancy}{Life expectancy at birth, total (years).
#' Life expectancy at birth indicates the number of years a newborn infant would live if prevailing 
#' patterns of mortality at the time of its birth were to stay the same throughout its life. Indicator code: SP.DYN.LE00.IN}
#' \item{male_life_expectancy}{Life expectancy at birth, male (years). Indicator code: SP.DYN.LE00.MA.IN}
#' \item{total_fertility}{Fertility rate, total (births per woman).
#' Total fertility rate represents the number of children that would be born to a woman if she were to 
#' live to the end of her childbearing years and bear children in accordance with current age-specific fertility rates. Indicator code: SP.DYN.TFRT.IN }
#' \item{female_survival}{Survival to age 65, female (\% of cohort).
#' Survival to age 65 refers to the percentage of a cohort of newborn infants that would survive to age 65, 
#' if subject to current age specific mortality rates. Indicator code: SP.DYN.TO65.FE.ZS}
#' \item{male_survival}{Survival to age 65, male (\% of cohort).Survival to age 65 refers to the percentage of a
#' cohort of newborn infants that would survive to age 65, if subject to current age specific mortality rates. Indicator code: SP.DYN.TO65.MA.ZS}
#' \item{wanted_fertility}{Wanted fertility rate (births per woman).
#' Wanted fertility rate is an estimate of what the total fertility rate would be if all unwanted births were avoided.
#' Indicator code: SP.DYN.WFRT}
#' \item{female_households}{Female headed households (\% of households with a female head). Indicator code: SP.HOU.FEMA.ZS}
#' \item{teenage_mothers}{Teenage mothers (\% of women ages 15-19 who have had children or are currently pregnant). Indicator code: SP.MTR.1519.ZS}
#' \item{population_youth}{Population ages 0-14 (\% of total).
#' Population, age 0-14 (\% of total) is the population between the ages of 0 and 14 as a percentage of the total population. Indicator code: SP.POP.0014.TO.ZS}
#' \item{population_potential_active}{Population ages 15-64 (\% of total). 
#' Total population between the ages 15 to 64 is the number of people who could potentially be economically active. 
#' Population is based on the de facto definition of population, which counts all residents regardless of legal status or 
#' citizenship--except for refugees not permanently settled in the country of asylum, who are generally considered part of 
#' the population of the country of origin. Indicator code: SP.POP.1564.TO.ZS}
#' \item{population_aged}{Population ages 65 and above (\% of total).
#' Population ages 65 and above as a percentage of the total population. Population is based on the de facto definition of 
#' population, which counts all residents regardless of legal status or citizenship--except for refugees not permanently 
#' settled in the country of asylum, who are generally considered part of the population of the country of origin. Indicator code: SP.POP.65UP.TO.ZS}
#' \item{age_dependency}{Age dependency ratio (\% of working-age population).
#' Age dependency ratio is the ratio of dependents--people younger than 15 or older than 64--to the working-age population--those ages 15-64. Data are shown as the proportion of dependents per 100 working-age population.
#' Indicator code: SP.POP.DPND}
#' \item{age_dependency_old}{Age dependency ratio, old (\% of working-age population).
#' Age dependency ratio, old, is the ratio of older dependents--people older than 64--to the working-age population--those ages 15-64. Data are shown as the proportion of dependents per 100 working-age population.
#' Indicator code: SP.POP.DPND.OL}
#' \item{age_dependency_young}{Age dependency ratio, young (\% of working-age population).
#' Age dependency ratio, young, is the ratio of younger dependents--people younger than 15--to the working-age population--those ages 15-64. Data are shown as the proportion of dependents per 100 working-age population.
#' Indicator code: SP.POP.DPND.YG}
#' \item{population_growth}{Population growth (annual \%). 
#' Population growth (annual \%) is the exponential rate of growth of midyear population from year t-1 to t, 
#' expressed as a percentage. Indicator code: SP.POP.GROW}
#' \item{population}{Population, total. Indicator code: SP.POP.TOTL }
#' \item{female_population}{Population, female (\% of total). Indicator code: SP.POP.TOTL.FE.ZS}
#' \item{birth_registration_rural}{Completeness of birth registration, rural (\%). Indicator code: SP.REG.BRTH.RU.ZS}
#' \item{birth_registration_urban}{Completeness of birth registration, urban (\%). Indicator code: P.REG.BRTH.UR.ZS}
#' \item{birth_registration}{Completeness of birth registration (\%).
#' Completeness of birth registration is the percentage of children under age 5 whose births were registered at the time of the survey. 
#' The numerator of completeness of birth registration includes children whose birth certificate was seen by the interviewer or whose 
#' mother or caretaker says the birth has been registered. Indicator code: SP.REG.BRTH.ZS}
#' \item{unmet_contraception}{Unmet need for contraception (\% of married women ages 15-49). Indicator code: SP.UWT.TFRT}
#' 
#' }
#' @name WDIhealth
#' @details Indicator code is the character code for the indicator in the World Development Indicators database.
#' @author Bjørn Høyland Haakon Gjerløw Aleksander Eilertsen 
#' @references The World Bank (2013). 
#' @keywords dataset economy health
#' @source Project homepage: \url{http://data.worldbank.org/topic/health}
#' @seealso WDIeduc 
#' @examples
#' #This example shows how to 1) subset only countries from the dataset
#' #(i.e remove world regions and other categories) and 2) 
#' #fetch and rename some interesting variables (in this case hospital beds, physicians,
#' #life expectancy, 
#' #public and total health expenditure). 
#' 
#' data(WDIhealth)
#' library(reshape)
#' 
#' countries <- as.character(unique(WDIhealth$country)[33:246])
#' WDIhealthSub <- WDIhealth[WDIhealth$country %in% c(countries),]
#' myVars <- names(WDIhealthSub) %in% c("country", "country.code", "year","hospital_beds", 
#'                                    "physicians", "total_life_expectancy",
#'                                    "gdp_public_health_expenditure", "gdp_total_health_expenditure")
#' WDIhealthSub <- WDIhealthSub[myVars]
#' WDIhealthSub <- rename(WDIhealthSub, c(SH.MED.BEDS.ZS="hospBeds", SH.MED.PHYS.ZS="physicians", 
#'                                       SP.DYN.LE00.IN="lifeExpecTot",
#'                                       SH.XPD.PUBL.ZS="healthExpenPub",
#'                                      SH.XPD.TOTL.ZS="healthExpenTot"))
#' 
#' # This example shows that (even in a highly inefficient model) political
#' #instability increases the difference in life expectancy between males and females.
#' #The model assumes that the number of cabinets between elections is a proxy for political
#' #instability.
#' 
#' data(WDIhealth)
#' data(ParlGov)
#' 
#' ParlGov <- ParlGov[which(ParlGov$NewCab==1 & ParlGov$DecemberandCensored==1
#'                          & ParlGov$year >= 1960 & ParlGov$year <= 2011),]
#' Health <- merge(ParlGov,WDIhealth, by.x=c("country_name_short","year"),
#'                 by.y=c("country.code","year"),all.x=TRUE)
#' 
#' #Define class
#' Health$cumulative_election_cabinets <- as.numeric(as.character(Health$cumulative_election_cabinets))
#' 
#' #Create two lag variables
#' #Create two lag variables
#' Health$life_diff <- Health$female_life_expectancy - Health$male_life_expectancy
#' library(plm)
#' 
#' pHealth <- pdata.frame(Health,c("country","year"))
#' pHealth$life_diff_lag <- lag(pHealth$life_diff,1)
#' pHealth$cabinets_lag <- lag(pHealth$cumulative_election_cabinets)
#' 
#' Health <- data.frame(pHealth)
#' 
#' #Create a data set with correct length for PCSE later
#' Health <- na.omit(Health[,c("life_diff","minority_seats","cabinets_lag","coalition_cabinet",
#'                             "life_diff_lag","year","country","caretaker","country_name_short")])
#' 
#' #OLS autoregressive and fixed effects (time and entity) model:
#' polinstability <- lm(life_diff ~ factor(minority_seats)
#'                      + cabinets_lag + factor(coalition_cabinet) + factor(caretaker) +
#'                        life_diff_lag + factor(year) + factor(country), data=Health)
#' 
#' #Autocorrelation: There is still correlation between t and t-1:
#' resid <- data.frame(polinstability$residuals)
#' resid$resid_lag <- c(NA,resid[1:nrow(resid)-1,])
#' autocorr <- lm(resid[,1] ~ resid[,2])
#' library(car)
#' summary(autocorr)
#' avPlots(autocorr)
#' 
#' 
#' #Use PCSE to try to control for dependency between observations
#' library(pcse)
#' pcse <- pcse(polinstability,groupN=Health$country_name_short,groupT=Health$year, pairwise=TRUE)
#' Results <- cbind(pcse$b,pcse$pcse,pcse$b/pcse$pcse)
#' colnames(Results) <- c("b","pcse","t")
#' 
#' Results                                
NULL