#' uacd - Understanding Assembly Confidence - data
#' 
#'@details uacd provides a series of datasets and functions to analyse assembly confidence.
#' 
#' The package strives to collect data sets with information on democracy at
#' yearly national-, cabinet- and party-level.
#' By gathering several data sets in one package,  it is easy to combine information from several sources to get more complete inforamtion on world democracies.
#' 
#' \emph{\strong{For example:} the \link{ParlGov} database has a great coverage of 
#' national elections and voting results, cabinet and legislative parties
#' and the individual parties' position along different dimensions.
#' However, \link{ParlGov} lacks information on electoral formula and district magnitudes.
#' Matt Golder and Nils-Christian Bormann have done a great effort to collect such election data
#' in \link{desaw}. The uacd-package make both of these data sets available and easy to merge together}.
#' 
#' We have sought to collect data from three main type of democratic institutions:
#' \strong{1} Elections \strong{2} Cabinets and \strong{3} parties. The following figures show the amount of data in some of \code{UACD}'s largest sources for these types of data:
#' 
#' \figure{elections.pdf}{Elections}
#' 
#' \figure{cabinets.pdf}{Cabinets}
#' 
#' \figure{parties.pdf}{Parties}
#' 
#' 
#' 
#'@format It relies on data from a series of sources, including:
#' \describe{
#' 
#' \item{\link{Archigos}}{Archigos data set with info about state leaders}
#' \item{\link{ArchigosTimeVarying}}{Archigos data set with info about state leaders in a start-stop format}
#' \item{\link{ArchigosElectionDates}}{Archigos data set with an overview of elections}
#' \item{\link{BoixMillerRosato}}{Dichotomous Coding of Democracy 1800 - 2007}
#' \item{\link{BenoitLaver}}{Party Policy in Modern Democracies}
#' \item{\link{Cabinet}}{ParlGov's data about cabinets}
#' \item{\link{ChapelHill2010}}{Chapel Hill expert opinion survey of party positions 2010}
#' \item{\link{ChapelHill2006}}{Chapel Hill expert opinion survey of party positions 2006}
#' \item{\link{ChapelHill2002}}{Chapel Hill expert opinion survey of party positions 2002}
#' \item{\link{ChapelHill1999}}{Chapel Hill expert opinion survey of party positions 1999}
#' \item{\link{CastlesMair}}{Party Positions from Castles & Mair (1983)}
#' \item{\link{Election}}{ParlGov's data about elections}
#' \item{\link{ElectionandVoting}}{ParlGov's election data with info about voting}
#' \item{\link{HuberInglehart}}{Party Positions from Huber & Inglehart (1995)}
#' \item{\link{ParlGov}}{A combination of \link{Cabinet}, \link{Election}, \link{ElectionandVoting} and \link{Party} built by the UACD team.}
#' \item{\link{Party}}{ParlGov's party data with info about positions}
#' \item{\link{Portfolio}}{Portfolio allocation in Western Europe}
#' \item{\link{StromMuller}}{Comparative Parlimentary data archive}
#' }
#'@name uacd-package
#'@aliases uacd
#'@docType package
#'@author Bjørn Høyland and Haakon Gjerløw
#'@examples
#' #This is an example of how you can merge ParlGov and desaw
#' data(desaw);data(ParlGov)
#' #Remove all party-variance except from prime-ministers party from ParlGov so that 
#' #it becomes a country-year format with the cabinet that sat in december the 
#' #given year as cabinet
#' ParlGov <- ParlGov[which(ParlGov$prime_minister ==1 & ParlGov$DecemberandCensored >0),]
#' library(countrycode)
#' #Create Correlates of War country-codes in ParlGov so the two data sets can be merged
#' ParlGov$ccode <- countrycode(ParlGov$country_name_short, "iso3c", "cown")
#' #Remove presidential elections, since ParlGov only includes parliamentary elections
#' desaw <- desaw[which(desaw$presidential!=1),]
#' #Five of the countries in ParlGov are coded with 2 legislative elections in the 
#' #same year in desaw. This code keeps only the last election in these cases
#' desaw <- desaw[order(desaw$ccode,desaw$year,desaw$date),]
#' desaw <- desaw[!duplicated(desaw[,c("ccode","year")]),]
#' #Merge
#' ParlDes <- merge(ParlGov,desaw,by=c("ccode","year"),all.x=TRUE)
#' dim(ParlDes)
#' summary(ParlDes)
NULL