#' Parliamentary involvement in transposition of EU legislation
#' 
#' Data used to investigate extent of parliamentary involvement in transpostion of EU legislation from 1979 - 2004. The data is unbalanced as not all memebr states transposed all legisaltion, for various reasons, e.g. not being a member at the time, or had already adopted national legislation to the same effect. 
#' @name FranchinoHoyland
#' @docType data
#' @author Bjørn Høyland
#' @format
#' An unbalanced data frame with 6089 observations on the following 14 variables.
#' Each row represents a unique EU legislation.
#' It includes 15 countries for the period 1979 - 2004
#' 
#' \describe{
#'  \item{\code{legex3_dummy}}{a factor with levels \code{0} \code{1}, where 1 indicates that the parliament was involved in the transpostion of the legisation}
#'  \item{\code{confEL_ave}}{a numeric vector capturing the degree of conflict between the coaltionpartners in the policyarea}
#'  \item{\code{council}}{a factor with levels \code{0} \code{1}, indicates Council involvement in the passing of the legisaltion}
#'  \item{\code{numberpolicies}}{a numeric vector, number of policy areas}
#'  \item{\code{transyears}}{a numeric vector, number of years allowed for national transposition of the legislation}
#'  \item{\code{st_pglenght}}{a numeric vector, number of pages, measure of complexisty}
#'  \item{\code{agenda}}{a numeric vector, government's agendasetting power}
#'  \item{\code{gov_amend}}{a numeric vector, government's amendment power}
#'  \item{\code{vote_confidence}}{a numeric vector, government's advantage in a vote of confidence}
#'  \item{\code{bicameralism}}{a numeric vector, power of second chamber, if any}
#'  \item{\code{cabtur}}{a numeric vector, cabinet turnover}
#'  \item{\code{policyarea}}{a factor with levels \code{agriculture} \code{environment} \code{industry} \code{interior} \code{public_admin} \code{public_health} \code{social} \code{finance} \code{transport}}
#'  \item{\code{d_id}}{a numeric vector}
#'  \item{\code{state}}{a factor with levels \code{AUT} \code{BEL} \code{DEN} \code{FIN} \code{FRA} \code{GER} \code{GRE} \code{IRE} \code{ITA} \code{LUX} \code{NET} \code{POR} \code{SPA} \code{SWE} \code{UK}}
#' }
#' @references Franchino, Fabio & Høyland, Bjørn (2009) 'Legislative Involvement in Parliamentary Systems', American Political Science Review, Vol. 103(4): 607 -- 621.
#' @examples
#' ## Model 1 from the paper but without robust st errors, page 616
#' library(arm);data(FranchinoHoyland)
#' probit.multi <- glmer(legex3_dummy ~ confEL_ave + council + 
#' numberpolicies + transyears + st_pglenght + agenda + 
#' gov_amend + vote_confidence + bicameralism + cabtur + 
#' confEL_ave:council + confEL_ave:numberpolicies + confEL_ave:transyears +
#' confEL_ave:st_pglenght + 
#' confEL_ave:agenda + confEL_ave:gov_amend + confEL_ave:vote_confidence+ 
#' confEL_ave:bicameralism+ policyarea +(1|d_id),
#' data=FranchinoHoyland, family=binomial(probit))
#' display(probit.multi)
#' @keywords dataset parliament EU policy
NULL