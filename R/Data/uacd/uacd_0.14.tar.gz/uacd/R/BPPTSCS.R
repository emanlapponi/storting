#' BPP401 - Beyond Parliamentarism and Presidentialism Time Series Cross Sectional Data of Constitutional Regime
#' 
#' @description This is one of three datasets used in the article "Beyond Parliamentarism and Presidentialism".
#' @format Constitutional regime for 223 countries between 1600 anf 2010. 22202 rows and 4 variables.
#' \describe{
#' 
#' \item{cowcode}{Correlates of War country code}
#' \item{country}{Country name}
#' \item{year}{Calendar year}
#' \item{regime}{Classification of presidential, parliamentary and semi-presidential.
#' 
#'\strong{Presidential}: Constitutions  in which the head of state is popularly elected (directly or indirectly) and the government does not need assembly confidence in order to exist.
#' 
#'\strong{Parliamentary}: Constitutions in which the head of state is a monarch or a president elected by the existing legislature,
#'and the government must obtain the confidence of the legislature in order to remain in power.
#'
#'\strong{Semi-presidential}: Constitutions in which the head of state is popularly elected (directly or indirectly) and the government needs to obtain the confidence
#'of the legislative assembly in order to exist.}
#'
#'}
#' @name BPPTSCS
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references  José Antonio Cheibub, Zachary Elkins and Tom Ginsburg. "Beyond Presidentialism and Parliamentarism". British Journal of Political Science, available on CJO2013. doi:10.1017/S000712341300032X. 
#' @source \url{http://journals.cambridge.org/action/displayAbstract?fromPage=online&aid=9072592} 
#' @seealso \link{BPPSimilarity} \link{BPP401}
#' @keywords dataset constitutions
#' @examples
#' library(uacd)
#' data(BPPSimilarity)
NULL