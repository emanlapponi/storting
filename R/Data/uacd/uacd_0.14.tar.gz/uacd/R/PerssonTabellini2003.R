#' PerssonTabellini2003 - Replication data for "The Economic Effects of Constitutions" 
#' 
#' @description These are replication data for "The Economic Effects of Constitutions".
#' @format A dataframe with 2340 rows and 178 variables.
#' It includes 60 countries in the period 1960 - 1998.
#' 
#' 
#' \describe{
#' \item{ctrycd}{Country code}
#' \item{country}{Country name}
#' \item{year}{Year.}
#' \item{cgexp}{Central government expenditures as a percentage of GDP,
#' constructed using the item Government Finance - Expenditures in the IFS,
#' divided by GDP at current prices and multiplied by 100.
#' Source: IMF - IFS CD-Rom and IMF - IFS Yearbook.}
#' \item{dcgexp}{First difference of \code{CGEXP}}
#' \item{cgrev}{Central government revenues as a percentage of GDP,
#' constructed using the item Government Finance - Revenues in the IFS,
#' divided by GDP at current prices and multiplied by 100.
#' Source: IMF - IFS CD-Rom and IMF - IFS Yearbook.}
#' \item{spl}{Central government budget surplus (if positive) or deficit (if negative),
#' as a percentage of GDP, constructed using the item Government Finance - Deficit and Surplus
#' in the IFS, divided by the GDP at current prices and multiplied by 100.
#' Source: IMF - IFS CD-Rom and IMF - IFS Yearbook.}
#' \item{elleg}{Dummy variable for legislative elections,
#' equal to 1 in the year the legislature is elected, independently from the form of government.
#' Source: http://www.ifes.org/eguide/elecguide.htm plus other national sources.}
#' \item{col_oth}{Dummy variable, equal to 1 if the country is a former colony
#' of a country other than Spain, or Portugal, or the UK, 0 otherwise.
#' Source: Wacziarg (1996).}
#' \item{trade}{Sum of exports and imports of goods and services measured as a share of GDP.
#' Source: The World Bank's World Development Indicators CD Rom 2000.}
#' \item{oil}{Price of oil in US dollars. Source: Datastream.}
#' \item{gdp}{Gross domestic product at current price. Source: IFS CD-Rom and IFS Yearbook.}
#' \item{africa}{Regional dummy variable, equal to 1 if a country is in Africa, 0 otherwise.}
#' \item{asiae}{Regional dummy variable, equal to 1 if a country is in East Asia, 0 otherwise.}
#' \item{laam}{Regional dummy variable, equal to 1 if a country is in Latin America, Central America or the Caribbeans, 0 otherwise}
#' \item{maj}{: dummy variable for electoral systems. Equals 1 if all the lower house is elected under
#' plurality rule, 0 otherwise. Only legislative elections (lower house) are considered.
#' Sources: Cox (1997), International Institute for Democracy and Electoral Assistance (1997),
#' Quain (1999), Kurian (1998), and national sources}
#' \item{oecd}{Dummy variable, equal to 1 for all countries that were members of OECD before 1993,
#' 0 otherwise, except for Turkey coded as 0 even though it was a member of OECD before the 1990s.}
#' \item{pres}{dummy variable for forms of government, equal to 1 in presidential regimes, 0 otherwise.
#' Only regimes where the confidence of the assembly is not necessary for the executive
#' (even if an elected president is not chief executive, or if there is no elected president)
#' are included among presidential regimes. Most semi-presidential and premier-presidential systems are
#' classified as parliamentary (see the text in Chapter 4 for further discussion and clarification).
#' Source: Shugart and Carey (1992) and national sources).}
#' \item{col_uk}{Dummy variable, equal to 1 if the country is a former UK colony, 0 otherwise.
#' Source: Wacziarg (1996).}
#' \item{legor_uk}{Dummy variables for the origin of the legal system,
#' classifying a country's legal system into Anglo-Saxon Common Law (UK).
#' Source: La Porta et al. (1998)}
#' \item{legor_fr}{Dummy variables for the origin of the legal system,
#' classifying a country's legal system into French Civil Law (FR).
#' Source: La Porta et al. (1998)}
#' \item{legor_so}{Dummy variables for the origin of the legal system,
#' classifying a country's legal system into Socialist Law (SO).
#' Source: La Porta et al. (1998)}
#' \item{legor_ge}{Dummy variables for the origin of the legal system,
#' classifying a country's legal system into German Civil Law (GE).
#' Source: La Porta et al. (1998)}
#' \item{legor_sc}{Dummy variables for the origin of the legal system,
#' classifying a country's legal system into Scandinavian Law (SC).
#' Source: La Porta et al. (1998)}
#' \item{latitude}{distance from the equator (in degrees), ranging between -90 to 90.
#' Source: Hall and Jones (1999).}
#' \item{semi}{\strong{Not found in codebook}.
#' However, the codebook writes about a variable named \code{mixed} which is not in the data set,
#' but which could be this variable:
#' Dummy variable for electoral systems, equal to 1 if the electoral formula for electing the
#' lower house is neither strict plurality rule nor strict proportionality, 0 otherwise.
#' Semi-proportional (or mixed) electoral rule identifies those electoral systems characterized by
#' both proportional and first-past-the-post representation for allocating seats
#' (for example Bolivia, Germany, Italy after the reform of 1993, etc.).
#' The share of the total number of seats allocated under the Proportional rule can be greater or smaller than
#' the complementary plurality-allocated share. Only legislative elections are considered.
#' Sources: Cox (1997), International Institute for Democracy and Electoral Assistance (1997), Quain (1999), and Kurian (1998) and national sources.}
#' \item{dssw}{First difference of \code{SSW}}
#' \item{lpop}{Natural log of the total population (in millions). Source: World Bank}
#' \item{prop1564}{Percentage of population between 15 and 64 years old in the total population.
#' Source: World Development Indicators CD-Rom 1999.}
#' \item{prop65}{Percentage of population over the age of 65 in the total population.
#' Source: World Development Indicators CD-Rom 1999.}
#' \item{majpres}{Interaction: \code{maj} * \code{pres}}
#' \item{majpar}{Interaction: \code{maj} * (1 - \code{pres})}
#' \item{propres}{Interaction: (1 - \code{maj}) * \code{pres}}
#' \item{propar}{Interaction: (1 - \code{maj}) * (1 - \code{pres})}
#' \item{posyg}{Positive values of \code{ygap}, 0 if \code{ygap} is negative.}
#' \item{negyg}{Negative values of \code{ygap}, 0 if \code{ygap} is positive.}
#' \item{ygap}{Deviation of aggregate output from its trend value in percent, 
#' computed as difference between the natural log of real GDP in the country and its country-specific trend
#' (obtained, using the Hodrick-Prescott filter). Source for real GDP: World Bank}
#' \item{polityIV}{Score for democracy, computed by subtracting the AUTOC score from the DEMOC score,
#' and ranging from +10 (strongly democratic) to -10 (strongly autocratic). Source: \link{PolityIV} Project}
#' \item{ccg_net_0}{Consolidated central government net domestic debt as a
#' percentage of gross national disposable income, in the first year for which a value of \code{spl} is available.
#' The Consolidated Central Government (CCG) is defined as follows:
#' budgetary central government plus extra budgetary central government plus social security agencies.
#' This definition of the central government is equivalent to that of general government
#' minus local and regional governments. Source: World Savings Database}
#' \item{col_uka}{UK colonial origin, discounted by the years since independence (\code{t_indep}),
#' and defined as \code{col_uka} = \code{col_uk} * (250 - \code{t_indep})/250. Source: Wacziarg (1996).}
#' \item{col_espa}{Spanish colonial origin, discounted by the years since independence (\code{t_indep}),
#' and defined as \code{col_espa} = \code{col_es} * (250 - \code{t_indep})/250. Source: Wacziarg (1996).
#' Source: Wacziarg (1996).}
#' \item{col_otha}{Other colonial origin, discounted by the years since independence (\code{t_indep}),
#' and defined as \code{col_otha} = \code{col_oth} * (250 - \code{t_indep})/250. Source: Wacziarg (1996)}
#' \item{federal}{Dummy variable, equal to 1 if the country has a federal political structure, 0 otherwise.
#' Source: Adsera, Boix and Paine (2001).}
#' \item{engfrac}{The fraction of the population speaking English as a native language.
#' Source: Hall and Jones (1999).}
#' \item{eurfrac}{The fraction of the population speaking one of the major languages of Western Europe: English, French, German, Portoguese, or Spanish.
#' Source: Hall and Jones (1999).}
#' \item{lat01}{Rescaled variable for latitude, defined as the absolute value of \code{latitude}
#' divided by 90 and taking values between 0 and 1. Source: Hall and Jones (1999).}
#' \item{rgdph}{is defined as real GDP per capita in constant dollars (chain index) expressed in
#' international prices, base year 1985. Data through 1992 are taken from the Penn World Table 5.6
#' (variable named RGDPC), while data on the period 1993-98 are computed from data taken from the
#' World Development Indicators, the World Bank. These later observations are computed on the basis of
#' the latest observation available from the Penn Word Tables and the growth rates of GDP per capita in
#' the subsequent years computed from the series of GDP at market prices (in constant 1995 U.S. dollars)
#' and population, from the World Development Indicators. Sources: Penn World Tables - mark 5.6 (PWT),
#' available on \url{http://datacentre2.chass.utoronto.ca/pwt/docs/topic.html}.
#' The World Bank's World Development Indicators; www.worldbank.org.}
#' \item{polity_gt}{Interpolated version of \code{polityIV}, rescaled with the same units of \code{gastil}
#' (i.e. higher values denote worse democracies). Computed as the forecasted value obtained by
#' regressing the rescaled values of \code{polityIV} on \code{gastil}. }
#' \item{gastil}{Average of indexes for civil liberties and political rights, where each index is measured
#' on one-to-seven scale with one representing the highest degree of freedom and seven the lowest.
#' Countries whose combined averages for political rights and for civil liberties fall between 1.0 and 2.5 are
#' designated "free", between 3.0 and 5.5 "partly free" and between 5.5 and 7.0 "not free".
#' Source: Freedom House, Annual Survey of Freedom Country Ratings.}
#' \item{lyp}{natural log of per capita real GDP (\code{rgdph}).} 
#' \item{du_noec}{Dummy variable for oil exporter.}
#' \item{mining_gdp}{Share of mining sector over GDP.
#' Source: UN National accounts}
#' \item{oil_ex}{\code{oil} times a dummy variable that equals 1 if net exports of oil are positive, 0 otherwise.}
#' \item{oil_im}{\code{oil} times a dummy variable that equals 1 if net exports of oil are negative, 0 otherwise.}
#' \item{default}{\strong{Not in codebook}. The variable seems to be coded as 1 when \code{polityIV} is positive and 0 otherwise.}
#' \item{ssw}{Consolidated central government expenditures on social services and welfare as percentage of GDP,
#' as reported in GFS Yearbook, divided by GDP and multiplied by 100. Source: IMF - GFS Yearbook 2000 and
#' IMF - IFS CD-Rom}
#' \item{lssw}{It represents the one-period lagged series of \code{ssw}}
#' \item{lspl}{\strong{Not in codebook}. Given the name, this could be the the one-period lagged series of \code{spl}}
#' \item{lcgrev}{One-year lag of \code{cgrev}}
#' \item{lcgexp}{One-year lag of \code{cgexp}}
#' \item{elex}{Dummy variable for executive elections, equal to 1 in a year when the executive is elected,
#' and 0 otherwise. Takes into consideration both presidential elections and legislative elections.
#' Source: \url{http://www.ifes.org/eguide/elecguide.htm} plus other national sources.}
#' \item{lelex}{One year lag of \code{elex}}
#' \item{el_maj}{Interaction: \code{maj} * \code{elex}}
#' \item{lel_maj}{One year lag of \code{el_maj}}
#' \item{el_pro}{Interaction: (1- \code{maj}) * \code{elex}}
#' \item{lel_pro}{One year lag of \code{el_pro}}
#' \item{el_pre}{Interaction: \code{pres} * \code{elex}}
#' \item{lel_pre}{One year lag of \code{el_pre}}
#' \item{el_par}{Interaction: (1- \code{pres}) * \code{elex}}
#' \item{lel_par}{One year lag of \code{el_par}}
#' \item{el_majpre}{Interaction: \code{pres} * \code{maj} * \code{elex}}
#' \item{el_propre}{Interaction: \code{pres} * (1- \code{maj}) * \code{elex}}
#' \item{el_majpar}{Interaction: (1- \code{pres}) * \code{maj} * \code{elex}}
#' \item{el_propar}{Interaction: (1- \code{pres}) * (1- \code{maj}) * \code{elex}}
#' \item{lel_majpre}{One year lag of \code{el_majpre}}
#' \item{lel_propre}{One year lag of \code{el_propre}}
#' \item{lel_majpar}{One year lag of \code{el_majpar}}
#' \item{lel_propar}{One year lag of \code{el_propar}}
#' }
#' @name PerssonTabellini2003
#' @author Bjørn Høyland, Haakon Gjerløw and Aleksander Eilertsen 
#' @references Persson, Torsten and Guido Tabellini (2003) \emph{The Economic Effects of Constitutions}. Cambridge: The MIT Press.
#' @keywords dataset election economy parliament
#' @source Guido Tabellini's homepage: 
#' \url{http://didattica.unibocconi.eu/myigier/index.php?IdUte=48805&idr=4273&lingua=eng&comando=Apri}
#' @seealso  PerssonTabellini2009
#' @examples 
#' #This example replicates figure 3.1 on page 38 in the book.
#'  
#'  data(PerssonTabellini2003)
#'  #remove missing and censor thos above 60. These are war-years in Israel and Nicaragua.
#'  GovSize <- PerssonTabellini2003[which(is.na(PerssonTabellini2003$cgexp)==FALSE
#'                                        & PerssonTabellini2003$cgexp <= 60),]
#'  
#'  plot(GovSize$year,GovSize$cgexp,bty="n",xlim=c(1960,2000),xaxt="n",ylab="")
#'  axis(1,at=c(seq(1960,2000,10)))
#'  
#'  #Get the mean-line
#'  Mean <- aggregate(GovSize$cgexp, by=list(GovSize$year),mean)
#'  lines(Mean$Group.1,Mean$x,col="red")
NULL