#' BPPSimilarity - Beyond Parliamentarism and Presidentialism Constitutional Similarities
#' 
#' @description This is one of three datasets used in the article "Beyond Parliamentarism and Presidentialism".
#' @format Dyads of 401 constitutions and their similarities. 80200 rows and 56 variables.
#' \describe{
#' 
#' \item{cowcodea}{Correlates of War country code for constitution "a"}
#' \item{cowcodeb}{Correlates of War country code for constitution "b"}
#' \item{samecoun}{Coded 1	if both constitutions were written in the same country, 0 otherwise}
#' \item{yeara}{Year when constitution "a" was written}
#' \item{yearb}{Year when constitution "b" was written}
#' \item{yeardiff}{Difference between \code{yeara} and \code{yearb}}
#' \item{simhog}{Degree of similiarity between two constitutions}
#' \item{simmono}{Degree of similiarity between two constitutions}
#' \item{simsplit}{Degree of similiarity between two constitutions}
#' \item{simextra}{Degree of similiarity between two constitutions}
#' \item{region_ccpa}{Region of the world where constitution "a" was written}
#' \item{region_ccpb}{Region of the world where constitution "b" was written}
#' \item{samereg}{Coded 1 if both constitutions were written in countries belonging to the same region of the world, 0 otherwise}
#' \item{regimea}{Regime type (see \emph{details}) of constitution "a".}
#' \item{regimeb}{Regime type (see \emph{details}) of constitution "b".}
#' \item{samesysr}{Coded 1 if both constitutions have the same type (see \emph{details}), 0 otherwise}
#' \item{bothpres_r}{Coded 1 if both constitutions were presidential (see \emph{details}), 0 otherwise}
#' \item{bothparl_r}{Coded 1 if both constitutions were parliamentary (see \emph{details}), 0 otherwise}
#' \item{bothsemi_r}{Coded 1 if both constitutions were semi-presidential (see \emph{details}), 0 otherwise}
#' \item{presparl_r}{Coded 1 if one constitution was presidential and the other parliamentary (see \emph{details}), 0 otherwise}
#' \item{pressemi_r}{Coded 1 if one constitution was presidential and the other semi-presidential (see \emph{details}), 0 otherwise}
#' \item{parlsemi_r}{Coded 1 if one constitution was parliamentary and the other semi-presidential (see \emph{details}), 0 otherwise}
#' \item{hinsta}{Regime type (as defined by \code{hinst} in \link{BPP401}) of constitution "a"}
#' \item{hinstb}{Regime type (as defined by \code{hinst} in \link{BPP401}) of constitution "b"}
#' \item{samesysh}{Coded 1 if both constitutions have the same regime type (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{bothpres_h}{Coded 1 if both constitutions were presidential (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{bothparl_h}{Coded 1 if both constitutions were parliamentary (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{bothsemi_h}{Coded 1 if both constitutions were semi-presidential (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{presparl_h}{Coded 1 if one constitution was presidential and the other parliamentary (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{pressemi_h}{Coded 1 if one constitution was presidential and the other semi-presidential (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#' \item{parlsemi_h}{Coded 1 if one constitution was parliamentary and the other semi-presidential (as defined by \code{hinst} in \link{BPP401}), 0 otherwise}
#'  }
#' @details
#' Classification of regime follows these instructions:
#' 
#'\strong{Presidential}: Constitutions  in which the head of state is popularly elected (directly or indirectly) and the government does not need assembly confidence in order to exist.
#' 
#'\strong{Parliamentary}: Constitutions in which the head of state is a monarch or a president elected by the existing legislature,
#'and the government must obtain the confidence of the legislature in order to remain in power.
#'
#'\strong{Semi-presidential}: Constitutions in which the head of state is popularly elected (directly or indirectly) and the government needs to obtain the confidence
#'of the legislative assembly in order to exist.
#'
#' @name BPPSimilarity
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references  José Antonio Cheibub, Zachary Elkins and Tom Ginsburg. "Beyond Presidentialism and Parliamentarism". British Journal of Political Science, available on CJO2013. doi:10.1017/S000712341300032X. 
#' @source \url{http://journals.cambridge.org/action/displayAbstract?fromPage=online&aid=9072592} 
#' @seealso \link{BPP401} \link{BPPTSCS}
#' @keywords dataset constitutions
#' @examples
#' library(uacd)
#' data(BPPSimilarity)
NULL