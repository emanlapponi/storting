#' UnsuccessfulSuccess - Replication data from "Unsuccessful Sucess? Failed No-Confidence Motions, Competence Signals and Electoral Support"
#' 
#' @description This is Laron K. Williams replication data from "Unsuccessful Sucess? Failed No-Confidence Motions, Competence Signals and Electoral Support"
#' @format A data frame with 1099 rows and 21 columns.
#' It includes 20 countries between 1953 - 2003.
#' \describe{
#' \item{nation}{Country}
#' \item{ccode}{Country code from Correlates of War}
#' \item{ptyname}{Party name abbreviation}
#' \item{elecdate}{Election date. Year-month format. Year has two digits until year 2000, then it is coded with four digits.}
#' \item{pervote}{Party vote share}
#' \item{lag_pervote}{Party vote share lagged (previous party vote share)}
#' \item{rgdppc_growth}{Real GDP per capita growth. For elections in the first 6 months, the lagged value is coded. This is from Penn World Tables (\link{PWT}) Version 6.2}
#' \item{opp_conf_elecdate}{Number of No-confidence motions against government}
#' \item{opp_conf_party_elecdate}{Number of No-confidence motions by the respective party}
#' \item{gparties}{Number of government parties. From Woldendorp, Keman, Budge (2000)}
#' \item{majority}{Dummy indicating if the cabinet has a majority of seats in the parliament. From Woldendorp, Keman, Budge(2000)}
#' \item{xregbet}{Dummy indicating if the party is a part of the cabinet}
#' \item{prime_dummy}{Dummy variable indicating prime minister's party. From Woldendorp, Keman, Budge(2000)}
#' \item{party}{Unkown. Not in codebook. By inspection this seems like a party ID variable.}
#' \item{eff_par}{Effective number of parties}
#' \item{change}{Change in vote share for each party from the previous election}
#' \item{abs_rile}{Partys absolute value on left-right score from Comparative Manifesto Projects "rile" variable.
#' Higher values indicates increased distance from 0 on the \code{rile}-variable in \link{ManifestoFull}.
#' 0 is assumed to represent ideological center. This variable is meant to capture are party's extremism.}
#' \item{ncm_abs_rile}{Interaction: \code{abs_rile} * \code{opp_conf_elecdat}  }
#' \item{ncm_all_abs_rile}{Interaction: \code{abs_rile} * \code{opp_conf_part_elecdate} }
#' \item{eoc}{Interaction: \code{eff_par} * \code{opp_conf_elecdate} }
#' \item{eoc_p}{Interaction: \code{eff_par} * \code{opp_conf_party_elecdate} }
#' 
#' }
#' @name UnsuccessfulSuccess
#' @author Bjørn Høyland, Haakon Gjerløw and Aleksander Eilertsen
#' @keywords dataset election cabient economy parliament position
#' @source Homepage: \url{http://web.missouri.edu/~williamslaro/research.html}
#' @references Williams, Laron K. (2011). "Unsuccessful Sucess? Failed No-Confidence Motions, Competence Signals and Electoral Support" in \emph{Comparative Political Studies}, vol. 44 no. 11.
#' @examples
#' # This example will give a correct replication of table 1 on page 1489 in the article
#' 
#' library(uacd);library(sandwich)
#' data(UnsuccessfulSuccess)
#' 
#' library(uacd);library(sandwich)
#' 
#' cl   <- function(dat,fm, cluster){
#'   require(sandwich, quietly = TRUE)
#'   require(lmtest, quietly = TRUE)
#'   M <- length(unique(cluster))
#'   N <- length(cluster)
#'   K <- fm$rank
#'   dfc <- (M/(M-1))*((N-1)/(N-K))
#'   uj  <- apply(estfun(fm),2, function(x) tapply(x, cluster, sum));
#'   vcovCL <- dfc*sandwich(fm, meat=crossprod(uj)/N)
#'   coeftest(fm, vcovCL) }
#' 
#' xregbet1 <- UnsuccessfulSuccess[which(UnsuccessfulSuccess$xregbet==1),]
#' xregbet0 <- UnsuccessfulSuccess[which(UnsuccessfulSuccess$xregbet==0),]
#' 
#' # Model 1: Govt. parties
#' Model1 <- lm(change ~ opp_conf_elecdate + rgdppc_growth + factor(majority) +
#' gparties + factor(prime_dummy) + lag_pervote,data=xregbet1)
#' Model1 <- data.frame(cl(xregbet1, Model1,xregbet1$ccode)[,c(1,2)])
#' Model1 <- cbind(c("Constant","No. of NCMs agains govt.", "Real GDP per capita growth",
#'                   "Majority govt.","No. of govt. parties",
#'                   "Prime ministers party", "Lagged vote share"),Model1)
#' colnames(Model1) <- c("Variable","Model1_coefs","Model1_SE")
#' 
#' # Model 2: Govt. parties
#' Model2 <- lm(change ~ opp_conf_elecdate + opp_conf_party_elecdate +
#' rgdppc_growth + factor(majority) + gparties + lag_pervote,data=xregbet0)
#' Model2 <- data.frame(cl(xregbet0, Model2,xregbet0$ccode)[,c(1,2)])
#' Model2 <- cbind(c("Constant","No. of NCMs agains govt.",
#' "No. of NCMs by that party", "Real GDP per capita growth",
#'                   "Majority govt.","No. of govt. parties","Lagged vote share"),Model2)
#' colnames(Model2) <- c("Variable","Model2_coefs","Model2_SE")
#' 
#' 
#' # Model 3: Opposition parties
#' Model3 <- lm(change ~ opp_conf_elecdate + opp_conf_party_elecdate +
#' rgdppc_growth + factor(majority)
#'              + gparties + lag_pervote + eff_par + eoc + eoc_p
#'              ,data=xregbet0)
#' Model3 <- data.frame(cl(xregbet0, Model3,xregbet0$ccode)[,c(1,2)])
#' Model3 <- cbind(c("Constant","No. of NCMs agains govt.",
#' "No. of NCMs by that party", "Real GDP per capita growth",
#'                   "Majority govt.","No. of govt. parties","Lagged vote share",
#'                   "Effective no. of parties","Eff. parties x Govt. NCMs",
#'                   "Eff. parties x Party NCMs"),Model3)
#' colnames(Model3) <- c("Variable","Model3_coefs","Model3_SE")
#' 
#' # Model 4: Opposition parties
#' Model4 <- lm(change ~ opp_conf_elecdate + opp_conf_party_elecdate +
#' rgdppc_growth + factor(majority)
#'              + gparties + lag_pervote + abs_rile + ncm_all_abs_rile + ncm_abs_rile
#'              ,data=xregbet0)
#' Model4 <- data.frame(cl(xregbet0, Model4,xregbet0$ccode)[,c(1,2)])
#' Model4 <- cbind(c("Constant","No. of NCMs agains govt.",
#' "No. of NCMs by that party", "Real GDP per capita growth",
#'                   "Majority govt.","No. of govt. parties",
#'                   "Lagged vote share","Ideological extremism",
#'                   "Extremism x Govt. NCMs", "Extremism x Party NCMs"),Model4)
#' colnames(Model4) <- c("Variable","Model4_coefs","Model4_SE")
#' 
#' Table1 <- merge(Model1,Model2,by="Variable",all=TRUE)
#' Table1 <- merge(Table1,Model3,by="Variable",all=TRUE)
#' Table1 <- merge(Table1,Model4,by="Variable",all=TRUE)
#' 
#' Table1
#' 
#' 
#' #Compare abs_rile Manifesto's rile variable, since the former is based on the latter.
#' #This example is from the parties in the norwegian party system.
#' 
#' data(UnsuccessfulSuccess)
#' Norway <- UnsuccessfulSuccess[which(UnsuccessfulSuccess$nation=="Norway"),]
#' Norway$Year <- paste("19",substr(Norway$elecdate, 1, 2),sep="")
#' library(car)
#' Norway$Year <- recode(Norway$Year, "'1920'='2001'")
#' Norway <- Norway[which(Norway$ptyname!="PP"),]
#' Norway$col <- recode(Norway$ptyname, "'SLP'='red3';'AP'='red';
#'                      'SP'='darkgreen';'VEN'='green';'KF'='yellow';
#'                      'FP'='darkblue';'HOYRE'='blue';'NKP'='darkred'")
#' 
#' 
#' 
#' data(ManifestoFull)
#' ManifestoFull$edate <- as.Date(ManifestoFull$edate, origin = "1960-01-01")
#' ManifestoFull$edate<- format(ManifestoFull$edate,"%d-%m-%Y")
#' ManifestoFull$edate <- sapply(strsplit(ManifestoFull$edate, "-"), "[[", 3)
#' 
#' MNorway <- ManifestoFull[which(ManifestoFull$country==12),]
#' MNorway <- MNorway[which(MNorway$party!=12410 & MNorway$edate >=1953
#'                    & MNorway$edate <= 2001),]
#' 
#' MNorway$col <- recode(MNorway$party, "'12221'='red3';'12320'='red';
#'                       '12810'='darkgreen';'12420'='green';'12520'='yellow';
#'                       '12951'='darkblue';'12620'='blue';'12220'='darkred' ")
#' 
#' par(mfrow=c(1,2))
#' 
#' plot(MNorway$rile,MNorway$edate,type="n",main="Manifesto rile")
#' for(i in 1:length(levels(factor(MNorway$party)))){
#'   with(MNorway[which(MNorway$party==levels(factor(MNorway$party))[i]),],
#'        lines(rile,edate,col=col))
#' }
#' legend("topright",fill=c("darkred","red3","red","darkgreen","green","yellow",
#'                          "blue","darkblue"),
#'        bty="n",legend=c("NKP","SV","AP","SP","V","KrF","H","FrP"))
#' 
#' 
#' plot(Norway$abs_rile,Norway$Year,type="n",main="UnsuccessfulSuccess rile",
#' xlab="Distance from ideological center",ylab="Year")
#' for(i in 1:length(levels(factor(Norway$ptyname)))){
#'   with(Norway[which(Norway$ptyname==levels(factor(Norway$ptyname))[i]),],
#'        lines(abs_rile,Year,col=col))
#' }
#' legend("topright",fill=c("red3","red","darkgreen","green","yellow",
#'                          "blue","darkblue"),bty="n",
#'        legend=c("SV","AP","SP","V","KrF","H","FrP"))
#' 
NULL