#' GolderAfrica - Replication data for: Are african party systems different?
#' 
#' @description Matt Golder's replication data for "Are african party systems different?"
#' @format A dataframe with 62 rows and 24 variables.
#' 38 countries at time points in the period 1980 - 2000. 
#' \describe{
#' \item{country_nyu}{Name of country.}
#' \item{year}{Year of legislative election}
#' \item{avemagnitude_nyu}{Average district magnitude in lowest tier. Number of seats in lower house divided by number of districts in lower house.}
#' \item{dictator_nyu}{Classification of political regimes as democracies and dictatorships.
#' Transition years are coded as the regime that exists (0 Democracy, 1 Dictatorship) as of December 31st in that year.
#' A regime is considered a dictatorship if the chief executive is not elected,
#' the legislature is not elected, there is no more than one party,
#' or there has been no alternation in power (Przeworski et al. 2000, Przeworski et al. 1996).
#' In other words, a regime is democratic if those who govern are selected through contested elections.}
#' \item{district_nyu}{Number of districts/constituencies in the lowest electoral tier}
#' \item{elecparties_nyu}{Effective number of electoral parties, following the calculation by Taagepera 1997}
#' \item{legparties_nyu}{Effective number of legislative parties, following the calculation by Taagepera 1997}
#' \item{concentration}{This is an index of ethnopolitical group concentration adapted from the Minorities at Risk
#' (Phase III) dataset: 0 = widely dispersed, 1 = primarily urban or minority in one region,
#' 2 = majority in one region, dispersed in others, 3 = concentrated in one region.
#' The index is calculated for each group by multiplying its concentration code by its share of 
#' the ethnopolitcally relevant population. Sum these numbers to get the concentration score for each country.}
#' \item{fragmentation}{This is a measure of ethnopolitical group fragmentation based on the share of the politicized
#' population that belongs to each ethnopolitical group or subgroup.
#' This index combines three levels of inclusiveness by including all undivided top and middle-level
#' groups and all lowest-level groups. It includes all groups that are potentially politically relevant
#' at the national level, while excluding groups that have not been politicized.
#' This is a description taken directly from Mozaffar et al. (2003). I do not know what the units of
#' measurement are exactly.}
#' \item{fragmentation2}{This is fragmentation squared (fragmentation^2)}
#' \item{logmag_nyu}{Natural logarithm of average district magnitude}
#' \item{logmag_conc_nyu}{Interaction: logmag_nyu * concentration}
#' \item{logmag_frag_nyu}{Interaction: logmag_nyu * fragmentation}
#' \item{logmag_frag_conc_nyu}{Interaction: logmag_nyu * fragmentation * concentration}
#' \item{prescandidate_nyu}{Effective number of presidential candidates}
#' \item{proximity_nyu}{A continuous variable from 0 to 1 measuring the proximity of presidential and legislative elections. Legislative and presidential elections that are held concurrently are coded as 1.
#' If legislative elections are midterm elections or if the regime has no direct presidential elections, then proximity_nyu is coded 0.
#' The more proximal the non-concurrent elections, the higher the proximity_nyu score.}
#' \item{prox_prescandidate_nyu}{Interaction: proximity_nyu * ENPRES. The codebook doesn't contain any information about ENPRES, but it might be prescandidate_nyu}
#' \item{seats_nyu}{Total number of seats in the lower house of the legislature during the election year. Changes in the number of seats are shown for the first election in which they are used}
#' \item{upperseats_nyu}{Total number of seats allocated in upper tiers above the district level.}
#' \item{uppertier_nyu}{Percentage of seats allocated in electoral districts above the lowest tier.
#' The percentage of upper tier seats is calculated as the total number of seats allocated in electoral tiers
#' above the district level divided by the total number of elected seats in the legislature.}
#' }
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @name GolderAfrica
#' @references Thomas Brambor; William Roberts Clark; Matt Golder, 2007, "Replication data for: Are African Party Systems Different?", http://hdl.handle.net/1902.1/10559 UNF:3:EiJkB9ZQmL0qN82HMuE3Ew== Matt Golder [Distributor] V1 [Version]
#' @keywords dataset election
#' @source Matt Golder's dataverse homepage: \url{http://dvn.iq.harvard.edu/dvn/dv/mgolder}
#' @seealso desaw, GolderExtremeRight, GolderFiscalPolicyEU
#' @examples
#' # The regression formula from the .do file.
#' #This should replicate the results from the fully-specified corrected data model
#' #in table 1.
#' # However, the results are not identical.
#' data(GolderAfrica)
#' lm(elecparties_nyu ~ fragmentation + concentration + logmag_nyu
#'   + frag_conc_nyu + logmag_frag_nyu + logmag_conc_nyu
#'   + logmag_frag_conc_nyu + proximity_nyu + prescandidate_nyu
#'   + prox_prescandidate_nyu, data=GolderAfrica)
#'
NULL