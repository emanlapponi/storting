#' PerssonTabellini2009 -  Replication data for 
#' Democratic Capital: The Nexus of Political and Economic Change by Persson and Tabellini (2009). 
#' 
#' @description This balanced dataset contains replication data for 
#' Democratic Capital: The Nexus of Political and Economic Change by Persson and Tabellini (2009). The dataset covers 
#' 155 countries for (at most) 180 years, from 1820 to 2000. For additional information, 
#' see \url{http://www.jstor.org/stable/25760275}. 
#'
#' @format A dataframe with 36180 rows and 37 variables. 
#' It includes 155 countries in the period 1820 - 2000.
#' \describe{
#' \item{year}{Year.}
#' \item{ctycode}{Country code.}
#' \item{countryname}{Country name.}
#' \item{polity2}{The combined democracy and autocracy scale (Polity 2) from the Polity IV-project. The scale runs from -10 
#' (most autocratic) to +10 (most democratic). }
#' \item{l_soc}{Socialist legal origin. }
#' \item{c_uk_mt}{British colonial origin.}
#' \item{c_esp}{Spanish colonial origin.}
#' \item{africa}{African country dummy.}
#' \item{laam}{Latin-America country dummy. }
#' \item{asia_me}{Middle East country dummy. }
#' \item{asia_as}{Asian country dummy}
#' \item{humancapital}{Human capital.}
#' \item{gyp}{GDP per capita growth. } 
#' \item{democracy}{A dichotomous measure of democracy, building on 
#' Boix and Sebastian Rosato's (2001) extension of the measure constructed by Przeworski et al. (2000)}
#' \item{ldemocracy}{Democracy lagged by one year. }
#' \item{closdem_cont_dist}{Foreign democratic capital. }
#' \item{flyp1_distance}{Foreign per capita income. }
#' \item{war}{Dummy variabled coded 1 if the country is at war.}
#' \item{lwar}{War lagged by one year. }
#' \item{end_dem}{Unkown. A categorical variabel with values 0, 1 and 2. }
#' \item{end_dic}{Unkown. A categorical variabel with values 0, 1 and 2. }
#' \item{llyp}{Lagged log per capita income.}
#' \item{period}{Number of years since 1800. }
#' \item{period_sq}{Period squared. }
#' \item{m5dic}{Switched regimes more than 5 times}
#' \item{demcap_delta94}{Democratic capital generated with delta = 0.94; Polity definition. }
#' \item{demcap_delta99}{Democratic capital generated with delta = 0.99; Polity definition. }
#' \item{polity_start}{ Polity2 in first year of independence (Polity IV). }
#' \item{exconst_start}{Constraints on the executive in first year of independence (Polity IV). }
#' \item{p_dem_sm}{Probability of autocracy (democracies). }
#' \item{p_dic_sm}{Probability of democracy (autocracies), }
#' \item{p_dem_sm_nodemcap}{p_dem_sm constructed without demcap as an explanatory variable. }
#' \item{p_dic_sm_nodemcap}{p_dic_sm constructed without demcap as an explanatory variable. }
#' \item{transition}{ Transition year dummy}
#' \item{berlin_soviet}{Socialist dummy (after 1989).}
#' \item{demcap_lindem}{Democratic capital in (lagged) democracy. }
#' \item{closdem_lindem}{ Foreign democratic capital in (lagged) democracy. }
#' 
#'  }
#' @name PerssonTabellini2009
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Perssson and Tabellini (2009). "Democratic Capital: The Nexus of Political and Economic Change", 
#' American Economic Journal: Macroeconomics, American Economic Association, vol. 1(2), pages 88-126, July. 
#' @source Guido Tabellinis' homeoages´ homepage \url{http://didattica.unibocconi.eu/myigier/index.php?IdUte=48805&idr=4243&lingua=eng}.
#' @keywords dataset regime
#' @examples
#' # This example replicates Model 3 and Model 7 in Table 4 in the article. 
#' data(PerssonTabellini2009)
#' library(lmtest)
#' 
#' model3 <- lm(gyp ~ demcap_delta99 + transition + llyp + flyp1_distance 
#'            + p_dem_sm + war + lwar + as.factor(year) - 1 +  as.factor(ctycode) - 1,
#'            data=PerssonTabellini2009)
#'# clse.f(PerssonTabellini2009, model3, PerssonTabellini2009$ctycode)
#'#Standard errors clustered on country
#'summary(model3)
#' ##coeftest(model3, vcovHC(model3, type = "HC0")) #Heteroskedasticity consistent standard errors 
#'
#' model7 <- lm(gyp ~ demcap_delta99 + berlin_soviet +  transition + llyp +
#' flyp1_distance + p_dic_sm + war + lwar + 
#'              as.factor(year) - 1 + as.factor(ctycode) - 1 ,
#'              data=PerssonTabellini2009)
#' ##clse.f(PerssonTabellini2009, model7, PerssonTabellini2009$ctycode)
#' #Standard errors clustered on country
#' ##coeftest(model3, vcovHC(model7, type = "HC0"))
#' #Heteroskedasticity consistent standard errors
#' summary(model7) 
NULL