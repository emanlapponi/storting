#' CHES - Chapel Hill expert survey trend file
#' 
#' @description This is the trend file for Chapel Hill expert survey (CHES) of party positions. The dataset contains the following variables
#' @format A dataframe with 704 rows and 62 variables.
#' It includes 287 parties from 24 countries.
#' For full documentation, see \url{http://chesdata.eu/}
#' \describe{
#' 
#' \item{country}{Two- or Three-letter country abbreviation}
#' \item{eastwest}{Eastern or western Europe.}
#' \item{eumember}{Membership status.}
#' \item{year}{Year expert was asked to evaluate the party}
#' \item{expert}{Number of experts who evaluated this party}
#' \item{party_id}{Party id}
#' \item{cmp_id}{Party ID in the Manifesto Project Party Code (\link{ManifestoFull})}
#' \item{vote}{Share of votes party got in the election most prior to the year.}
#' \item{family}{classification is primarily based on Hix and Lord (1997), except that they place confessional and agrarian parties in separate categories.
#' Family association for parties in Central/Eastern Europe is based primarily on Derksen classification (now incorporated in Wikipedia), triangulated by
#' a) membership or affiliation with international and EU party associations, and b) self-identification.}
#' \item{govt}{Government participation in current year.
#' 
#' 0 = Not in goverment.
#' 
#' 0.5 = In government at part of the year.
#' 
#' 1 = In government in full year.}
#' \item{position}{overall orientation of the party leadership towards European integration, from 1 - 7 where 7 is most in favor of integration.}
#' \item{pro_anti}{Variable \code{position} recoded into a trichotomous variable.0 = anti, 1 = netural, 2 = pro}
#' \item{eu_salience}{relative salience of European integration in the party’s public stance. 0 - 4 where 4 indicates high importance.}
#' \item{eu_dissent}{degree of dissent in party on European integration. 0 - 10 where 10 represents extreme division.}
#' \item{eu_benefit}{position of the party leadership in year on whether country has benefited from being a member of the EU. 1 = benefitted, 2 = neither benefitted nor lost, 3 = Not benefitted}
#' \item{ep_ep}{position of the party leadership on the powers of the European Parliament. 1 - 7 where 7 indicates strong favor for power to the European parliament.}
#' \item{eu_fiscal}{Position of party leadership on tax harmonization in the EU.
#' Higher value indicate more in favor of tax harmonization. Only asked in 1999}
#' \item{eu_intmark}{position of the party leadership on the internal market. 1 - 7 where 7 indicates strong favor of internal market.}
#' \item{eu_employ}{Position of party leadership on common employment policy in EU. Higher value indicate more in favor of employment policy. Only asked in 2002}
#' \item{eu_agri}{Position of party leadership on EU agricultural spending. Higher value indicates more in favor of agricultural spending. Only asked in 2002}
#' \item{eu_cohesion}{position of the party leadership on EU cohesion or regional policy (e.g. the structural funds). 1 - 7 where 7 indicates strong favor for cohesion.}
#' \item{eu_environ}{Position of party leadership on common EU environmental policy. Higher value indicate more in favor of common EU environmental policy. Only asked in 1999 and 2002}
#' \item{eu_asylum}{osition of party leadership on common policy on political asylum. Higher value indicate more in favor of common policy on political asylum. Only asked in 1999 and 2002}
#' \item{eu_foreign}{position of the party leadership on EU foreign and security policy. 1 - 7 where 7 indicates strong favor for common EU policy.}
#' \item{eu_turkey}{position of the party leadership on EU enlargement to Turkey. 1 - 7 where 7 is most favorable to enlargement. Only asked in 2006 and 2010}
#' \item{lrgen}{Overall ideological left-right placement. 0=Extreme left, 10=Extreme Right}
#' \item{lrecon}{position of the party in terms of its ideological stance on economic issues. Parties can be classified in terms of their stance on economic issues. Parties on the economic left want government to play an active role in the economy. Parties on the economic right emphasize a reduced economic role for government: privatization, lower taxes, less regulation, less government spending, and a leaner welfare state. 0 = extreme left, 10 = extreme right.}
#' \item{galtan}{position of the party in terms of of their views on democratic freedoms and rights. “Libertarian” or “postmaterialist” parties favor expanded personal freedoms, for example, access to abortion, active euthanasia, same-sex marriage, or greater democratic participation. “Traditional” or “authoritarian” parties often reject these ideas; they value order, tradition, and stability, and believe that the government should be a firm moral authority on social and cultural issues. 0 = Libertarian/postmaterialst, 10=Traditional/Authoritarian}
#' \item{spendvtax}{position on improving public services vs. reducing taxes. 0 - 10 where 10 indicates strong favor for reducing taxes.}
#' \item{spendvtax_salience}{importance/salience of improving public services vs. reducing taxes. Higher value indicate higher salience.}
#' \item{deregulation}{position on deregulation. Higher value indicates more favor for deregulation.}
#' \item{dereg_salience}{importance/salience of deregulation. Higher value indicates higher salience.}
#' \item{redistribution}{position on redistribution of wealth from the rich to the poor. Higher value indicates stronger opposition to redistribution.}
#' \item{redist_salience}{importance/salience of redistribution. Higher value indicates higher salience.}
#' \item{civlib_laworder}{position on civil liberties vs. law and order. Higher value indicates more support for tough measures to fight crime.}
#' \item{civlib_salience}{importance/salience of civil liberties vs. law and order. Higher value indicates higher salience.}        
#' \item{sociallifestyle}{position on social lifestyle (e.g. homosexuality). Higher value indicates more opposition to liberal policies.}        
#' \item{social_salience}{importance/salience of lifestyle (e.g. homosexuality). Higher value indicates higher salience.}        
#' \item{religious_principle}{position on role of religious principles in politics. Higher value indicates more in favor of religious principles politics}    
#' \item{relig_salience}{importance/salience of religious principles. Higher value indicates higher salience.}
#' \item{immigrate_policy}{position on immigration policy. Higher value indicates more favor for tough policy.}       
#' \item{immigra_salience}{importance/salience of immigration policies. Higher value indicates higher salience.}       
#' \item{multiculturalism}{Position of party on integration of immigrants and asylum seekers. Higher value indicates support for strong assimilation.}       
#' \item{multicult_salience}{Relative important/salience of "intergration"-issue for party.}     
#' \item{urban_rural}{position on urban vs. rural interests. Higher value indicates stronger support for rural interests.}           
#' \item{urb_rur_salience}{importance/salience of urban vs. rural interests. Higher value indicates higher salience.}       
#' \item{environment}{position towards the environment. Higher value indicates support for economic growth even at the cost of the environment.}            
#' \item{enviro_salience}{importance/salience of environment. Higher value indicates higher salience.}        
#' \item{cosmo}{Position of party on cosmopolitan vs. nationalism. Higher value indicates advocates for nationalism. Only asked in 2006}
#' \item{cosmo_salience}{Relative importance/salience of "cosmopolitan vs. nationalism"-issue}
#' \item{regions}{position on political decentralization. to regions/localities. Higher value indicates opposition to decentralization.}                
#' \item{region_salience}{importance/salience of decentralization. Higher value indicates higher salience.}       
#' \item{international_security}{position towards international security and peacekeeping missions. Higher value indicates opposition to deployment of national troops.} 
#' \item{international_salience}{importance/salience of international security. Higher value indicates higher salience.} 
#' \item{us}{Position of party on US power in world affairs. Higher value indicates favor of strong US leadership. Only asked in 2006}
#' \item{us_salience}{Relative importance/salience of "US power"-issue for party. Only aske din 2006}
#' \item{ethnic_minorities}{position towards ethnic minorities. Higher value indicates opposition to rights for ethnic minorities.}      
#' \item{ethnic_salience}{importance/salience of ethnic minorities. Higher value indicates higher salience.}        
#'  } 
#' @name CHES
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @references Ryan Bakker, Catherine de Vries, Erica Edwards, Liesbet Hooghe, Seth Jolly, Gary Marks, Jonathan Polk, Jan Rovny, Marco Steenbergen, Milada Vachudova (2012), "Measuring Party Positions in Europe: The Chapel Hill Expert Survey Trend File, 1999-2010," Party Politics
#' @source \url{http://chesdata.eu/} 
#' @seealso \link{Ray} \link{ChapelHill2010} \link{ChapelHill2006} \link{ChapelHill2002} \link{ChapelHill1999} 
#' @keywords dataset party position
#' @examples
#' library(uacd)
#' data(CHES)
NULL