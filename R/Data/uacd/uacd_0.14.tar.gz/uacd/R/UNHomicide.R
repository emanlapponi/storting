#' UNHomicide - United Nations Homicide Statistics
#' 
#' @description United Nations Homicide Statistics
#' @format A balanced dataframe with 3578 rows and 19 variables.
#' It covers 217 countries between 1995 - 2011.
#' \describe{
#' 
#' \item{Region}{Geographical region}
#' \item{Subregion}{Geographical subregion}
#' \item{Firearm_Subregion}{Subregion as it is coded for values of homicides caused by firearms}
#' \item{City_Subregion}{Subregion as it is coded for values of homicides in most populous city}
#' \item{Country}{Country name}
#' \item{Source_Type}{Categorical indicating what kind of source the values are derived from: CJ = Criminal Justice, PH = Public Health.}
#' \item{Source}{Indicates which institution gathered the data}
#' \item{Firearm_Source_Type}{Categorical indicating what kind of source the values for the firearm data are derived from: CJ = Criminal Justice, PH = Public Health.}
#' \item{Firearm_Source}{Indicates which institution gathered the data for firearm homicides}
#' \item{City_Source}{Indicates which institution gathered the data for homicides in the most populous city}
#' \item{Sex_Source_Type}{Categorical indicating what kind of source the values for the homicides by sex data are derived from: CJ = Criminal Justice, PH = Public Health.}
#' \item{Sex_Source}{Indicates which institution gathered the data for homicides by sex. A cross indicates: Country information on causes of death not available for most causes. Estimates based on cause of death modelling and death registration data from other countries in the region. Further country-level information and data on specific causes was also used}
#' \item{Year}{Year}
#' \item{Rate}{Homicide rate per 100000 population. Based on the formula (count/population)*100,000}
#' \item{Count}{Absolute number of homicides}
#' \item{Firearm_Percent}{Percentage of homicides caused by firearms}
#' \item{Firearm_Rate}{Homicide caused by firearm rate per 100000 population}
#' \item{Firearm_Count}{Absolute number of homicides caused by firearms}
#' \item{City}{Country's most populous city}
#' \item{City_Rate}{Homicide rate per 100000 population in most populous city}
#' \item{City_Count}{Absolute number of homicides in most populous city}
#' \item{Males_percentage}{Percentage male homicide victims}
#' \item{Female_percentage}{Percentage female homicide victims}
#' \item{Undetermined_percentage}{Percentage homicides where the victims sex is undetermined}
#' \item{Males_Rate}{Male victims per 100000 population. It is unclear if this measure is males per 100000 total population, or per 100000 male population}
#' \item{Males_Rate}{Female victims per 100000 population. It is unclear if this measure is females per 100000 total population, or per 100000 female population}
#' 
#'  } 
#' @name UNHomicide
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @details Version: 2011 Global Study on Homicide. How subregion is coded varies between the general homicide data,
#' data for firearm homicides and homicides in the most populous city uses.
#' In addition, all (Homicides in general, homicides by firearm, homicides in most populous city and homicide by sex) datasets varies in how they measure in United Kingdom, Norther Ireland,Wales and Scotland.
#' San Marino, Marshall Island, Cook Islands, Niue, and Tuvalu are only noted in the data set for homicides by sex.
#' Time coverage varies alot between countries and between the different homicide measures.
#' 
#' NB! Homicide statistics are highly uncertain.
#' Countries have different abilities to identify homicides, and this changes through the years.
#' Comparison is therefore problematic both through time and space. 
#' @references 
#' UN homicide web page: \url{http://www.unodc.org/unodc/en/data-and-analysis/homicide.html}
#' @keywords dataset crime
#' @source UN homicide web page: \url{http://www.unodc.org/unodc/en/data-and-analysis/homicide.html}
#' @examples
#' # Does the percentage of homicides caused by firearms change the longer a cabinet has
#' # been in office?
#' 
#' data(ParlGov)
#' ParlGov$Start_year <- as.numeric(as.character(ParlGov$Start_year))
#' ParlGov$ParlGov$year <- as.numeric(as.character(ParlGov$ParlGov$year))
#' ParlGov$In_office <- ParlGov$year - ParlGov$Start_year
#' ParlGov <- ParlGov[which(ParlGov$year>=1995 & ParlGov$NewCab==1 &
#' ParlGov$DecemberandCensored==1),]
#' data(UNHomicide)
#' 
#' Homicide <- merge(ParlGov,UNHomicide,by.x=c("country_name","year"),
#'                   by.y=c("Country","Year"),all.x=TRUE)
#' 
#' Homicide$Rate <- as.numeric(Homicide$Rate)
#' Homicide <- Homicide[order(Homicide$country_name,Homicide$year),]
#' Homicide$fire_change <- NA
#' for(i in 2:nrow(Homicide)){
#'   Homicide$fire_change[i] <- ifelse(Homicide$country_name[i]==
#'   Homicide$country_name[i-1],
#'   Homicide$Firearm_Percentage[i]-Homicide$Firearm_Percentage[i-1],NA)
#' }
#' 
#' Homicide$firearm_lag <- NA
#' for(i in 2:nrow(Homicide)){
#'   Homicide$firearm_lag[i] <- ifelse(Homicide$country_name[i]==
#'   Homicide$country_name[i-1], Homicide$Firearm_Percentage[i-1],NA)
#' }
#' 
#' ArmsControl<- lm(fire_change ~ firearm_lag + poly(In_office,3)
#'                  + factor(country_name) ,data=Homicide)
#' 
#' termplot(ArmsControl,se=TRUE,term=2,rug=TRUE,
#' ylab="Change in per. homicides caused by firearms",
#'          xlab="Years in office")
#' abline(h=0)
NULL