#' ArchigosTimeVarying - A Data Base on leaders 1875 - 2004 in time varying format
#' 
#' @description This dataset contains the Archigos dataset in time-varying (start-stop) format.
#' For full documentation see the original
#' \href{http://www.rochester.edu/college/faculty/hgoemans/Archigos.2.9-August.pdf}{codebook}.
#' @format A dataframe with 14653 rows and 35 variables.
#' It covers state leaders in 187 countries between 1872 - 2004.
#' \describe{
#' \item{obsid}{Observation ID. }
#' \item{leadid}{Leader ID. }
#' \item{ccode}{COW numeric country code. }
#' \item{idacr}{COW alpha country code. }
#' \item{leader}{Leader name. }
#' \item{startdate}{Start of tenure spell in d/m/Y format}
#' \item{enddate}{End of tenure spell in d/m/Y format}
#' \item{bornin}{Leader birth date. }
#' \item{died}{Leader death date. }
#' \item{eindate}{Start of tenure spell in Y-m-d format}
#' \item{eoutdate}{End of tenure spell in Y-m-d format}
#' \item{startobs}{Start date of this observation row (start-stop format)}
#' \item{endobs}{End date of this observation row}
#' \item{year}{Year}
#' \item{entry}{Identifies how the leader came to power. {\strong{0)}} Through regular means
#' {\strong{1)}} Through irregular means {\strong{2)}} Directly imposed by another state.}
#' \item{exit}{Identifies how the leader lost power. {\strong{1)}} Through regular means
#' {\strong{2)}} Leader died of natural cause while in power {\strong{2.1)}} Leader retired due to ill health.
#' {\strong{2.2)}} Leader lost office as a result of suicide.
#' {\strong{3)}} Leader lost power through irregular means
#' {\strong{4)}} Leader deposed by another state
#' {\strong{-888)}} Leader still in power }
#' \item{exit_tv}{Equal to {\emph{exit}} but coded as missing (-888) for all years but the last leader year.}
#' \item{fail}{Coded 1 if this is the year the leader loses power}
#' \item{age0}{Age of leader when the leader enters power}
#' \item{age}{Age of leader in the given year}
#' \item{exitcode}{Identifies in more detail how the leader lost power.
#' {\strong{0)}} Through regular means
#' {\strong{1)}} Leader lost power as a result of domestic popular protest with foreign support
#' {\strong{2)}} Leader lost power as a result of domestic popular protest without foreign support
#' {\strong{3)}} Leader removed by domestic rebel forces with foreign support
#' {\strong{4)}} Leader removed by domestic rebel forces without foreign support
#' {\strong{5)}} Leader removed by domestic military actors with foreign support
#' {\strong{6)}} Leader removed by domestic military actors without foreign support
#' {\strong{7)}} Leader removed by other domestic government actors with foreign support
#' {\strong{8)}} Leader removed by other domestic government actors without foreign support
#' {\strong{9)}} Leader removed through the threat or use of foreign force
#' {\strong{11)}} Leader removed through assassination by unsupported individual
#' {\strong{16)}} Leader removed in a power struggle within military, short of coup, i.e. without changing institutional features such as a military council or junta
#' {\strong{111)}} Leader removed in an irregular manner through other means or processes
#' }
#' \item{prevtimesinoffice}{This variable counts the leader's previous times in office. }
#' \item{posttenurefate}{Post tenure fate.
#' 
#' {\strong{-999)}} Missing because lost once in 2004, before 31 December. No year has passed.
#' {\strong{-888)}} Missing because the leader is still in power
#' {\strong{-777)}} Missing because the leader died a natural death, up to six months after losing once.
#' {\strong{-666)}} Missing because no information could be found.
#' {\strong{0)}} OK
#' {\strong{1)}} Exile
#' {\strong{2)}} Imprisonment (including house arrest)
#' {\strong{3)}} Death }
#' \item{gender}{Gender. {\strong{0)}} Male
#' {\strong{1)}} Female }
#' \item{ten}{Tenure duration for this observation row. This is {\emph{endobs}} - {\emph{startobs}}}
#' \item{sumten}{Cumulative tenure duration. This variable cumulates values from {\emph{ten}}. The last entry for each leader will be that leader's total tenure duration}
#' \item{lnten}{This is the natural logarithm of {\emph{sumten}}}
#' \item{obsid}{Id for observation row}
#' \item{numld}{Unkown.}
#' \item{outday}{This is "Day" extracted from {\emph{enddate}}}
#' \item{borndate}{Exact date of birth.}
#' \item{yrborn}{Year of birth.}
#' \item{deathdate}{Exact date of death. }
#' \item{yrdied}{Year of death.}
#' }
#' @name ArchigosTimeVarying
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen 
#' @references Goemans, Gleditsch, Chiozza (2009). "Introducing Archigos: A Data Set of Political Leaders," 
#' Journal of Peace Research, 46(2), (March) 2009: 269-183.
#' @keywords dataset leaders cabinet
#' @source Project homepage: \url{http://www.rochester.edu/college/faculty/hgoemans/data.htm}
#' @seealso Archigos ArchigosElectionDates
#' @examples 
#' #This example shows how ArchigosTimeVarying can be used together with ParlGov to see
#' #if characteristics of the prime minister matters for the cabinet.
#' 
#' data(ArchigosTimeVarying)
#' ArchigosTimeVarying <- ArchigosTimeVarying[which(ArchigosTimeVarying$year>=1900),]
#' data(ParlGov)
#' #December cabinets
#' ParlGov <- ParlGov[which(ParlGov$year < 2005 & ParlGov$NewCab==1
#'                          & ParlGov$DecemberandCensored > 0),]
#' 
#' #Find december leaders in ArchigosTimeVarying
#' ArchigosTimeVarying$startnumeric <- as.numeric(
#' as.character(difftime(ArchigosTimeVarying$startobs,
#' "1900-01-01",units="weeks")))
#' ArchigosTimeVarying$endnumeric <- as.numeric(
#' as.character(difftime(ArchigosTimeVarying$endobs,
#' "1900-01-01",units="weeks")))
#' ArchigosTimeVarying$December <- paste(
#' as.character(ArchigosTimeVarying$year),"-12-31",sep="")
#' ArchigosTimeVarying$decnumeric <-  as.numeric(
#' as.character(difftime(ArchigosTimeVarying$December,
#' "1900-01-01",units="weeks")))
#' ArchigosTimeVarying$decdummy <- ifelse(
#' ArchigosTimeVarying$decnumeric >
#' ArchigosTimeVarying$startnumeric
#' & ArchigosTimeVarying$decnumeric < 
#' ArchigosTimeVarying$endnumeric,1,0)
#' 
#' ArchigosDecember <- ArchigosTimeVarying[which(ArchigosTimeVarying$decdummy==1),]
#' library(countrycode)
#' ParlGov$ccode <- countrycode(ParlGov$country_name_short,"iso3c","cown",warn=TRUE)
#' DemLeaders <- merge(ParlGov,ArchigosDecember,by=c("ccode","year"),all.x=TRUE)
#' DemLeaders <- DemLeaders[order(DemLeaders$country_name_short,
#'                                DemLeaders$year, DemLeaders$cabinet_name),]
#' #Extract one row per cabinet, since there are no variables with yearly variation
#' Cabinets <- DemLeaders[!duplicated(DemLeaders$cabinet_name),]
#' 
#' 
#' library(survival);library(eha)
#' Cabinets$cabinet_duration <- as.numeric(as.character(Cabinets$cabinet_duration))
#' 
#' #See differences between genders
#' plot(Surv(Cabinets$cabinet_duration),strata=Cabinets$gender,fn="surv")
#' 
#' #A cox model 
#' summary(coxph(Surv(cabinet_duration) ~ cluster(country_name_short)
#'               + factor(gender) + age0 + minority_seats,data=Cabinets))
#' 
NULL