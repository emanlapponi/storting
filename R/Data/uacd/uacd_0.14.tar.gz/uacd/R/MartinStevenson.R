#' MartinStevenson - Replication data for "Government Formation in parliamentary democarcies"
#' 
#' @description Lanny W. Martin and Randolph T. Stevenson (2001) replication data for "Government Formation in parliamentary democarcies"
#' @format A data frame with 33256 rows and 67 variables. This documentation is not finished.
#' 
#' \describe{
#' 
#' \item{case}{Unique ID for each formation attempt.}
#' \item{country}{Country. Follows Manifesto Research Group country codes.
#' 
#' 11 = Sweden
#' 
#' 12 = Norway
#' 
#' 13 = Denmark
#' 
#' 14 = Iceland
#' 
#' 21 = Belgium
#' 
#' 22 = Netherlands
#' 
#' 23 = Luxembourg
#' 
#' 32 = Italy
#' 
#' 41 = Germany
#' 
#' 42 = Austria
#' 
#' 51 = UK
#' 
#' 53 = Ireland
#' 
#' 62 = Canada
#' 
#' 72 = Israel
#' 
#' }
#' \item{formopp}{Unique ID for each formation attempt within countries.}
#' \item{seats}{No definition of variable in codebook nor .do file.}
#' \item{realg}{The real government dummy. 1 indicates a real governemnt, 0 are potential governments.}
#' \item{gdiv1}{Ideological devisions in the coalition, based on Manifesto rile-score.}
#' \item{mgodiv1}{Ideological devisions within the majority opposition, based on Manifesto rile-score.}
#' \item{minor}{Minority coalition}
#' \item{median}{Dummy indicating the median party in coalition}
#' \item{minwin}{Minimum winning coalition}
#' \item{dompar}{Largest party in the coalition}
#' \item{sq}{Incumbent coalition}
#' \item{prevpm}{Previous prime minister in coalition}
#' \item{mcw3}{Minimal connected winning coalition}
#' \item{minran2}{Ideological-compact minimal winning coalition}
#' \item{mginvest}{Minoirty coalition where investiture vote required}
#' \item{anmax2}{Anti-system presence in the coalition}
#' \item{pmdist}{Ideological divisions between formateur and partner}
#' \item{pmport}{Dummy indicating if the coalition includes formateur}
#' \item{vsp}{Very strong party in coalition}
#' \item{msp}{Merely strong party in coalition}
#' \item{psp}{}
#' \item{singpar}{}
#' \item{warmiss}{}
#' \item{pmpodi}{}
#' \item{vspsing}{Very strong party alone in coalition}
#' \item{msppsp}{}
#' \item{mwgdiv1}{}
#' \item{gdiv1c}{}
#' \item{pmgdvdif}{}
#' \item{numpar}{Number of parties in coalition}
#' \item{anti}{Anti-pact associated with the coalition}
#' \item{pro}{Pre-electoral pact associated with the coalition}
#' \item{newid}{}
#' \item{equal1}{}
#' \item{pmdisneq}{}
#' \item{gdiv1neq}{}
#' \item{single}{}
#' \item{pspmsp}{}
#' \item{mspsing}{Merely strong party alone in coalition}
#' \item{pfull1}{}
#' \item{pmw1}{}
#' \item{pmed1}{}
#' \item{pgdiv1}{}
#' \item{pnp1}{}
#' \item{pmin1}{}
#' \item{pinv1}{}
#' \item{pbig1}{}
#' \item{psq1}{}
#' \item{ppm1}{}
#' \item{pant1}{}
#' \item{ppro1}{}
#' \item{pneg1}{}
#' \item{popp1}{}
#' \item{preif}{}
#' \item{prebg}{}
#' \item{coal}{}
#' \item{vspcoal}{}
#' \item{mspcoal}{}
#' \item{prels}{}
#' \item{prelsod}{}
#' \item{preod}{}
#' \item{exclude1}{}
#' \item{eq1}{}
#' \item{central}{}
#' \item{counform}{}
#' \item{govt}{The party codes for the parties in the coalition. It follows a complex system with country and formopp, explained in the codebook.}
#'  
#' }
#' @details The codebooks lacks definition of most variables in the data set. This documentation is not yet finished.
#' @name MartinStevenson
#' @references Lanny Martin; Randolph T. Stevenson 2001,
#' Replication data for: "Government Formation in parliamentary democarcies",
#' \url{http://www.ruf.rice.edu/~lmartin/Research.html}
#' 
#' @keywords dataset cabinet
#' @source Martins dataverse: \url{http://www.ruf.rice.edu/~lmartin/Research.html}
#' @author Bjørn Høyland, Haakon Gjerløw, Aleksander Eilertsen
#' @examples
#' library(uacd)
#' data(MartinStevenson)
#' 
#' 
NULL